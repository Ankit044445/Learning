dmx.config({
  "loginlayout": {
    "apiLabels": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "object",
            "name": "result",
            "sub": [
              {
                "type": "key_array",
                "name": "general",
                "sub": [
                  {
                    "type": "text",
                    "name": "label"
                  }
                ]
              },
              {
                "type": "object",
                "name": "login",
                "sub": [
                  {
                    "type": "object",
                    "name": "login",
                    "sub": [
                      {
                        "type": "text",
                        "name": "button"
                      },
                      {
                        "type": "text",
                        "name": "screen_title"
                      },
                      {
                        "type": "text",
                        "name": "section_header"
                      }
                    ]
                  },
                  {
                    "type": "object",
                    "name": "password",
                    "sub": [
                      {
                        "type": "text",
                        "name": "error_required"
                      },
                      {
                        "type": "text",
                        "name": "label"
                      },
                      {
                        "type": "text",
                        "name": "placeholder"
                      }
                    ]
                  },
                  {
                    "type": "object",
                    "name": "username",
                    "sub": [
                      {
                        "type": "text",
                        "name": "error_required"
                      },
                      {
                        "type": "text",
                        "name": "label"
                      },
                      {
                        "type": "text",
                        "name": "placeholder"
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "apiLogin": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "array",
            "name": "result",
            "sub": [
              {
                "type": "boolean",
                "name": "success"
              },
              {
                "type": "text",
                "name": "token"
              }
            ]
          }
        ]
      }
    ],
    "apiTest": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "array",
            "name": "result",
            "sub": [
              {
                "type": "boolean",
                "name": "success"
              },
              {
                "type": "object",
                "name": "data",
                "sub": [
                  {
                    "type": "text",
                    "name": "password"
                  },
                  {
                    "type": "number",
                    "name": "id"
                  },
                  {
                    "type": "text",
                    "name": "email"
                  }
                ]
              },
              {
                "type": "text",
                "name": "token"
              }
            ]
          }
        ]
      }
    ]
  },
  "login": {
    "apiLabel": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "object",
            "name": "result",
            "sub": [
              {
                "type": "object",
                "name": "general",
                "sub": [
                  {
                    "type": "text",
                    "name": "cancel"
                  },
                  {
                    "type": "text",
                    "name": "close"
                  },
                  {
                    "type": "text",
                    "name": "error"
                  },
                  {
                    "type": "text",
                    "name": "error_connection"
                  },
                  {
                    "type": "text",
                    "name": "error_server"
                  },
                  {
                    "type": "text",
                    "name": "no"
                  },
                  {
                    "type": "text",
                    "name": "ok"
                  },
                  {
                    "type": "text",
                    "name": "save"
                  },
                  {
                    "type": "text",
                    "name": "yes"
                  }
                ]
              },
              {
                "type": "object",
                "name": "login",
                "sub": [
                  {
                    "type": "object",
                    "name": "login",
                    "sub": [
                      {
                        "type": "text",
                        "name": "button"
                      },
                      {
                        "type": "text",
                        "name": "error_creds"
                      },
                      {
                        "type": "text",
                        "name": "screen_title"
                      },
                      {
                        "type": "text",
                        "name": "section_header"
                      }
                    ]
                  },
                  {
                    "type": "object",
                    "name": "password",
                    "sub": [
                      {
                        "type": "text",
                        "name": "error_required"
                      },
                      {
                        "type": "text",
                        "name": "label"
                      },
                      {
                        "type": "text",
                        "name": "placeholder"
                      }
                    ]
                  },
                  {
                    "type": "object",
                    "name": "username",
                    "sub": [
                      {
                        "type": "text",
                        "name": "error_required"
                      },
                      {
                        "type": "text",
                        "name": "label"
                      },
                      {
                        "type": "text",
                        "name": "placeholder"
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "apiLogin": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "number",
            "name": "userid"
          },
          {
            "type": "text",
            "name": "token"
          },
          {
            "type": "boolean",
            "name": "result"
          }
        ]
      }
    ],
    "flowLogin": [
      {
        "name": "validUser",
        "type": "text"
      }
    ],
    "localStorage": [
      {
        "type": "text",
        "name": "username"
      },
      {
        "type": "text",
        "name": "token"
      },
      {
        "type": "text",
        "name": "userid"
      }
    ]
  },
  "list": {
    "apiTable": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "object",
            "name": "data",
            "sub": [
              {
                "type": "number",
                "name": "offset"
              },
              {
                "type": "number",
                "name": "limit"
              },
              {
                "type": "number",
                "name": "total"
              },
              {
                "type": "object",
                "name": "page",
                "sub": [
                  {
                    "type": "object",
                    "name": "offset",
                    "sub": [
                      {
                        "type": "number",
                        "name": "first"
                      },
                      {
                        "type": "number",
                        "name": "prev"
                      },
                      {
                        "type": "number",
                        "name": "next"
                      },
                      {
                        "type": "number",
                        "name": "last"
                      }
                    ]
                  },
                  {
                    "type": "number",
                    "name": "current"
                  },
                  {
                    "type": "number",
                    "name": "total"
                  }
                ]
              },
              {
                "type": "array",
                "name": "data",
                "sub": [
                  {
                    "type": "text",
                    "name": "lead_fname"
                  },
                  {
                    "type": "text",
                    "name": "lead_lname"
                  },
                  {
                    "type": "text",
                    "name": "lead_phone"
                  },
                  {
                    "type": "text",
                    "name": "qualify_id"
                  },
                  {
                    "type": "text",
                    "name": "lead_email"
                  },
                  {
                    "type": "number",
                    "name": "project_id"
                  },
                  {
                    "type": "number",
                    "name": "student_status"
                  },
                  {
                    "type": "text",
                    "name": "address_place"
                  },
                  {
                    "type": "text",
                    "name": "address_street"
                  },
                  {
                    "type": "text",
                    "name": "address_city"
                  },
                  {
                    "type": "text",
                    "name": "address_state"
                  },
                  {
                    "type": "text",
                    "name": "address_zip"
                  },
                  {
                    "type": "text",
                    "name": "qualify_status"
                  },
                  {
                    "type": "text",
                    "name": "project_name"
                  },
                  {
                    "type": "text",
                    "name": "name"
                  },
                  {
                    "type": "text",
                    "name": "email"
                  },
                  {
                    "type": "text",
                    "name": "phone"
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "localStorage": [
      {
        "type": "text",
        "name": "qualify_name"
      },
      {
        "type": "text",
        "name": "qualify_email"
      },
      {
        "type": "text",
        "name": "qualify_phone"
      },
      {
        "type": "text",
        "name": "qualify_project"
      },
      {
        "type": "text",
        "name": "qualify_status"
      },
      {
        "type": "text",
        "name": "token"
      }
    ],
    "apiLabels": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "object",
            "name": "result",
            "sub": [
              {
                "type": "object",
                "name": "general",
                "sub": [
                  {
                    "type": "text",
                    "name": "cancel"
                  },
                  {
                    "type": "text",
                    "name": "close"
                  },
                  {
                    "type": "text",
                    "name": "error"
                  },
                  {
                    "type": "text",
                    "name": "error_server"
                  },
                  {
                    "type": "text",
                    "name": "filter"
                  },
                  {
                    "type": "text",
                    "name": "no"
                  },
                  {
                    "type": "text",
                    "name": "ok"
                  },
                  {
                    "type": "text",
                    "name": "reset"
                  },
                  {
                    "type": "text",
                    "name": "save"
                  },
                  {
                    "type": "text",
                    "name": "update"
                  },
                  {
                    "type": "text",
                    "name": "yes"
                  }
                ]
              },
              {
                "type": "object",
                "name": "leads",
                "sub": [
                  {
                    "type": "object",
                    "name": "leads",
                    "sub": [
                      {
                        "type": "text",
                        "name": "about_survey"
                      },
                      {
                        "type": "text",
                        "name": "action"
                      },
                      {
                        "type": "text",
                        "name": "address"
                      },
                      {
                        "type": "text",
                        "name": "add_new_lead"
                      },
                      {
                        "type": "text",
                        "name": "apply_action"
                      },
                      {
                        "type": "text",
                        "name": "apply_selection"
                      },
                      {
                        "type": "text",
                        "name": "assigned_to"
                      },
                      {
                        "type": "text",
                        "name": "batch_assign"
                      },
                      {
                        "type": "text",
                        "name": "batch_list"
                      },
                      {
                        "type": "text",
                        "name": "cancel"
                      },
                      {
                        "type": "text",
                        "name": "city"
                      },
                      {
                        "type": "text",
                        "name": "Create_batch"
                      },
                      {
                        "type": "text",
                        "name": "date"
                      },
                      {
                        "type": "text",
                        "name": "date_from"
                      },
                      {
                        "type": "text",
                        "name": "date_to"
                      },
                      {
                        "type": "text",
                        "name": "email"
                      },
                      {
                        "type": "text",
                        "name": "first_name"
                      },
                      {
                        "type": "text",
                        "name": "fname"
                      },
                      {
                        "type": "text",
                        "name": "hh_income"
                      },
                      {
                        "type": "text",
                        "name": "hh_size"
                      },
                      {
                        "type": "text",
                        "name": "id"
                      },
                      {
                        "type": "text",
                        "name": "last_name"
                      },
                      {
                        "type": "text",
                        "name": "log_history"
                      },
                      {
                        "type": "text",
                        "name": "method_of_communication"
                      },
                      {
                        "type": "text",
                        "name": "new_leads"
                      },
                      {
                        "type": "text",
                        "name": "note"
                      },
                      {
                        "type": "text",
                        "name": "phone"
                      },
                      {
                        "type": "text",
                        "name": "projects"
                      },
                      {
                        "type": "text",
                        "name": "reset_filter"
                      },
                      {
                        "type": "text",
                        "name": "review_tag"
                      },
                      {
                        "type": "text",
                        "name": "save"
                      },
                      {
                        "type": "text",
                        "name": "search"
                      },
                      {
                        "type": "text",
                        "name": "select/search"
                      },
                      {
                        "type": "text",
                        "name": "source"
                      },
                      {
                        "type": "text",
                        "name": "state"
                      },
                      {
                        "type": "text",
                        "name": "status"
                      },
                      {
                        "type": "text",
                        "name": "street_address"
                      },
                      {
                        "type": "text",
                        "name": "student"
                      },
                      {
                        "type": "text",
                        "name": "title"
                      },
                      {
                        "type": "text",
                        "name": "update"
                      },
                      {
                        "type": "text",
                        "name": "zip"
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "sessionStorage": [
      {
        "type": "text",
        "name": "lead_list_create"
      },
      {
        "type": "text",
        "name": "lead_list_create_alert"
      },
      {
        "type": "text",
        "name": "lead_list_update_alert"
      },
      {
        "type": "text",
        "name": "lead_list_update_project"
      }
    ],
    "flowOnLoad": [
      {
        "name": "alert_create",
        "type": "text"
      }
    ],
    "apionactive": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "text",
            "name": "message"
          },
          {
            "type": "boolean",
            "name": "result"
          }
        ]
      }
    ],
    "flowOnActive": [
      {
        "name": "$param",
        "type": "object",
        "sub": [
          {
            "type": "text",
            "name": "project_id"
          },
          {
            "type": "text",
            "name": "is_active"
          }
        ]
      }
    ],
    "tableRepeat1": {
      "meta": [
        {
          "type": "number",
          "name": "id"
        },
        {
          "type": "number",
          "name": "response_id"
        },
        {
          "type": "text",
          "name": "date"
        },
        {
          "type": "text",
          "name": "adsource"
        },
        {
          "type": "number",
          "name": "student_status"
        },
        {
          "type": "text",
          "name": "source_project"
        },
        {
          "type": "text",
          "name": "fname"
        },
        {
          "type": "text",
          "name": "lname"
        },
        {
          "type": "text",
          "name": "email"
        },
        {
          "type": "text",
          "name": "phone"
        },
        {
          "type": "text",
          "name": "address_place"
        },
        {
          "type": "text",
          "name": "address_street"
        },
        {
          "type": "text",
          "name": "address_city"
        },
        {
          "type": "text",
          "name": "address_state"
        },
        {
          "type": "number",
          "name": "address_zip"
        },
        {
          "type": "number",
          "name": "address_lati"
        },
        {
          "type": "number",
          "name": "address_longi"
        },
        {
          "type": "text",
          "name": "howheardsrc"
        },
        {
          "type": "text",
          "name": "prefcomms"
        },
        {
          "type": "number",
          "name": "ok2sms"
        },
        {
          "type": "number",
          "name": "notifysurv"
        },
        {
          "type": "number",
          "name": "project_id"
        },
        {
          "type": "text",
          "name": "camp_resident"
        },
        {
          "type": "number",
          "name": "dormitory"
        },
        {
          "type": "text",
          "name": "dormitory_other"
        },
        {
          "type": "number",
          "name": "married_spouse"
        },
        {
          "type": "number",
          "name": "other_rommate_nonttu"
        },
        {
          "type": "number",
          "name": "live_with_parents"
        },
        {
          "type": "text",
          "name": "applinks_pin"
        },
        {
          "type": "number",
          "name": "live_in_studyarea"
        },
        {
          "type": "number",
          "name": "hh_income"
        },
        {
          "type": "number",
          "name": "hh_size"
        },
        {
          "type": "number",
          "name": "assigned_to"
        },
        {
          "type": "number",
          "name": "lead_status"
        },
        {
          "type": "text",
          "name": "created_on"
        },
        {
          "type": "number",
          "name": "created_by"
        },
        {
          "type": "text",
          "name": "updated_on"
        },
        {
          "type": "text",
          "name": "updated_by"
        }
      ],
      "outputType": "object"
    },
    "tableRepeat2": {
      "meta": [
        {
          "name": "$index",
          "type": "number"
        },
        {
          "name": "$key",
          "type": "text"
        },
        {
          "name": "$value",
          "type": "object"
        },
        {
          "type": "number",
          "name": "id"
        },
        {
          "type": "number",
          "name": "response_id"
        },
        {
          "type": "text",
          "name": "date"
        },
        {
          "type": "text",
          "name": "adsource"
        },
        {
          "type": "number",
          "name": "student_status"
        },
        {
          "type": "text",
          "name": "source_project"
        },
        {
          "type": "text",
          "name": "fname"
        },
        {
          "type": "text",
          "name": "lname"
        },
        {
          "type": "text",
          "name": "email"
        },
        {
          "type": "text",
          "name": "phone"
        },
        {
          "type": "text",
          "name": "address_place"
        },
        {
          "type": "text",
          "name": "address_street"
        },
        {
          "type": "text",
          "name": "address_city"
        },
        {
          "type": "text",
          "name": "address_state"
        },
        {
          "type": "number",
          "name": "address_zip"
        },
        {
          "type": "number",
          "name": "address_lati"
        },
        {
          "type": "number",
          "name": "address_longi"
        },
        {
          "type": "text",
          "name": "howheardsrc"
        },
        {
          "type": "text",
          "name": "prefcomms"
        },
        {
          "type": "number",
          "name": "ok2sms"
        },
        {
          "type": "number",
          "name": "notifysurv"
        },
        {
          "type": "number",
          "name": "project_id"
        },
        {
          "type": "text",
          "name": "camp_resident"
        },
        {
          "type": "number",
          "name": "dormitory"
        },
        {
          "type": "text",
          "name": "dormitory_other"
        },
        {
          "type": "number",
          "name": "married_spouse"
        },
        {
          "type": "number",
          "name": "other_rommate_nonttu"
        },
        {
          "type": "number",
          "name": "live_with_parents"
        },
        {
          "type": "text",
          "name": "applinks_pin"
        },
        {
          "type": "number",
          "name": "live_in_studyarea"
        },
        {
          "type": "number",
          "name": "hh_income"
        },
        {
          "type": "number",
          "name": "hh_size"
        },
        {
          "type": "number",
          "name": "assigned_to"
        },
        {
          "type": "number",
          "name": "lead_status"
        },
        {
          "type": "text",
          "name": "created_on"
        },
        {
          "type": "number",
          "name": "created_by"
        },
        {
          "type": "text",
          "name": "updated_on"
        },
        {
          "type": "text",
          "name": "updated_by"
        }
      ],
      "outputType": "object"
    },
    "apiBatchCreate": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "array",
            "name": "leadids",
            "sub": [
              {
                "type": "number",
                "name": "$value"
              }
            ]
          },
          {
            "type": "boolean",
            "name": "result"
          }
        ]
      }
    ],
    "apiReviewtag": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "array",
            "name": "data",
            "sub": [
              {
                "type": "number",
                "name": "id"
              },
              {
                "type": "text",
                "name": "tag"
              },
              {
                "type": "text",
                "name": "description"
              },
              {
                "type": "text",
                "name": "status"
              },
              {
                "type": "number",
                "name": "created_by"
              },
              {
                "type": "text",
                "name": "created_on"
              },
              {
                "type": "text",
                "name": "updated_on"
              },
              {
                "type": "text",
                "name": "updated_by"
              }
            ]
          }
        ]
      }
    ],
    "apiBatchList": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "object",
            "name": "data",
            "sub": [
              {
                "type": "number",
                "name": "offset"
              },
              {
                "type": "number",
                "name": "limit"
              },
              {
                "type": "number",
                "name": "total"
              },
              {
                "type": "object",
                "name": "page",
                "sub": [
                  {
                    "type": "object",
                    "name": "offset",
                    "sub": [
                      {
                        "type": "number",
                        "name": "first"
                      },
                      {
                        "type": "number",
                        "name": "prev"
                      },
                      {
                        "type": "number",
                        "name": "next"
                      },
                      {
                        "type": "number",
                        "name": "last"
                      }
                    ]
                  },
                  {
                    "type": "number",
                    "name": "current"
                  },
                  {
                    "type": "number",
                    "name": "total"
                  }
                ]
              },
              {
                "type": "array",
                "name": "data",
                "sub": [
                  {
                    "type": "number",
                    "name": "batch_lead_id"
                  },
                  {
                    "type": "text",
                    "name": "batch_label"
                  },
                  {
                    "type": "text",
                    "name": "lead_id"
                  },
                  {
                    "type": "text",
                    "name": "lead_type"
                  },
                  {
                    "type": "number",
                    "name": "user_id"
                  },
                  {
                    "type": "number",
                    "name": "records_count"
                  },
                  {
                    "type": "text",
                    "name": "created_on"
                  },
                  {
                    "type": "text",
                    "name": "created_by"
                  },
                  {
                    "type": "text",
                    "name": "updated_on"
                  },
                  {
                    "type": "text",
                    "name": "updated_by"
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "arr1": {
      "meta": null,
      "outputType": "text"
    },
    "varBatchLeadfilter": {
      "meta": null,
      "outputType": "text"
    },
    "apiFilterApplyTo": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "text",
            "name": "message"
          }
        ]
      }
    ],
    "apiApplySelection": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "array",
            "name": "leadids",
            "sub": [
              {
                "type": "number",
                "name": "$value"
              }
            ]
          },
          {
            "type": "boolean",
            "name": "result"
          }
        ]
      }
    ],
    "flowLeadStatus": [
      {
        "name": "$param",
        "type": "object",
        "sub": [
          {
            "type": "text",
            "name": "lead_status"
          },
          {
            "type": "text",
            "name": "id"
          }
        ]
      }
    ],
    "varUsername": {
      "meta": null,
      "outputType": "text"
    },
    "apiActionLead": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "text",
            "name": "message"
          }
        ]
      }
    ],
    "varAssingedApply": {
      "meta": null,
      "outputType": "number"
    },
    "apiLeadsDetails": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "object",
            "name": "leaddata",
            "sub": [
              {
                "type": "number",
                "name": "id"
              },
              {
                "type": "number",
                "name": "response_id"
              },
              {
                "type": "text",
                "name": "date"
              },
              {
                "type": "text",
                "name": "adsource"
              },
              {
                "type": "number",
                "name": "student_status"
              },
              {
                "type": "text",
                "name": "source_project"
              },
              {
                "type": "text",
                "name": "fname"
              },
              {
                "type": "text",
                "name": "lname"
              },
              {
                "type": "text",
                "name": "email"
              },
              {
                "type": "text",
                "name": "phone"
              },
              {
                "type": "text",
                "name": "address_place"
              },
              {
                "type": "text",
                "name": "address_street"
              },
              {
                "type": "text",
                "name": "address_city"
              },
              {
                "type": "text",
                "name": "address_state"
              },
              {
                "type": "number",
                "name": "address_zip"
              },
              {
                "type": "text",
                "name": "address_lati"
              },
              {
                "type": "text",
                "name": "address_longi"
              },
              {
                "type": "text",
                "name": "howheardsrc"
              },
              {
                "type": "text",
                "name": "prefcomms"
              },
              {
                "type": "text",
                "name": "ok2sms"
              },
              {
                "type": "text",
                "name": "notifysurv"
              },
              {
                "type": "number",
                "name": "project_id"
              },
              {
                "type": "text",
                "name": "camp_resident"
              },
              {
                "type": "text",
                "name": "dormitory"
              },
              {
                "type": "text",
                "name": "dormitory_other"
              },
              {
                "type": "text",
                "name": "married_spouse"
              },
              {
                "type": "text",
                "name": "other_rommate_nonttu"
              },
              {
                "type": "text",
                "name": "live_with_parents"
              },
              {
                "type": "text",
                "name": "applinks_pin"
              },
              {
                "type": "text",
                "name": "live_in_studyarea"
              },
              {
                "type": "number",
                "name": "hh_income"
              },
              {
                "type": "number",
                "name": "hh_size"
              },
              {
                "type": "number",
                "name": "assigned_to"
              },
              {
                "type": "number",
                "name": "lead_status"
              },
              {
                "type": "text",
                "name": "created_on"
              },
              {
                "type": "text",
                "name": "created_by"
              },
              {
                "type": "text",
                "name": "updated_on"
              },
              {
                "type": "text",
                "name": "updated_by"
              }
            ]
          },
          {
            "type": "array",
            "name": "lead_history",
            "sub": [
              {
                "type": "text",
                "name": "created_on"
              },
              {
                "type": "number",
                "name": "lead_status"
              },
              {
                "type": "number",
                "name": "assign_to"
              },
              {
                "type": "text",
                "name": "action_note"
              },
              {
                "type": "text",
                "name": "lead_status_name"
              },
              {
                "type": "text",
                "name": "created_by"
              },
              {
                "type": "text",
                "name": "updatedby_name"
              }
            ]
          },
          {
            "type": "array",
            "name": "lead_review_tag",
            "sub": [
              {
                "type": "text",
                "name": "review_tag_id"
              },
              {
                "type": "text",
                "name": "created_on"
              }
            ]
          }
        ]
      }
    ],
    "apiApplyselection": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "array",
            "name": "leadids",
            "sub": [
              {
                "type": "number",
                "name": "$value"
              }
            ]
          },
          {
            "type": "boolean",
            "name": "result"
          }
        ]
      }
    ]
  },
  "create": {
    "apiCreate": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "number",
            "name": "project_id"
          },
          {
            "type": "boolean",
            "name": "result"
          }
        ]
      }
    ],
    "flowCreate": [
      {
        "name": "api",
        "type": "text"
      }
    ],
    "apilabel": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "object",
            "name": "result",
            "sub": [
              {
                "type": "object",
                "name": "general",
                "sub": [
                  {
                    "type": "text",
                    "name": "cancel"
                  },
                  {
                    "type": "text",
                    "name": "close"
                  },
                  {
                    "type": "text",
                    "name": "error"
                  },
                  {
                    "type": "text",
                    "name": "error_server"
                  },
                  {
                    "type": "text",
                    "name": "filter"
                  },
                  {
                    "type": "text",
                    "name": "no"
                  },
                  {
                    "type": "text",
                    "name": "ok"
                  },
                  {
                    "type": "text",
                    "name": "reset"
                  },
                  {
                    "type": "text",
                    "name": "save"
                  },
                  {
                    "type": "text",
                    "name": "yes"
                  }
                ]
              },
              {
                "type": "object",
                "name": "projects",
                "sub": [
                  {
                    "type": "object",
                    "name": "projects",
                    "sub": [
                      {
                        "type": "text",
                        "name": "active"
                      },
                      {
                        "type": "text",
                        "name": "client"
                      },
                      {
                        "type": "text",
                        "name": "code"
                      },
                      {
                        "type": "text",
                        "name": "etc_number"
                      },
                      {
                        "type": "text",
                        "name": "id"
                      },
                      {
                        "type": "text",
                        "name": "name"
                      },
                      {
                        "type": "text",
                        "name": "new_project"
                      },
                      {
                        "type": "text",
                        "name": "status"
                      },
                      {
                        "type": "text",
                        "name": "title"
                      },
                      {
                        "type": "text",
                        "name": "year"
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "apilabels": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "object",
            "name": "result",
            "sub": [
              {
                "type": "object",
                "name": "general",
                "sub": [
                  {
                    "type": "text",
                    "name": "cancel"
                  },
                  {
                    "type": "text",
                    "name": "close"
                  },
                  {
                    "type": "text",
                    "name": "error"
                  },
                  {
                    "type": "text",
                    "name": "error_server"
                  },
                  {
                    "type": "text",
                    "name": "filter"
                  },
                  {
                    "type": "text",
                    "name": "no"
                  },
                  {
                    "type": "text",
                    "name": "ok"
                  },
                  {
                    "type": "text",
                    "name": "reset"
                  },
                  {
                    "type": "text",
                    "name": "save"
                  },
                  {
                    "type": "text",
                    "name": "update"
                  },
                  {
                    "type": "text",
                    "name": "yes"
                  }
                ]
              },
              {
                "type": "object",
                "name": "leads",
                "sub": [
                  {
                    "type": "object",
                    "name": "leads",
                    "sub": [
                      {
                        "type": "text",
                        "name": "about_survey"
                      },
                      {
                        "type": "text",
                        "name": "action"
                      },
                      {
                        "type": "text",
                        "name": "address"
                      },
                      {
                        "type": "text",
                        "name": "add_new_lead"
                      },
                      {
                        "type": "text",
                        "name": "apply_action"
                      },
                      {
                        "type": "text",
                        "name": "apply_selection"
                      },
                      {
                        "type": "text",
                        "name": "assigned_to"
                      },
                      {
                        "type": "text",
                        "name": "batch_assign"
                      },
                      {
                        "type": "text",
                        "name": "cancel"
                      },
                      {
                        "type": "text",
                        "name": "city"
                      },
                      {
                        "type": "text",
                        "name": "Create_batch"
                      },
                      {
                        "type": "text",
                        "name": "date"
                      },
                      {
                        "type": "text",
                        "name": "date_from"
                      },
                      {
                        "type": "text",
                        "name": "date_to"
                      },
                      {
                        "type": "text",
                        "name": "email"
                      },
                      {
                        "type": "text",
                        "name": "first_name"
                      },
                      {
                        "type": "text",
                        "name": "fname"
                      },
                      {
                        "type": "text",
                        "name": "hh_income"
                      },
                      {
                        "type": "text",
                        "name": "hh_size"
                      },
                      {
                        "type": "text",
                        "name": "id"
                      },
                      {
                        "type": "text",
                        "name": "last_name"
                      },
                      {
                        "type": "text",
                        "name": "log_history"
                      },
                      {
                        "type": "text",
                        "name": "method_of_communication"
                      },
                      {
                        "type": "text",
                        "name": "new_leads"
                      },
                      {
                        "type": "text",
                        "name": "note"
                      },
                      {
                        "type": "text",
                        "name": "phone"
                      },
                      {
                        "type": "text",
                        "name": "projects"
                      },
                      {
                        "type": "text",
                        "name": "reset_filter"
                      },
                      {
                        "type": "text",
                        "name": "review_tag"
                      },
                      {
                        "type": "text",
                        "name": "save"
                      },
                      {
                        "type": "text",
                        "name": "search"
                      },
                      {
                        "type": "text",
                        "name": "select/search"
                      },
                      {
                        "type": "text",
                        "name": "source"
                      },
                      {
                        "type": "text",
                        "name": "state"
                      },
                      {
                        "type": "text",
                        "name": "status"
                      },
                      {
                        "type": "text",
                        "name": "street_address"
                      },
                      {
                        "type": "text",
                        "name": "student"
                      },
                      {
                        "type": "text",
                        "name": "title"
                      },
                      {
                        "type": "text",
                        "name": "update"
                      },
                      {
                        "type": "text",
                        "name": "zip"
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "sessionStorage": [
      {
        "type": "text",
        "name": "lead_list_create_alert"
      },
      {
        "type": "text",
        "name": "lead_list_create"
      }
    ],
    "apiGetproject": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "object",
            "name": "query",
            "sub": [
              {
                "type": "number",
                "name": "offset"
              },
              {
                "type": "number",
                "name": "limit"
              },
              {
                "type": "number",
                "name": "total"
              },
              {
                "type": "object",
                "name": "page",
                "sub": [
                  {
                    "type": "object",
                    "name": "offset",
                    "sub": [
                      {
                        "type": "number",
                        "name": "first"
                      },
                      {
                        "type": "number",
                        "name": "prev"
                      },
                      {
                        "type": "number",
                        "name": "next"
                      },
                      {
                        "type": "number",
                        "name": "last"
                      }
                    ]
                  },
                  {
                    "type": "number",
                    "name": "current"
                  },
                  {
                    "type": "number",
                    "name": "total"
                  }
                ]
              },
              {
                "type": "array",
                "name": "data",
                "sub": [
                  {
                    "type": "number",
                    "name": "project_id"
                  },
                  {
                    "type": "text",
                    "name": "project_name"
                  },
                  {
                    "type": "text",
                    "name": "project_code"
                  },
                  {
                    "type": "text",
                    "name": "etc_project_number"
                  },
                  {
                    "type": "number",
                    "name": "start_year"
                  },
                  {
                    "type": "text",
                    "name": "client_name"
                  },
                  {
                    "type": "text",
                    "name": "project_status"
                  },
                  {
                    "type": "number",
                    "name": "is_active"
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "apiGetusers": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "array",
            "name": "result",
            "sub": [
              {
                "type": "number",
                "name": "success"
              },
              {
                "type": "object",
                "name": "data",
                "sub": [
                  {
                    "type": "number",
                    "name": "offset"
                  },
                  {
                    "type": "number",
                    "name": "limit"
                  },
                  {
                    "type": "number",
                    "name": "total"
                  },
                  {
                    "type": "object",
                    "name": "page",
                    "sub": [
                      {
                        "type": "object",
                        "name": "offset",
                        "sub": [
                          {
                            "type": "number",
                            "name": "first"
                          },
                          {
                            "type": "number",
                            "name": "prev"
                          },
                          {
                            "type": "number",
                            "name": "next"
                          },
                          {
                            "type": "number",
                            "name": "last"
                          }
                        ]
                      },
                      {
                        "type": "number",
                        "name": "current"
                      },
                      {
                        "type": "number",
                        "name": "total"
                      }
                    ]
                  },
                  {
                    "type": "array",
                    "name": "data",
                    "sub": [
                      {
                        "type": "number",
                        "name": "id"
                      },
                      {
                        "type": "text",
                        "name": "name"
                      },
                      {
                        "type": "text",
                        "name": "email"
                      },
                      {
                        "type": "text",
                        "name": "user_name"
                      },
                      {
                        "type": "number",
                        "name": "is_active"
                      },
                      {
                        "type": "text",
                        "name": "created_on"
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "repeat2": {
      "meta": null,
      "outputType": "text"
    },
    "var1": {
      "meta": null,
      "outputType": "text"
    }
  },
  "update": {
    "apiDetails": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "object",
            "name": "project_data",
            "sub": [
              {
                "type": "number",
                "name": "project_id"
              },
              {
                "type": "text",
                "name": "project_name"
              },
              {
                "type": "text",
                "name": "project_description"
              },
              {
                "type": "text",
                "name": "project_code"
              },
              {
                "type": "text",
                "name": "etc_project_number"
              },
              {
                "type": "number",
                "name": "start_year"
              },
              {
                "type": "text",
                "name": "client_name"
              },
              {
                "type": "text",
                "name": "project_status"
              },
              {
                "type": "text",
                "name": "project_timezone"
              },
              {
                "type": "number",
                "name": "is_active"
              },
              {
                "type": "text",
                "name": "created_on"
              },
              {
                "type": "number",
                "name": "created_by"
              },
              {
                "type": "text",
                "name": "updated_on"
              },
              {
                "type": "text",
                "name": "updated_by"
              }
            ]
          },
          {
            "type": "boolean",
            "name": "result"
          }
        ]
      }
    ],
    "sessionStorage": [
      {
        "type": "text",
        "name": "lead_list_update_alert"
      },
      {
        "type": "text",
        "name": "lead_list_update_project"
      }
    ],
    "apiupdate": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "number",
            "name": "project_id"
          },
          {
            "type": "boolean",
            "name": "result"
          }
        ]
      }
    ],
    "apiLeadsDetails": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "object",
            "name": "leaddata",
            "sub": [
              {
                "type": "number",
                "name": "id"
              },
              {
                "type": "number",
                "name": "response_id"
              },
              {
                "type": "text",
                "name": "date"
              },
              {
                "type": "text",
                "name": "adsource"
              },
              {
                "type": "number",
                "name": "student_status"
              },
              {
                "type": "text",
                "name": "source_project"
              },
              {
                "type": "text",
                "name": "fname"
              },
              {
                "type": "text",
                "name": "lname"
              },
              {
                "type": "text",
                "name": "email"
              },
              {
                "type": "text",
                "name": "phone"
              },
              {
                "type": "text",
                "name": "address_place"
              },
              {
                "type": "text",
                "name": "address_street"
              },
              {
                "type": "text",
                "name": "address_city"
              },
              {
                "type": "text",
                "name": "address_state"
              },
              {
                "type": "number",
                "name": "address_zip"
              },
              {
                "type": "number",
                "name": "address_lati"
              },
              {
                "type": "number",
                "name": "address_longi"
              },
              {
                "type": "text",
                "name": "howheardsrc"
              },
              {
                "type": "text",
                "name": "prefcomms"
              },
              {
                "type": "number",
                "name": "ok2sms"
              },
              {
                "type": "number",
                "name": "notifysurv"
              },
              {
                "type": "number",
                "name": "project_id"
              },
              {
                "type": "text",
                "name": "camp_resident"
              },
              {
                "type": "number",
                "name": "dormitory"
              },
              {
                "type": "text",
                "name": "dormitory_other"
              },
              {
                "type": "number",
                "name": "married_spouse"
              },
              {
                "type": "number",
                "name": "other_rommate_nonttu"
              },
              {
                "type": "number",
                "name": "live_with_parents"
              },
              {
                "type": "text",
                "name": "applinks_pin"
              },
              {
                "type": "number",
                "name": "live_in_studyarea"
              },
              {
                "type": "number",
                "name": "hh_income"
              },
              {
                "type": "number",
                "name": "hh_size"
              },
              {
                "type": "number",
                "name": "assigned_to"
              },
              {
                "type": "number",
                "name": "lead_status"
              },
              {
                "type": "text",
                "name": "created_on"
              },
              {
                "type": "number",
                "name": "created_by"
              },
              {
                "type": "text",
                "name": "updated_on"
              },
              {
                "type": "number",
                "name": "updated_by"
              }
            ]
          },
          {
            "type": "array",
            "name": "lead_history",
            "sub": [
              {
                "type": "text",
                "name": "created_on"
              },
              {
                "type": "number",
                "name": "lead_status"
              },
              {
                "type": "text",
                "name": "assign_to"
              },
              {
                "type": "text",
                "name": "action_note"
              },
              {
                "type": "text",
                "name": "lead_status_name"
              },
              {
                "type": "text",
                "name": "created_by"
              },
              {
                "type": "text",
                "name": "updatedby_name"
              }
            ]
          },
          {
            "type": "array",
            "name": "lead_review_tag",
            "sub": [
              {
                "type": "text",
                "name": "review_tag_id"
              },
              {
                "type": "text",
                "name": "created_on"
              }
            ]
          }
        ]
      }
    ],
    "apiGetproject": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "text",
            "name": "message"
          }
        ]
      }
    ],
    "apiOnUpdate": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "text",
            "name": "message"
          }
        ]
      }
    ],
    "dmx-repeat": {
      "meta": [
        {
          "type": "text",
          "name": "tag"
        },
        {
          "type": "text",
          "name": "description"
        },
        {
          "type": "number",
          "name": "status"
        }
      ],
      "outputType": "array"
    },
    "repeat1": {
      "meta": [
        {
          "type": "text",
          "name": "created_on"
        },
        {
          "type": "number",
          "name": "lead_status"
        },
        {
          "type": "number",
          "name": "assign_to"
        },
        {
          "type": "text",
          "name": "action_note"
        }
      ],
      "outputType": "array"
    },
    "apiReviewtag": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "array",
            "name": "data",
            "sub": [
              {
                "type": "number",
                "name": "id"
              },
              {
                "type": "text",
                "name": "tag"
              },
              {
                "type": "text",
                "name": "description"
              },
              {
                "type": "text",
                "name": "status"
              },
              {
                "type": "number",
                "name": "created_by"
              },
              {
                "type": "text",
                "name": "created_on"
              },
              {
                "type": "text",
                "name": "updated_on"
              },
              {
                "type": "text",
                "name": "updated_by"
              }
            ]
          }
        ]
      }
    ],
    "apilabels": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "object",
            "name": "result",
            "sub": [
              {
                "type": "object",
                "name": "general",
                "sub": [
                  {
                    "type": "text",
                    "name": "cancel"
                  },
                  {
                    "type": "text",
                    "name": "close"
                  },
                  {
                    "type": "text",
                    "name": "error"
                  },
                  {
                    "type": "text",
                    "name": "error_server"
                  },
                  {
                    "type": "text",
                    "name": "filter"
                  },
                  {
                    "type": "text",
                    "name": "no"
                  },
                  {
                    "type": "text",
                    "name": "ok"
                  },
                  {
                    "type": "text",
                    "name": "reset"
                  },
                  {
                    "type": "text",
                    "name": "save"
                  },
                  {
                    "type": "text",
                    "name": "update"
                  },
                  {
                    "type": "text",
                    "name": "yes"
                  }
                ]
              },
              {
                "type": "object",
                "name": "leads",
                "sub": [
                  {
                    "type": "object",
                    "name": "leads",
                    "sub": [
                      {
                        "type": "text",
                        "name": "about_survey"
                      },
                      {
                        "type": "text",
                        "name": "action"
                      },
                      {
                        "type": "text",
                        "name": "address"
                      },
                      {
                        "type": "text",
                        "name": "add_new_lead"
                      },
                      {
                        "type": "text",
                        "name": "apply_action"
                      },
                      {
                        "type": "text",
                        "name": "apply_selection"
                      },
                      {
                        "type": "text",
                        "name": "assigned_to"
                      },
                      {
                        "type": "text",
                        "name": "batch_assign"
                      },
                      {
                        "type": "text",
                        "name": "cancel"
                      },
                      {
                        "type": "text",
                        "name": "city"
                      },
                      {
                        "type": "text",
                        "name": "Create_batch"
                      },
                      {
                        "type": "text",
                        "name": "date"
                      },
                      {
                        "type": "text",
                        "name": "date_from"
                      },
                      {
                        "type": "text",
                        "name": "date_to"
                      },
                      {
                        "type": "text",
                        "name": "email"
                      },
                      {
                        "type": "text",
                        "name": "first_name"
                      },
                      {
                        "type": "text",
                        "name": "fname"
                      },
                      {
                        "type": "text",
                        "name": "hh_income"
                      },
                      {
                        "type": "text",
                        "name": "hh_size"
                      },
                      {
                        "type": "text",
                        "name": "id"
                      },
                      {
                        "type": "text",
                        "name": "last_name"
                      },
                      {
                        "type": "text",
                        "name": "log_history"
                      },
                      {
                        "type": "text",
                        "name": "method_of_communication"
                      },
                      {
                        "type": "text",
                        "name": "new_leads"
                      },
                      {
                        "type": "text",
                        "name": "note"
                      },
                      {
                        "type": "text",
                        "name": "phone"
                      },
                      {
                        "type": "text",
                        "name": "projects"
                      },
                      {
                        "type": "text",
                        "name": "reset_filter"
                      },
                      {
                        "type": "text",
                        "name": "review_tag"
                      },
                      {
                        "type": "text",
                        "name": "save"
                      },
                      {
                        "type": "text",
                        "name": "search"
                      },
                      {
                        "type": "text",
                        "name": "select/search"
                      },
                      {
                        "type": "text",
                        "name": "source"
                      },
                      {
                        "type": "text",
                        "name": "state"
                      },
                      {
                        "type": "text",
                        "name": "status"
                      },
                      {
                        "type": "text",
                        "name": "street_address"
                      },
                      {
                        "type": "text",
                        "name": "student"
                      },
                      {
                        "type": "text",
                        "name": "title"
                      },
                      {
                        "type": "text",
                        "name": "update"
                      },
                      {
                        "type": "text",
                        "name": "zip"
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "apiGetusers": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "array",
            "name": "result",
            "sub": [
              {
                "type": "number",
                "name": "success"
              },
              {
                "type": "object",
                "name": "data",
                "sub": [
                  {
                    "type": "number",
                    "name": "offset"
                  },
                  {
                    "type": "number",
                    "name": "limit"
                  },
                  {
                    "type": "number",
                    "name": "total"
                  },
                  {
                    "type": "object",
                    "name": "page",
                    "sub": [
                      {
                        "type": "object",
                        "name": "offset",
                        "sub": [
                          {
                            "type": "number",
                            "name": "first"
                          },
                          {
                            "type": "number",
                            "name": "prev"
                          },
                          {
                            "type": "number",
                            "name": "next"
                          },
                          {
                            "type": "number",
                            "name": "last"
                          }
                        ]
                      },
                      {
                        "type": "number",
                        "name": "current"
                      },
                      {
                        "type": "number",
                        "name": "total"
                      }
                    ]
                  },
                  {
                    "type": "array",
                    "name": "data",
                    "sub": [
                      {
                        "type": "number",
                        "name": "id"
                      },
                      {
                        "type": "text",
                        "name": "name"
                      },
                      {
                        "type": "text",
                        "name": "email"
                      },
                      {
                        "type": "text",
                        "name": "user_name"
                      },
                      {
                        "type": "number",
                        "name": "is_active"
                      },
                      {
                        "type": "text",
                        "name": "created_on"
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "tableRepeat1": {
      "meta": [
        {
          "type": "text",
          "name": "created_on"
        },
        {
          "type": "number",
          "name": "lead_status"
        },
        {
          "type": "text",
          "name": "assign_to"
        },
        {
          "type": "text",
          "name": "action_note"
        },
        {
          "type": "text",
          "name": "lead_status_name"
        },
        {
          "type": "text",
          "name": "created_by"
        },
        {
          "type": "text",
          "name": "updatedby_name"
        }
      ],
      "outputType": "array"
    },
    "varUsername": {
      "meta": null,
      "outputType": "text"
    },
    "apiUpdate": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "object",
            "name": "pages",
            "sub": [
              {
                "type": "object",
                "name": "page1",
                "sub": [
                  {
                    "type": "text",
                    "name": "id"
                  },
                  {
                    "type": "object",
                    "name": "questions",
                    "sub": [
                      {
                        "type": "object",
                        "name": "address",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "bound_ne_lat"
                          },
                          {
                            "type": "text",
                            "name": "bound_ne_lng"
                          },
                          {
                            "type": "text",
                            "name": "bound_sw_lat"
                          },
                          {
                            "type": "text",
                            "name": "bound_sw_lng"
                          },
                          {
                            "type": "text",
                            "name": "dbfields"
                          },
                          {
                            "type": "text",
                            "name": "init_lat"
                          },
                          {
                            "type": "text",
                            "name": "init_lng"
                          },
                          {
                            "type": "text",
                            "name": "init_zoom"
                          },
                          {
                            "type": "text",
                            "name": "required"
                          },
                          {
                            "type": "text",
                            "name": "seq"
                          },
                          {
                            "type": "text",
                            "name": "show"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "allow_incentive",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "correct_address",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "optioncols"
                          },
                          {
                            "type": "text",
                            "name": "required"
                          },
                          {
                            "type": "text",
                            "name": "seq"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "district_code",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "from",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "hh_address",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "hh_county",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "hh_latitude",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "hh_longitute",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "hh_pin",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "hh_state",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "hh_studyarea",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "hh_welcome_income",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "optioncols"
                          },
                          {
                            "type": "text",
                            "name": "required"
                          },
                          {
                            "type": "text",
                            "name": "seq"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "hh_welcome_number_employed",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "optioncols"
                          },
                          {
                            "type": "text",
                            "name": "required"
                          },
                          {
                            "type": "text",
                            "name": "seq"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "hh_zipcode",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "id",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "number_persons",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "optioncols"
                          },
                          {
                            "type": "text",
                            "name": "required"
                          },
                          {
                            "type": "text",
                            "name": "seq"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "other_hh_county",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      },
                      {
                        "type": "object",
                        "name": "sample_number",
                        "sub": [
                          {
                            "type": "text",
                            "name": "id"
                          },
                          {
                            "type": "text",
                            "name": "type"
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "text",
                    "name": "nextpage"
                  }
                ]
              }
            ]
          },
          {
            "type": "key_array",
            "name": "labels",
            "sub": [
              {
                "type": "text",
                "name": "qtext"
              },
              {
                "type": "text",
                "name": "required"
              }
            ]
          },
          {
            "type": "object",
            "name": "options",
            "sub": [
              {
                "type": "array",
                "name": "correct_address",
                "sub": [
                  {
                    "type": "text",
                    "name": "key"
                  },
                  {
                    "type": "text",
                    "name": "text"
                  },
                  {
                    "type": "number",
                    "name": "seq"
                  }
                ]
              },
              {
                "type": "array",
                "name": "number_persons",
                "sub": [
                  {
                    "type": "text",
                    "name": "key"
                  },
                  {
                    "type": "text",
                    "name": "text"
                  },
                  {
                    "type": "number",
                    "name": "seq"
                  }
                ]
              },
              {
                "type": "array",
                "name": "hh_welcome_number_employed",
                "sub": [
                  {
                    "type": "text",
                    "name": "key"
                  },
                  {
                    "type": "text",
                    "name": "text"
                  },
                  {
                    "type": "number",
                    "name": "seq"
                  }
                ]
              },
              {
                "type": "array",
                "name": "hh_welcome_income",
                "sub": [
                  {
                    "type": "text",
                    "name": "key"
                  },
                  {
                    "type": "text",
                    "name": "text"
                  },
                  {
                    "type": "number",
                    "name": "seq"
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "apiSurveyJson": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "text",
            "name": "currentpage"
          },
          {
            "type": "text",
            "name": "nextpage"
          },
          {
            "type": "object",
            "name": "pages",
            "sub": [
              {
                "type": "object",
                "name": "page1",
                "sub": [
                  {
                    "type": "text",
                    "name": "id"
                  },
                  {
                    "type": "key_array",
                    "name": "questions",
                    "sub": [
                      {
                        "type": "text",
                        "name": "id"
                      },
                      {
                        "type": "text",
                        "name": "type"
                      },
                      {
                        "type": "text",
                        "name": "required"
                      }
                    ]
                  }
                ]
              }
            ]
          },
          {
            "type": "object",
            "name": "labels",
            "sub": [
              {
                "type": "object",
                "name": "emaildnr",
                "sub": [
                  {
                    "type": "text",
                    "name": "qtext"
                  },
                  {
                    "type": "text",
                    "name": "placeholder"
                  },
                  {
                    "type": "text",
                    "name": "required"
                  },
                  {
                    "type": "text",
                    "name": "dontknow"
                  },
                  {
                    "type": "text",
                    "name": "refuse"
                  }
                ]
              },
              {
                "type": "object",
                "name": "email",
                "sub": [
                  {
                    "type": "text",
                    "name": "qtext"
                  },
                  {
                    "type": "text",
                    "name": "placeholder"
                  },
                  {
                    "type": "text",
                    "name": "required"
                  }
                ]
              },
              {
                "type": "object",
                "name": "gmap1",
                "sub": [
                  {
                    "type": "text",
                    "name": "qtext"
                  },
                  {
                    "type": "text",
                    "name": "placeholder"
                  },
                  {
                    "type": "text",
                    "name": "required"
                  }
                ]
              },
              {
                "type": "object",
                "name": "textonly",
                "sub": [
                  {
                    "type": "text",
                    "name": "qtext"
                  },
                  {
                    "type": "text",
                    "name": "placeholder"
                  },
                  {
                    "type": "text",
                    "name": "required"
                  }
                ]
              },
              {
                "type": "object",
                "name": "textdnr",
                "sub": [
                  {
                    "type": "text",
                    "name": "qtext"
                  },
                  {
                    "type": "text",
                    "name": "placeholder"
                  },
                  {
                    "type": "text",
                    "name": "required"
                  },
                  {
                    "type": "text",
                    "name": "dontknow"
                  },
                  {
                    "type": "text",
                    "name": "refuse"
                  }
                ]
              },
              {
                "type": "object",
                "name": "number",
                "sub": [
                  {
                    "type": "text",
                    "name": "qtext"
                  },
                  {
                    "type": "text",
                    "name": "placeholder"
                  },
                  {
                    "type": "text",
                    "name": "required"
                  },
                  {
                    "type": "text",
                    "name": "validmin"
                  },
                  {
                    "type": "text",
                    "name": "validmax"
                  }
                ]
              },
              {
                "type": "object",
                "name": "numberdnr",
                "sub": [
                  {
                    "type": "text",
                    "name": "qtext"
                  },
                  {
                    "type": "text",
                    "name": "placeholder"
                  },
                  {
                    "type": "text",
                    "name": "required"
                  },
                  {
                    "type": "text",
                    "name": "validmin"
                  },
                  {
                    "type": "text",
                    "name": "validmax"
                  },
                  {
                    "type": "text",
                    "name": "dontknow"
                  },
                  {
                    "type": "text",
                    "name": "refuse"
                  }
                ]
              },
              {
                "type": "object",
                "name": "radiocol1",
                "sub": [
                  {
                    "type": "text",
                    "name": "qtext"
                  },
                  {
                    "type": "text",
                    "name": "required"
                  }
                ]
              },
              {
                "type": "object",
                "name": "radioothercol1",
                "sub": [
                  {
                    "type": "text",
                    "name": "qtext"
                  },
                  {
                    "type": "text",
                    "name": "required"
                  },
                  {
                    "type": "text",
                    "name": "requiredother"
                  },
                  {
                    "type": "text",
                    "name": "placeholderother"
                  }
                ]
              },
              {
                "type": "object",
                "name": "checkboxcol1",
                "sub": [
                  {
                    "type": "text",
                    "name": "qtext"
                  },
                  {
                    "type": "text",
                    "name": "required"
                  }
                ]
              },
              {
                "type": "object",
                "name": "checkboxothercol1",
                "sub": [
                  {
                    "type": "text",
                    "name": "qtext"
                  },
                  {
                    "type": "text",
                    "name": "required"
                  },
                  {
                    "type": "text",
                    "name": "requiredother"
                  },
                  {
                    "type": "text",
                    "name": "placeholderother"
                  }
                ]
              },
              {
                "type": "object",
                "name": "datepicker",
                "sub": [
                  {
                    "type": "text",
                    "name": "qtext"
                  },
                  {
                    "type": "text",
                    "name": "placeholder"
                  },
                  {
                    "type": "text",
                    "name": "required"
                  }
                ]
              },
              {
                "type": "object",
                "name": "timepicker",
                "sub": [
                  {
                    "type": "text",
                    "name": "qtext"
                  },
                  {
                    "type": "text",
                    "name": "placeholder"
                  },
                  {
                    "type": "text",
                    "name": "required"
                  }
                ]
              },
              {
                "type": "object",
                "name": "autocomplete1",
                "sub": [
                  {
                    "type": "text",
                    "name": "qtext"
                  },
                  {
                    "type": "text",
                    "name": "placeholder"
                  },
                  {
                    "type": "text",
                    "name": "required"
                  }
                ]
              },
              {
                "type": "object",
                "name": "gplacesearch1",
                "sub": [
                  {
                    "type": "text",
                    "name": "qtext"
                  },
                  {
                    "type": "text",
                    "name": "placeholder"
                  },
                  {
                    "type": "text",
                    "name": "required"
                  }
                ]
              },
              {
                "type": "object",
                "name": "gmapcombine",
                "sub": [
                  {
                    "type": "text",
                    "name": "qtext"
                  },
                  {
                    "type": "text",
                    "name": "required"
                  }
                ]
              },
              {
                "type": "object",
                "name": "gplacesearchcombine",
                "sub": [
                  {
                    "type": "text",
                    "name": "qtext"
                  },
                  {
                    "type": "text",
                    "name": "placeholder"
                  },
                  {
                    "type": "text",
                    "name": "required"
                  }
                ]
              }
            ]
          },
          {
            "type": "object",
            "name": "options",
            "sub": [
              {
                "type": "array",
                "name": "radiocol1",
                "sub": [
                  {
                    "type": "text",
                    "name": "key"
                  },
                  {
                    "type": "text",
                    "name": "text"
                  },
                  {
                    "type": "number",
                    "name": "seq"
                  }
                ]
              },
              {
                "type": "array",
                "name": "radioothercol1",
                "sub": [
                  {
                    "type": "text",
                    "name": "key"
                  },
                  {
                    "type": "text",
                    "name": "text"
                  },
                  {
                    "type": "number",
                    "name": "seq"
                  }
                ]
              },
              {
                "type": "array",
                "name": "checkboxcol1",
                "sub": [
                  {
                    "type": "text",
                    "name": "key"
                  },
                  {
                    "type": "text",
                    "name": "text"
                  },
                  {
                    "type": "number",
                    "name": "seq"
                  }
                ]
              },
              {
                "type": "array",
                "name": "checkboxothercol1",
                "sub": [
                  {
                    "type": "text",
                    "name": "key"
                  },
                  {
                    "type": "text",
                    "name": "text"
                  },
                  {
                    "type": "number",
                    "name": "seq"
                  }
                ]
              }
            ]
          },
          {
            "type": "object",
            "name": "answers",
            "sub": [
              {
                "type": "text",
                "name": "textonly"
              },
              {
                "type": "text",
                "name": "textdnr"
              },
              {
                "type": "text",
                "name": "textdnr_dontknow"
              },
              {
                "type": "text",
                "name": "textdnr_refuse"
              },
              {
                "type": "text",
                "name": "number"
              },
              {
                "type": "text",
                "name": "numberdnr"
              },
              {
                "type": "text",
                "name": "numberdnr_dontknow"
              },
              {
                "type": "text",
                "name": "numberdnr_refuse"
              },
              {
                "type": "text",
                "name": "radiocol1"
              },
              {
                "type": "text",
                "name": "radioothercol1"
              },
              {
                "type": "text",
                "name": "radioothercol1_other"
              },
              {
                "type": "text",
                "name": "checkboxcol1"
              },
              {
                "type": "text",
                "name": "checkboxothercol1"
              },
              {
                "type": "text",
                "name": "checkboxothercol1_other"
              },
              {
                "type": "text",
                "name": "gmap1_placename"
              },
              {
                "type": "text",
                "name": "gmap1_address"
              },
              {
                "type": "text",
                "name": "gmap1_city"
              },
              {
                "type": "text",
                "name": "gmap1_state"
              },
              {
                "type": "text",
                "name": "gmap1_zip"
              },
              {
                "type": "text",
                "name": "gmap1_county"
              },
              {
                "type": "text",
                "name": "gmap1_studyarea"
              },
              {
                "type": "text",
                "name": "gmap1_country"
              },
              {
                "type": "text",
                "name": "gmap1_lat"
              },
              {
                "type": "text",
                "name": "gmap1_lng"
              },
              {
                "type": "text",
                "name": "datepicker"
              },
              {
                "type": "text",
                "name": "timepicker"
              },
              {
                "type": "text",
                "name": "autocomplete1"
              },
              {
                "type": "text",
                "name": "gplacesearch"
              },
              {
                "type": "text",
                "name": "email"
              },
              {
                "type": "text",
                "name": "emaildnr"
              },
              {
                "type": "text",
                "name": "emaildnr_dontknow"
              },
              {
                "type": "text",
                "name": "emaildnr_refuse"
              }
            ]
          }
        ]
      }
    ],
    "etcsradioc21_repeat_c1": {
      "meta": null,
      "outputType": "opject"
    }
  },
  "admin": {
    "localStorage": [
      {
        "type": "text",
        "name": "admin_projects_list_project_name"
      },
      {
        "type": "text",
        "name": "admin_projects_list_etc_project_number"
      },
      {
        "type": "text",
        "name": "admin_projects_list_project_code"
      },
      {
        "type": "text",
        "name": "admin_projects_list_start_year"
      },
      {
        "type": "text",
        "name": "admin_projects_list_active"
      },
      {
        "type": "text",
        "name": "admin_projects_list_status"
      },
      {
        "type": "text",
        "name": "admin_projects_list_pageoffset"
      },
      {
        "type": "text",
        "name": "token"
      },
      {
        "type": "text",
        "name": "userid"
      },
      {
        "type": "text",
        "name": "admin_user_list_user_name"
      },
      {
        "type": "text",
        "name": "admin_user_list_name"
      },
      {
        "type": "text",
        "name": "admin_user_list_user_email"
      },
      {
        "type": "text",
        "name": "admin_user_list_user_id"
      },
      {
        "type": "text",
        "name": "admin_user_list_pageoffset"
      },
      {
        "type": "text",
        "name": "leads_list_fname"
      }
    ]
  },
  "user_list": {
    "apiUserTable": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "array",
            "name": "result",
            "sub": [
              {
                "type": "number",
                "name": "success"
              },
              {
                "type": "object",
                "name": "data",
                "sub": [
                  {
                    "type": "number",
                    "name": "offset"
                  },
                  {
                    "type": "number",
                    "name": "limit"
                  },
                  {
                    "type": "number",
                    "name": "total"
                  },
                  {
                    "type": "object",
                    "name": "page",
                    "sub": [
                      {
                        "type": "object",
                        "name": "offset",
                        "sub": [
                          {
                            "type": "number",
                            "name": "first"
                          },
                          {
                            "type": "number",
                            "name": "prev"
                          },
                          {
                            "type": "number",
                            "name": "next"
                          },
                          {
                            "type": "number",
                            "name": "last"
                          }
                        ]
                      },
                      {
                        "type": "number",
                        "name": "current"
                      },
                      {
                        "type": "number",
                        "name": "total"
                      }
                    ]
                  },
                  {
                    "type": "array",
                    "name": "data",
                    "sub": [
                      {
                        "type": "number",
                        "name": "id"
                      },
                      {
                        "type": "text",
                        "name": "name"
                      },
                      {
                        "type": "text",
                        "name": "email"
                      },
                      {
                        "type": "text",
                        "name": "user_name"
                      },
                      {
                        "type": "number",
                        "name": "is_active"
                      },
                      {
                        "type": "text",
                        "name": "created_on"
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "tableRepeat2": {
      "meta": [
        {
          "type": "number",
          "name": "id"
        },
        {
          "type": "text",
          "name": "name"
        },
        {
          "type": "text",
          "name": "email"
        },
        {
          "type": "text",
          "name": "user_name"
        },
        {
          "type": "number",
          "name": "is_active"
        },
        {
          "type": "text",
          "name": "created_on"
        }
      ],
      "outputType": "array"
    },
    "sessionStorage": [
      {
        "type": "text",
        "name": "user_list_create_alert"
      },
      {
        "type": "text",
        "name": "user_list_create"
      },
      {
        "type": "text",
        "name": "user_update"
      },
      {
        "type": "text",
        "name": "user_update_alert"
      }
    ],
    "flowOnActive": [
      {
        "name": "$param",
        "type": "object",
        "sub": [
          {
            "type": "text",
            "name": "user_id"
          },
          {
            "type": "text",
            "name": "is_active"
          }
        ]
      }
    ],
    "localStorage": [
      {
        "type": "text",
        "name": "admin_projects_list_pageoffset"
      },
      {
        "type": "text",
        "name": "admin_user_list_user_name"
      },
      {
        "type": "text",
        "name": "admin_user_list_name"
      },
      {
        "type": "text",
        "name": "admin_user_list_user_email"
      },
      {
        "type": "text",
        "name": "admin_user_list_user_id"
      }
    ],
    "apiLabels": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "object",
            "name": "result",
            "sub": [
              {
                "type": "object",
                "name": "general",
                "sub": [
                  {
                    "type": "text",
                    "name": "cancel"
                  },
                  {
                    "type": "text",
                    "name": "close"
                  },
                  {
                    "type": "text",
                    "name": "error"
                  },
                  {
                    "type": "text",
                    "name": "error_server"
                  },
                  {
                    "type": "text",
                    "name": "filter"
                  },
                  {
                    "type": "text",
                    "name": "no"
                  },
                  {
                    "type": "text",
                    "name": "ok"
                  },
                  {
                    "type": "text",
                    "name": "reset"
                  },
                  {
                    "type": "text",
                    "name": "save"
                  },
                  {
                    "type": "text",
                    "name": "update"
                  },
                  {
                    "type": "text",
                    "name": "yes"
                  }
                ]
              },
              {
                "type": "object",
                "name": "users",
                "sub": [
                  {
                    "type": "object",
                    "name": "users",
                    "sub": [
                      {
                        "type": "text",
                        "name": "action"
                      },
                      {
                        "type": "text",
                        "name": "add_user"
                      },
                      {
                        "type": "text",
                        "name": "confirm_password"
                      },
                      {
                        "type": "text",
                        "name": "created_on"
                      },
                      {
                        "type": "text",
                        "name": "email"
                      },
                      {
                        "type": "text",
                        "name": "id"
                      },
                      {
                        "type": "text",
                        "name": "is_active"
                      },
                      {
                        "type": "text",
                        "name": "name"
                      },
                      {
                        "type": "text",
                        "name": "new_password"
                      },
                      {
                        "type": "text",
                        "name": "permissions"
                      },
                      {
                        "type": "text",
                        "name": "reset_password"
                      },
                      {
                        "type": "text",
                        "name": "roles"
                      },
                      {
                        "type": "text",
                        "name": "title"
                      },
                      {
                        "type": "text",
                        "name": "update_user"
                      },
                      {
                        "type": "text",
                        "name": "users"
                      },
                      {
                        "type": "text",
                        "name": "user_name"
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "apiActive": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "text",
            "name": "message"
          }
        ]
      }
    ]
  },
  "user_create": {
    "apiUserCreate": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "text",
            "name": "message"
          },
          {
            "type": "boolean",
            "name": "result"
          }
        ]
      }
    ],
    "repeat1": {
      "meta": null,
      "outputType": "text"
    },
    "apigetproject": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "object",
            "name": "query",
            "sub": [
              {
                "type": "number",
                "name": "offset"
              },
              {
                "type": "number",
                "name": "limit"
              },
              {
                "type": "number",
                "name": "total"
              },
              {
                "type": "object",
                "name": "page",
                "sub": [
                  {
                    "type": "object",
                    "name": "offset",
                    "sub": [
                      {
                        "type": "number",
                        "name": "first"
                      },
                      {
                        "type": "number",
                        "name": "prev"
                      },
                      {
                        "type": "number",
                        "name": "next"
                      },
                      {
                        "type": "number",
                        "name": "last"
                      }
                    ]
                  },
                  {
                    "type": "number",
                    "name": "current"
                  },
                  {
                    "type": "number",
                    "name": "total"
                  }
                ]
              },
              {
                "type": "array",
                "name": "data",
                "sub": [
                  {
                    "type": "number",
                    "name": "project_id"
                  },
                  {
                    "type": "text",
                    "name": "project_name"
                  },
                  {
                    "type": "text",
                    "name": "project_code"
                  },
                  {
                    "type": "text",
                    "name": "etc_project_number"
                  },
                  {
                    "type": "number",
                    "name": "start_year"
                  },
                  {
                    "type": "text",
                    "name": "client_name"
                  },
                  {
                    "type": "text",
                    "name": "project_status"
                  },
                  {
                    "type": "number",
                    "name": "is_active"
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "sessionStorage": [
      {
        "type": "text",
        "name": "user_list_create_alert"
      },
      {
        "type": "text",
        "name": "user_list_create"
      }
    ],
    "apiRoles": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "array",
            "name": "data",
            "sub": [
              {
                "type": "number",
                "name": "role_id"
              },
              {
                "type": "text",
                "name": "role_name"
              },
              {
                "type": "text",
                "name": "role_description"
              },
              {
                "type": "text",
                "name": "created_on"
              },
              {
                "type": "text",
                "name": "created_by"
              },
              {
                "type": "text",
                "name": "updated_on"
              },
              {
                "type": "text",
                "name": "updated_by"
              }
            ]
          }
        ]
      }
    ],
    "apiPermission": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "object",
            "name": "data",
            "sub": [
              {
                "type": "number",
                "name": "permission_id"
              },
              {
                "type": "text",
                "name": "permission_name"
              },
              {
                "type": "text",
                "name": "permission_description"
              },
              {
                "type": "text",
                "name": "category"
              },
              {
                "type": "text",
                "name": "created_on"
              },
              {
                "type": "number",
                "name": "created_by"
              },
              {
                "type": "text",
                "name": "updated_by"
              },
              {
                "type": "text",
                "name": "updated_on"
              }
            ]
          }
        ]
      }
    ],
    "dmx-repeat": {
      "meta": [
        {
          "name": "$index",
          "type": "number"
        },
        {
          "name": "$key",
          "type": "text"
        },
        {
          "name": "$value",
          "type": "object"
        },
        {
          "type": "number",
          "name": "project_id"
        },
        {
          "type": "text",
          "name": "project_name"
        },
        {
          "type": "text",
          "name": "project_code"
        },
        {
          "type": "text",
          "name": "etc_project_number"
        },
        {
          "type": "number",
          "name": "start_year"
        },
        {
          "type": "text",
          "name": "client_name"
        },
        {
          "type": "text",
          "name": "project_status"
        },
        {
          "type": "number",
          "name": "is_active"
        }
      ],
      "outputType": "array"
    },
    "dmx-repeatrole": {
      "meta": [
        {
          "type": "number",
          "name": "role_id"
        },
        {
          "type": "text",
          "name": "role_name"
        },
        {
          "type": "text",
          "name": "role_description"
        },
        {
          "type": "text",
          "name": "created_on"
        },
        {
          "type": "text",
          "name": "created_by"
        },
        {
          "type": "text",
          "name": "updated_on"
        },
        {
          "type": "text",
          "name": "updated_by"
        }
      ],
      "outputType": "array"
    },
    "dmx-repeat-permission": {
      "meta": [
        {
          "type": "number",
          "name": "permission_id"
        },
        {
          "type": "text",
          "name": "permission_name"
        },
        {
          "type": "text",
          "name": "permission_description"
        },
        {
          "type": "text",
          "name": "category"
        },
        {
          "type": "text",
          "name": "created_on"
        },
        {
          "type": "number",
          "name": "created_by"
        },
        {
          "type": "text",
          "name": "updated_by"
        },
        {
          "type": "text",
          "name": "updated_on"
        }
      ],
      "outputType": "object"
    },
    "flowOnCreateResponse": [
      {
        "name": "debugValue",
        "type": "text"
      }
    ],
    "apilabels": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "object",
            "name": "result",
            "sub": [
              {
                "type": "object",
                "name": "general",
                "sub": [
                  {
                    "type": "text",
                    "name": "cancel"
                  },
                  {
                    "type": "text",
                    "name": "close"
                  },
                  {
                    "type": "text",
                    "name": "error"
                  },
                  {
                    "type": "text",
                    "name": "error_server"
                  },
                  {
                    "type": "text",
                    "name": "filter"
                  },
                  {
                    "type": "text",
                    "name": "no"
                  },
                  {
                    "type": "text",
                    "name": "ok"
                  },
                  {
                    "type": "text",
                    "name": "reset"
                  },
                  {
                    "type": "text",
                    "name": "save"
                  },
                  {
                    "type": "text",
                    "name": "update"
                  },
                  {
                    "type": "text",
                    "name": "yes"
                  }
                ]
              },
              {
                "type": "object",
                "name": "users",
                "sub": [
                  {
                    "type": "object",
                    "name": "users",
                    "sub": [
                      {
                        "type": "text",
                        "name": "action"
                      },
                      {
                        "type": "text",
                        "name": "add_user"
                      },
                      {
                        "type": "text",
                        "name": "confirm_password"
                      },
                      {
                        "type": "text",
                        "name": "created_on"
                      },
                      {
                        "type": "text",
                        "name": "email"
                      },
                      {
                        "type": "text",
                        "name": "id"
                      },
                      {
                        "type": "text",
                        "name": "is_active"
                      },
                      {
                        "type": "text",
                        "name": "name"
                      },
                      {
                        "type": "text",
                        "name": "new_password"
                      },
                      {
                        "type": "text",
                        "name": "permissions"
                      },
                      {
                        "type": "text",
                        "name": "reset_password"
                      },
                      {
                        "type": "text",
                        "name": "roles"
                      },
                      {
                        "type": "text",
                        "name": "title"
                      },
                      {
                        "type": "text",
                        "name": "update_user"
                      },
                      {
                        "type": "text",
                        "name": "users"
                      },
                      {
                        "type": "text",
                        "name": "user_name"
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "varUsername": {
      "meta": null,
      "outputType": "object"
    }
  },
  "user_update": {
    "apiuserdetails": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "object",
            "name": "data",
            "sub": [
              {
                "type": "number",
                "name": "id"
              },
              {
                "type": "text",
                "name": "name"
              },
              {
                "type": "text",
                "name": "email"
              },
              {
                "type": "text",
                "name": "user_name"
              },
              {
                "type": "text",
                "name": "role_id"
              },
              {
                "type": "number",
                "name": "is_active"
              },
              {
                "type": "text",
                "name": "created_on"
              },
              {
                "type": "text",
                "name": "created_by"
              },
              {
                "type": "text",
                "name": "updated_on"
              },
              {
                "type": "text",
                "name": "updated_by"
              },
              {
                "type": "array",
                "name": "projects"
              },
              {
                "type": "array",
                "name": "permissions"
              }
            ]
          }
        ]
      }
    ],
    "apiUserdetails": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "object",
            "name": "data",
            "sub": [
              {
                "type": "number",
                "name": "id"
              },
              {
                "type": "text",
                "name": "name"
              },
              {
                "type": "text",
                "name": "email"
              },
              {
                "type": "text",
                "name": "user_name"
              },
              {
                "type": "number",
                "name": "role_id"
              },
              {
                "type": "number",
                "name": "is_active"
              },
              {
                "type": "text",
                "name": "created_on"
              },
              {
                "type": "number",
                "name": "created_by"
              },
              {
                "type": "text",
                "name": "updated_on"
              },
              {
                "type": "text",
                "name": "updated_by"
              },
              {
                "type": "array",
                "name": "projects",
                "sub": [
                  {
                    "type": "number",
                    "name": "user_project_id"
                  },
                  {
                    "type": "number",
                    "name": "user_id"
                  },
                  {
                    "type": "number",
                    "name": "project_id"
                  },
                  {
                    "type": "text",
                    "name": "created_on"
                  },
                  {
                    "type": "number",
                    "name": "created_by"
                  },
                  {
                    "type": "text",
                    "name": "updated_on"
                  },
                  {
                    "type": "text",
                    "name": "updated_by"
                  }
                ]
              },
              {
                "type": "array",
                "name": "permissions",
                "sub": [
                  {
                    "type": "number",
                    "name": "user_permissions_id"
                  },
                  {
                    "type": "number",
                    "name": "user_id"
                  },
                  {
                    "type": "number",
                    "name": "permission_id"
                  },
                  {
                    "type": "text",
                    "name": "created_on"
                  },
                  {
                    "type": "number",
                    "name": "created_by"
                  },
                  {
                    "type": "text",
                    "name": "updated_on"
                  },
                  {
                    "type": "text",
                    "name": "updated_by"
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "apiPermission": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "object",
            "name": "data",
            "sub": [
              {
                "type": "number",
                "name": "permission_id"
              },
              {
                "type": "text",
                "name": "permission_name"
              },
              {
                "type": "text",
                "name": "permission_description"
              },
              {
                "type": "text",
                "name": "category"
              },
              {
                "type": "text",
                "name": "created_on"
              },
              {
                "type": "number",
                "name": "created_by"
              },
              {
                "type": "text",
                "name": "updated_by"
              },
              {
                "type": "text",
                "name": "updated_on"
              }
            ]
          }
        ]
      }
    ],
    "apiRoles": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "object",
            "name": "data",
            "sub": [
              {
                "type": "number",
                "name": "role_id"
              },
              {
                "type": "text",
                "name": "role_name"
              },
              {
                "type": "text",
                "name": "role_description"
              },
              {
                "type": "text",
                "name": "created_on"
              },
              {
                "type": "number",
                "name": "created_by"
              },
              {
                "type": "text",
                "name": "updated_on"
              },
              {
                "type": "text",
                "name": "updated_by"
              }
            ]
          }
        ]
      }
    ],
    "apigetproject": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "object",
            "name": "query",
            "sub": [
              {
                "type": "number",
                "name": "offset"
              },
              {
                "type": "number",
                "name": "limit"
              },
              {
                "type": "number",
                "name": "total"
              },
              {
                "type": "object",
                "name": "page",
                "sub": [
                  {
                    "type": "object",
                    "name": "offset",
                    "sub": [
                      {
                        "type": "number",
                        "name": "first"
                      },
                      {
                        "type": "number",
                        "name": "prev"
                      },
                      {
                        "type": "number",
                        "name": "next"
                      },
                      {
                        "type": "number",
                        "name": "last"
                      }
                    ]
                  },
                  {
                    "type": "number",
                    "name": "current"
                  },
                  {
                    "type": "number",
                    "name": "total"
                  }
                ]
              },
              {
                "type": "array",
                "name": "data",
                "sub": [
                  {
                    "type": "number",
                    "name": "project_id"
                  },
                  {
                    "type": "text",
                    "name": "project_name"
                  },
                  {
                    "type": "text",
                    "name": "project_code"
                  },
                  {
                    "type": "text",
                    "name": "etc_project_number"
                  },
                  {
                    "type": "number",
                    "name": "start_year"
                  },
                  {
                    "type": "text",
                    "name": "client_name"
                  },
                  {
                    "type": "text",
                    "name": "project_status"
                  },
                  {
                    "type": "number",
                    "name": "is_active"
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "tableRepeat1": {
      "meta": [
        {
          "name": "$index",
          "type": "number"
        },
        {
          "name": "$key",
          "type": "text"
        },
        {
          "name": "$value",
          "type": "object"
        },
        {
          "type": "number",
          "name": "project_id"
        },
        {
          "type": "text",
          "name": "project_name"
        },
        {
          "type": "text",
          "name": "project_code"
        },
        {
          "type": "text",
          "name": "etc_project_number"
        },
        {
          "type": "number",
          "name": "start_year"
        },
        {
          "type": "text",
          "name": "client_name"
        },
        {
          "type": "text",
          "name": "project_status"
        },
        {
          "type": "number",
          "name": "is_active"
        }
      ],
      "outputType": "array"
    },
    "apiGetuserproject": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "array",
            "name": "data",
            "sub": [
              {
                "type": "number",
                "name": "project_id"
              },
              {
                "type": "text",
                "name": "project_name"
              },
              {
                "type": "text",
                "name": "project_description"
              },
              {
                "type": "text",
                "name": "project_code"
              },
              {
                "type": "text",
                "name": "etc_project_number"
              },
              {
                "type": "number",
                "name": "start_year"
              },
              {
                "type": "text",
                "name": "client_name"
              },
              {
                "type": "text",
                "name": "project_status"
              },
              {
                "type": "text",
                "name": "project_timezone"
              },
              {
                "type": "number",
                "name": "is_active"
              },
              {
                "type": "text",
                "name": "created_on"
              },
              {
                "type": "number",
                "name": "created_by"
              },
              {
                "type": "text",
                "name": "updated_on"
              },
              {
                "type": "text",
                "name": "updated_by"
              },
              {
                "type": "number",
                "name": "user_project_id"
              },
              {
                "type": "number",
                "name": "user_id"
              }
            ]
          }
        ]
      }
    ],
    "apiUpdate": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "text",
            "name": "message"
          },
          {
            "type": "boolean",
            "name": "result"
          }
        ]
      }
    ],
    "sessionStorage": [
      {
        "type": "text",
        "name": "user_update"
      },
      {
        "type": "text",
        "name": "user_update_alert"
      }
    ],
    "apiGeProjectbyUserid": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "array",
            "name": "data",
            "sub": [
              {
                "type": "number",
                "name": "project_id"
              },
              {
                "type": "text",
                "name": "project_name"
              },
              {
                "type": "text",
                "name": "project_description"
              },
              {
                "type": "text",
                "name": "project_code"
              },
              {
                "type": "text",
                "name": "etc_project_number"
              },
              {
                "type": "number",
                "name": "start_year"
              },
              {
                "type": "text",
                "name": "client_name"
              },
              {
                "type": "text",
                "name": "project_status"
              },
              {
                "type": "text",
                "name": "project_timezone"
              },
              {
                "type": "number",
                "name": "is_active"
              },
              {
                "type": "text",
                "name": "created_on"
              },
              {
                "type": "number",
                "name": "created_by"
              },
              {
                "type": "text",
                "name": "updated_on"
              },
              {
                "type": "text",
                "name": "updated_by"
              },
              {
                "type": "number",
                "name": "user_project_id"
              },
              {
                "type": "number",
                "name": "user_id"
              }
            ]
          }
        ]
      }
    ],
    "dmx-repeat": {
      "meta": [
        {
          "name": "$index",
          "type": "number"
        },
        {
          "name": "$key",
          "type": "text"
        },
        {
          "name": "$value",
          "type": "object"
        },
        {
          "type": "number",
          "name": "project_id"
        },
        {
          "type": "text",
          "name": "project_name"
        },
        {
          "type": "text",
          "name": "project_code"
        },
        {
          "type": "text",
          "name": "etc_project_number"
        },
        {
          "type": "number",
          "name": "start_year"
        },
        {
          "type": "text",
          "name": "client_name"
        },
        {
          "type": "text",
          "name": "project_status"
        },
        {
          "type": "number",
          "name": "is_active"
        }
      ],
      "outputType": "array"
    },
    "varSelProjs": {
      "meta": null,
      "outputType": "number"
    },
    "apilabels": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "object",
            "name": "result",
            "sub": [
              {
                "type": "object",
                "name": "general",
                "sub": [
                  {
                    "type": "text",
                    "name": "cancel"
                  },
                  {
                    "type": "text",
                    "name": "close"
                  },
                  {
                    "type": "text",
                    "name": "error"
                  },
                  {
                    "type": "text",
                    "name": "error_server"
                  },
                  {
                    "type": "text",
                    "name": "filter"
                  },
                  {
                    "type": "text",
                    "name": "no"
                  },
                  {
                    "type": "text",
                    "name": "ok"
                  },
                  {
                    "type": "text",
                    "name": "reset"
                  },
                  {
                    "type": "text",
                    "name": "save"
                  },
                  {
                    "type": "text",
                    "name": "update"
                  },
                  {
                    "type": "text",
                    "name": "yes"
                  }
                ]
              },
              {
                "type": "object",
                "name": "users",
                "sub": [
                  {
                    "type": "object",
                    "name": "users",
                    "sub": [
                      {
                        "type": "text",
                        "name": "action"
                      },
                      {
                        "type": "text",
                        "name": "add_user"
                      },
                      {
                        "type": "text",
                        "name": "confirm_password"
                      },
                      {
                        "type": "text",
                        "name": "created_on"
                      },
                      {
                        "type": "text",
                        "name": "email"
                      },
                      {
                        "type": "text",
                        "name": "id"
                      },
                      {
                        "type": "text",
                        "name": "is_active"
                      },
                      {
                        "type": "text",
                        "name": "name"
                      },
                      {
                        "type": "text",
                        "name": "new_password"
                      },
                      {
                        "type": "text",
                        "name": "permissions"
                      },
                      {
                        "type": "text",
                        "name": "reset_password"
                      },
                      {
                        "type": "text",
                        "name": "roles"
                      },
                      {
                        "type": "text",
                        "name": "title"
                      },
                      {
                        "type": "text",
                        "name": "update_user"
                      },
                      {
                        "type": "text",
                        "name": "users"
                      },
                      {
                        "type": "text",
                        "name": "user_name"
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "varUsername": {
      "meta": null,
      "outputType": "text"
    }
  },
  "user_reset_password": {
    "apiUpdatePassword": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "text",
            "name": "message"
          }
        ]
      }
    ],
    "apiUserdetails": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "boolean",
            "name": "result"
          },
          {
            "type": "object",
            "name": "data",
            "sub": [
              {
                "type": "number",
                "name": "id"
              },
              {
                "type": "text",
                "name": "name"
              },
              {
                "type": "text",
                "name": "email"
              },
              {
                "type": "text",
                "name": "user_name"
              },
              {
                "type": "number",
                "name": "role_id"
              },
              {
                "type": "number",
                "name": "is_active"
              },
              {
                "type": "text",
                "name": "created_on"
              },
              {
                "type": "number",
                "name": "created_by"
              },
              {
                "type": "text",
                "name": "updated_on"
              },
              {
                "type": "number",
                "name": "updated_by"
              },
              {
                "type": "array",
                "name": "projects",
                "sub": [
                  {
                    "type": "number",
                    "name": "user_project_id"
                  },
                  {
                    "type": "number",
                    "name": "user_id"
                  },
                  {
                    "type": "number",
                    "name": "project_id"
                  },
                  {
                    "type": "text",
                    "name": "created_on"
                  },
                  {
                    "type": "number",
                    "name": "created_by"
                  },
                  {
                    "type": "text",
                    "name": "updated_on"
                  },
                  {
                    "type": "text",
                    "name": "updated_by"
                  }
                ]
              },
              {
                "type": "array",
                "name": "permissions",
                "sub": [
                  {
                    "type": "number",
                    "name": "user_permissions_id"
                  },
                  {
                    "type": "number",
                    "name": "user_id"
                  },
                  {
                    "type": "number",
                    "name": "permission_id"
                  },
                  {
                    "type": "text",
                    "name": "created_on"
                  },
                  {
                    "type": "number",
                    "name": "created_by"
                  },
                  {
                    "type": "text",
                    "name": "updated_on"
                  },
                  {
                    "type": "text",
                    "name": "updated_by"
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "query": [
      {
        "type": "text",
        "name": "id"
      },
      {
        "type": "text",
        "name": "email"
      }
    ],
    "apiLabels": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "object",
            "name": "result",
            "sub": [
              {
                "type": "object",
                "name": "general",
                "sub": [
                  {
                    "type": "text",
                    "name": "cancel"
                  },
                  {
                    "type": "text",
                    "name": "close"
                  },
                  {
                    "type": "text",
                    "name": "error"
                  },
                  {
                    "type": "text",
                    "name": "error_server"
                  },
                  {
                    "type": "text",
                    "name": "filter"
                  },
                  {
                    "type": "text",
                    "name": "no"
                  },
                  {
                    "type": "text",
                    "name": "ok"
                  },
                  {
                    "type": "text",
                    "name": "reset"
                  },
                  {
                    "type": "text",
                    "name": "save"
                  },
                  {
                    "type": "text",
                    "name": "update"
                  },
                  {
                    "type": "text",
                    "name": "yes"
                  }
                ]
              },
              {
                "type": "object",
                "name": "users",
                "sub": [
                  {
                    "type": "object",
                    "name": "users",
                    "sub": [
                      {
                        "type": "text",
                        "name": "action"
                      },
                      {
                        "type": "text",
                        "name": "add_user"
                      },
                      {
                        "type": "text",
                        "name": "confirm_password"
                      },
                      {
                        "type": "text",
                        "name": "created_on"
                      },
                      {
                        "type": "text",
                        "name": "email"
                      },
                      {
                        "type": "text",
                        "name": "id"
                      },
                      {
                        "type": "text",
                        "name": "is_active"
                      },
                      {
                        "type": "text",
                        "name": "name"
                      },
                      {
                        "type": "text",
                        "name": "new_password"
                      },
                      {
                        "type": "text",
                        "name": "permissions"
                      },
                      {
                        "type": "text",
                        "name": "reset_password"
                      },
                      {
                        "type": "text",
                        "name": "roles"
                      },
                      {
                        "type": "text",
                        "name": "title"
                      },
                      {
                        "type": "text",
                        "name": "update_user"
                      },
                      {
                        "type": "text",
                        "name": "users"
                      },
                      {
                        "type": "text",
                        "name": "user_name"
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  },
  "verifyqualification": {
    "apisurvey": [
      {
        "type": "object",
        "name": "data",
        "sub": [
          {
            "type": "object",
            "name": "pages",
            "sub": [
              {
                "type": "object",
                "name": "page1",
                "sub": [
                  {
                    "type": "text",
                    "name": "id"
                  },
                  {
                    "type": "key_array",
                    "name": "questions",
                    "sub": [
                      {
                        "type": "text",
                        "name": "id"
                      },
                      {
                        "type": "text",
                        "name": "readonly"
                      },
                      {
                        "type": "text",
                        "name": "seq"
                      },
                      {
                        "type": "text",
                        "name": "type"
                      }
                    ]
                  }
                ]
              }
            ]
          },
          {
            "type": "object",
            "name": "labels"
          },
          {
            "type": "object",
            "name": "options"
          }
        ]
      }
    ]
  }
});
