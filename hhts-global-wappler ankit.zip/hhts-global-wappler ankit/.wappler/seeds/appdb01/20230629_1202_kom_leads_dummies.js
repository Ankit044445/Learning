exports.seed = async function (knex) {
  // Inserts seed entries
  await knex.transaction(async trx => {

    // Process projects
    await trx('leads').del();
    var leads = [], id = null;

    //(Math.random() + 1).toString(36).substring(2)
    for (let i = 0; i < 15; i++) {

      await trx('leads').insert({

        "response_id": 1,
        "date": "2023-06-29 12:35",
        "adsource": `ads ${i}`,
        "student_status": 2,
        "source_project": `srcprj ${i}`,
        "fname": `f ${i}`,
        "lname": `l ${i}`,
        "email": `email${i}@gmail.com`,
        "phone": `${i}${i}${i}${i}${i}${i}${i}${i}${i}${i}`,
        "address_place": `place ${i}`,
        "address_street": `street ${i}`,
        "address_city": `city ${i}`,
        "address_state": `state ${i}`,
        "address_zip": `${i}${i}${i}${i}${i}`,
        "address_lati": 11.23636,
        "address_longi": 11.23636,
        "howheardsrc": `howheardsrc ${i}`,
        "prefcomms": `prefcomms ${i}`,
        "ok2sms": 1,
        "notifysurv": 1,
        "project_id": 2,
        "camp_resident": `campresident ${i}`,
        "dormitory": 1,
        "dormitory_other": null,
        "married_spouse": 1,
        "other_rommate_nonttu": 1,
        "live_with_parents": 2,
        "applinks_pin": `pin ${i}`,
        "live_in_studyarea": 1,
        "hh_income": 5,
        "hh_size": 6,
        "assigned_to": 1,
        "lead_status": 2,
        "created_on": "2023-06-29 12:33:51",
        "created_by": 1,
        "updated_on": null,
        "updated_by": null
      });
    }



  })

};