exports.seed = async function (knex) {
  // Inserts seed entries
  await knex.transaction(async trx => {

    // Process permissions
    await trx('permissions').del();
    var permissions = [], permissions_id = null;
    permissions_id = await trx('permissions').insert({ permission_name: "all", permission_description: "all", created_on: "2023-06-16T01:22:27.000Z", created_by: 1 }, 'permission_id');
    permissions.push(typeof permissions_id[0] === 'object' ? permissions_id[0] : { permission_id: permissions_id[0] })
    permissions_id = await trx('permissions').insert({ permission_name: "RTC Visitor", permission_description: "RTC Visitor", created_on: "2023-07-16T18:30:00.000Z", created_by: 1, category: 1 }, 'permission_id');
    permissions.push(typeof permissions_id[0] === 'object' ? permissions_id[0] : { permission_id: permissions_id[0] })
    permissions_id = await trx('permissions').insert({ permission_name: "CARTA SC OB", permission_description: "CARTA SC OB", created_on: "2023-07-02T18:30:00.000Z", created_by: 1, category: 2 }, 'permission_id');
    permissions.push(typeof permissions_id[0] === 'object' ? permissions_id[0] : { permission_id: permissions_id[0] })
    permissions_id = await trx('permissions').insert({ permission_name: "MN24", permission_description: "MN24", created_on: "2023-07-02T18:30:00.000Z", created_by: 1, category: 2 }, 'permission_id');
    permissions.push(typeof permissions_id[0] === 'object' ? permissions_id[0] : { permission_id: permissions_id[0] })
    permissions_id = await trx('permissions').insert({ permission_name: "HH24", permission_description: "HH24", created_on: "2023-07-02T18:30:00.000Z", created_by: 1, category: 1 }, 'permission_id');
    permissions.push(typeof permissions_id[0] === 'object' ? permissions_id[0] : { permission_id: permissions_id[0] })

  })

};