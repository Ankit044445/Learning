exports.seed = async function (knex) {
  // Inserts seed entries
  await knex.transaction(async trx => {

    // Process permissions
    await trx('permissions').del();
    var permissions = [], permissions_id = null;
    permissions_id = await trx('permissions').insert({ permission_name: "all", permission_description: "all", created_on: "2023-06-16T06:52:27", created_by: 1 }, 'permission_id');
    permissions.push(typeof permissions_id[0] === 'object' ? permissions_id[0] : { permission_id: permissions_id[0] })

  })

};