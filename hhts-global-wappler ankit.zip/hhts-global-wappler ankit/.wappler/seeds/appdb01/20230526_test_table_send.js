exports.seed = async function (knex) {
  // Inserts seed entries
  await knex.transaction(async trx => {

    await trx('test').insert({
      id: 1,
      name: 'name',
      email: 'name@email.com',
      dob: '2023-05-26',
      created_on: '2023-05-26 16:50:00'
    });
  })

};