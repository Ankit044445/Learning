exports.seed = async function (knex) {
  // Inserts seed entries
  await knex.transaction(async trx => {

    // Process review_tag
    await trx('review_tag').del();
    await trx('review_tag').insert({ id: 1, tag: "Not In Study Area", created_by: 1 }).onConflict('id').ignore();
    await trx('review_tag').insert({ id: 2, tag: "Home Address", created_by: 1 }).onConflict('id').ignore();
    await trx('review_tag').insert({ id: 3, tag: "Missing Home Address", created_by: 1 }).onConflict('id').ignore();
    await trx('review_tag').insert({ id: 4, tag: "Phone Number Has 11 Digits", created_by: 1 }).onConflict('id').ignore();
    await trx('review_tag').insert({ id: 5, tag: "Number Not In Service", created_by: 1 }).onConflict('id').ignore();
    await trx('review_tag').insert({ id: 6, tag: "Wrong Number", created_by: 1 }).onConflict('id').ignore();
    await trx('review_tag').insert({ id: 7, tag: "Missing Email Address", created_by: 1 }).onConflict('id').ignore();
    await trx('review_tag').insert({ id: 8, tag: "Phone Number Have 11 or More Digits", created_by: 1 }).onConflict('id').ignore();
    await trx('review_tag').insert({ id: 9, tag: "Duplicate Phone Number", created_by: 1 }).onConflict('id').ignore();
    await trx('review_tag').insert({ id: 10, tag: "Invalid Email Address", created_by: 1 }).onConflict('id').ignore();
    await trx('review_tag').insert({ id: 11, tag: "Missing Phone Number", created_by: 1 }).onConflict('id').ignore();
    await trx('review_tag').insert({ id: 12, tag: "Email Address Extension", created_by: 1 }).onConflict('id').ignore();
    await trx('review_tag').insert({ id: 13, tag: "First Name", created_by: 1 }).onConflict('id').ignore();
    await trx('review_tag').insert({ id: 14, tag: "Last Name", created_by: 1 }).onConflict('id').ignore();
    await trx('review_tag').insert({ id: 15, tag: "Email Address", created_by: 1 }).onConflict('id').ignore();
    await trx('review_tag').insert({ id: 16, tag: "Phone Number", created_by: 1 }).onConflict('id').ignore();

  })

};