exports.seed = async function (knex) {
  // Inserts seed entries
  await knex.transaction(async trx => {

    await trx('users').insert({
      id: 1,
      name: 'Zalak',
      email: 'aidev.zalak@gmail.com',
      user_name: 'aidev.zalak@gmail.com',
      password: 'home1234',
      is_active: 1
    });

    // Process users
    // await trx('users').del();
    // var users = [], users_id = null;

  })

};