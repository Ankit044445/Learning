exports.seed = async function (knex) {
  // Inserts seed entries
  await knex.transaction(async trx => {

    // Process roles
    await trx('roles').del();
    var roles = [], roles_id = null;
    roles_id = await trx('roles').insert({ role_name: "admin", role_description: "admin", created_on: "2023-06-16T06:49:45", created_by: 1 }, 'role_id');
    roles.push(typeof roles_id[0] === 'object' ? roles_id[0] : { role_id: roles_id[0] })

  })

};