exports.seed = async function (knex) {
  // Inserts seed entries
  await knex.transaction(async trx => {

    // Process projects
    await trx('projects').del();
    var projects = [], projects_id = null;

    //(Math.random() + 1).toString(36).substring(2)
    for (let i = 0; i < 1000; i++) {

      await trx('projects').insert({
        project_name: `Prj ${i}`,
        project_description: '',
        project_code: `Code ${i}`,
        etc_project_number: `Num ${i}`,
        start_year: 2023,
        client_name: `Clnt ${i}`,
        project_status: 'new',
        project_timezone: 'America/Chicago',
        is_active: 1,
        created_on: '2023-06-04 12:35',
        created_by: 1,
      });
    }



  })

};