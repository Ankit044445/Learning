exports.seed = async function (knex) {
  // Inserts seed entries
  await knex.transaction(async trx => {

    // Process lead_status
    await trx('lead_status').del();
    var lead_status = [], lead_status_id = null;
    lead_status_id = await trx('lead_status').insert({ name: "approved", created_by: 1, created_on: "2023-07-21 05:30:00" }, 'lead_status_id');
    lead_status.push(typeof lead_status_id[0] === 'object' ? lead_status_id[0] : { lead_status_id: lead_status_id[0] })
    lead_status_id = await trx('lead_status').insert({ name: "not approved", created_by: 1, created_on: "2023-07-13 06:30:00" }, 'lead_status_id');
    lead_status.push(typeof lead_status_id[0] === 'object' ? lead_status_id[0] : { lead_status_id: lead_status_id[0] })

  })

};