exports.seed = async function (knex) {
  // Inserts seed entries
  await knex.transaction(async trx => {

    // Process roles
    await trx('roles').del();
    var roles = [], roles_id = null;

    await trx('roles').insert([
      {
        role_id: 1,
        role_name: 'admin',
        role_description: '',
        created_by: 1
      },
      {
        role_id: 2,
        role_name: 'staff',
        role_description: '',
        created_by: 1
      }
    ]);
  })

};