
exports.up = function (knex) {
  return knex.schema
    .table('users', async function (table) {
      table.integer('created_by').after('created_on');
      table.integer('updated_by').after('updated_on');
    })

};

exports.down = function (knex) {
  return knex.schema
    .table('users', async function (table) {
      table.dropColumn('created_by');
      table.dropColumn('updated_by');
    })
};
