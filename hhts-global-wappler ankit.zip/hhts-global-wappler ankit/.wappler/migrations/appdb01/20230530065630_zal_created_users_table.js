
exports.up = function(knex) {
  return knex.schema
    .createTable('users', async function (table) {
      table.increments('id');
      table.string('name');
      table.string('email');
      table.string('user_name');
      table.string('password');
      table.integer('is_active');
      table.datetime('created_on').defaultTo(knex.fn.now());
      table.datetime('updated_on');
    })

};

exports.down = function(knex) {
  return knex.schema
    .dropTable('users')
};
