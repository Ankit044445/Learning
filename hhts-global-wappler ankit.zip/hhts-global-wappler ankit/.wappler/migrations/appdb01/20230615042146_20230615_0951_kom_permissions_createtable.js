
exports.up = function(knex) {
  return knex.schema
    .createTable('permissions', async function (table) {
      table.increments('permission_id');
      table.string('permission_name', 255);
      table.string('permission_description', 255);
      table.datetime('created_on').defaultTo(knex.fn.now());
      table.integer('created_by');
      table.integer('updated_by');
      table.datetime('updated_on');
    })

};

exports.down = function(knex) {
  return knex.schema
    .dropTable('permissions')
};
