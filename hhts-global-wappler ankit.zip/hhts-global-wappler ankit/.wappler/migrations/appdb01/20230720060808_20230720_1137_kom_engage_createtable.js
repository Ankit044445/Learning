
exports.up = function (knex) {
  return knex.schema
    .createTable('engage_callstart', async function (table) {
      table.increments('callstart_id');
      table.integer('etcid');
      table.string('fname', 255);
      table.string('lname', 255);
      table.string('phone');
      table.text('apidata');
      table.integer('contact_id');
      table.datetime('created_on').defaultTo(knex.fn.now());
    })
    .createTable('engage_callend', async function (table) {
      table.increments('callend_id');
      table.integer('etcid');
      table.integer('interation_type');
      table.string('agent_username', 255);
      table.timestamp('start_timestamp');
      table.timestamp('end_timestamp');
      table.timestamp('acw_start_timestamp');
      table.timestamp('acw_end_timestamp');
      table.string('recording_s3_location', 255);
      table.string('recording_url', 100);
      table.string('resolution_codes', 100);
      table.string('agent_note', 255);
      table.integer('contact_id');
      table.datetime('created_on').defaultTo(knex.fn.now());
    })

};

exports.down = function (knex) {
  return knex.schema
    .dropTable('engage_callend')
    .dropTable('callstart')
};
