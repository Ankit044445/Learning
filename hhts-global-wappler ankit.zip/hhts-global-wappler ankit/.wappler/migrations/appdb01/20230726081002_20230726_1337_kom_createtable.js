
exports.up = function(knex) {
  return knex.schema
    .createTable('lead_status', async function (table) {
      table.increments('lead_status_id');
      table.string('name', 255);
      table.integer('created_by');
      table.datetime('created_on');
      table.datetime('updated_on');
      table.integer('updated_by');
    })

};

exports.down = function(knex) {
  return knex.schema
    .dropTable('lead_status')
};
