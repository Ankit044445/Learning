
exports.up = function(knex) {
  return knex.schema
    .createTable('test', async function (table) {
      table.increments('id');
      table.string('name', 100);
      table.string('email');
      table.date('dob');
      table.datetime('created_on');
      table.datetime('updated_on');
    })

};

exports.down = function(knex) {
  return knex.schema
    .dropTable('test')
};
