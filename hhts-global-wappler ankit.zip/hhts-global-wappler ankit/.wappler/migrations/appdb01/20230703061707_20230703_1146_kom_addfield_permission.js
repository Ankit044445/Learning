
exports.up = function (knex) {
  return knex.schema
    .table('permissions', async function (table) {
      table.integer('category');
    })

};

exports.down = function (knex) {
  return knex.schema
    .table('permissions', async function (table) {
      table.dropColumn('category');
    })
};
