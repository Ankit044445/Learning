
exports.up = function(knex) {
  return knex.schema
    .renameTable('user_permisiions', 'user_permissions')
    .table('user_permisiions', async function (table) {
      table.undefined('user_id');
      table.undefined('permission_id');
      table.undefined('created_on').defaultTo(knex.fn.now());
      table.undefined('created_by');
      table.undefined('updated_on');
      table.undefined('updated_by');
    })

};

exports.down = function(knex) {
  return knex.schema
    .renameTable('user_permissions', 'user_permisiions')
    .table('user_permisiions', async function (table) {
      table.dropColumn('user_id');
      table.dropColumn('permission_id');
      table.dropColumn('created_on');
      table.dropColumn('created_by');
      table.dropColumn('updated_on');
      table.dropColumn('updated_by');
    })
};
