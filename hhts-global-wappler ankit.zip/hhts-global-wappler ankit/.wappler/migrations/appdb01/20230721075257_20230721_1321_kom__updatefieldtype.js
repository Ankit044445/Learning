
exports.up = function (knex) {
  return knex.schema
    .table('engage_callend', async function (table) {
      table.string('interation_type', 255).alter();
      table.datetime('start_timestamp').alter();
      table.datetime('end_timestamp').alter();
      table.datetime('acw_start_timestamp').alter();
      table.datetime('acw_end_timestamp').alter();
      table.text('resolution_codes').alter();
      table.string('contact_id', 100).alter();
      table.datetime('created_on').defaultTo(knex.fn.now()).alter();
    })

};

exports.down = function (knex) {
  return knex.schema
    .table('engage_callend', async function (table) {
      table.integer('interation_type').alter();
      table.timestamp('start_timestamp').alter();
      table.timestamp('end_timestamp').alter();
      table.timestamp('acw_start_timestamp').alter();
      table.timestamp('acw_end_timestamp').alter();
      table.string('resolution_codes', 100).alter();
      table.integer('contact_id').alter();
      table.datetime('created_on').defaultTo(current_timestamp()).alter();
    })
};
