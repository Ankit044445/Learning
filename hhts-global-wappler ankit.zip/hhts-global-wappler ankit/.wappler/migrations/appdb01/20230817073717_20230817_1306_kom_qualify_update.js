
exports.up = function(knex) {
  return knex.schema
    .table('qualify', async function (table) {
      table.renameColumn('address_correct', 'current_address');
      table.renameColumn('address_place', 'address_placename');
      table.renameColumn('address_lati', 'address_lat');
      table.renameColumn('address_longi', 'address_lng');
      table.renameColumn('hh_size', 'number_persons');
      table.renameColumn('hh_employed_size', 'hh_welcome_number_employed');
      table.renameColumn('hh_income', 'hh_welcome_income');
      table.string('address_searchtext', 255);
      table.string('address_searchplaceid', 255);
      table.string('address_placeid', 255);
      table.string('address_fulladdress', 255);
      table.string('address_county', 255);
      table.string('address_country', 255);
    })

};

exports.down = function(knex) {
  return knex.schema
    .table('qualify', async function (table) {
      table.renameColumn('current_address', 'address_correct');
      table.renameColumn('address_placename', 'address_place');
      table.renameColumn('address_lat', 'address_lati');
      table.renameColumn('address_lng', 'address_longi');
      table.renameColumn('number_persons', 'hh_size');
      table.renameColumn('hh_welcome_number_employed', 'hh_employed_size');
      table.renameColumn('hh_welcome_income', 'hh_income');
      table.dropColumn('address_searchtext');
      table.dropColumn('address_searchplaceid');
      table.dropColumn('address_placeid');
      table.dropColumn('address_fulladdress');
      table.dropColumn('address_county');
      table.dropColumn('address_country');
    })
};
