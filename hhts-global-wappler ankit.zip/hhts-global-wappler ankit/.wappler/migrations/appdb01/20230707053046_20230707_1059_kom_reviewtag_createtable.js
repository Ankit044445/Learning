
exports.up = function(knex) {
  return knex.schema
    .createTable('lead_review_tag', async function (table) {
      table.increments('lead_review_tag_id');
      table.string('review_tag_id', 255);
      table.integer('lead_id').unsigned();
      table.foreign('lead_id').references('id').inTable('leads').onUpdate('CASCADE').onDelete('CASCADE');
      table.integer('created_by');
      table.datetime('created_on');
      table.datetime('updated_on');
      table.integer('updated_by');
    })

};

exports.down = function(knex) {
  return knex.schema
    .dropTable('lead_review_tag')
};
