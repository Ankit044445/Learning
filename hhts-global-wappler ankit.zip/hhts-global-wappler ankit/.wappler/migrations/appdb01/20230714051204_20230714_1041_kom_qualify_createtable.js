
exports.up = function (knex) {
  return knex.schema
    .createTable('qualify', async function (table) {
      table.increments('qualify_id');
      table.integer('lead_id').unsigned();
      table.foreign('lead_id').references('id').inTable('leads').onUpdate('CASCADE').onDelete('CASCADE');
      table.string('name', 255);
      table.string('email', 255);
      table.string('phone', 20);
      table.integer('address_correct');
      table.string('address_place', 255);
      table.string('address_street', 255);
      table.string('address_city', 255);
      table.string('address_state', 255);
      table.string('address_zip', 10);
      table.float('address_lati');
      table.float('address_longi');
      table.string('studyarea', 100);
      table.integer('hh_size');
      table.integer('hh_employed_size');
      table.integer('hh_income');
      table.integer('qualify_status');
      table.text('note');
      table.datetime('created_on').defaultTo(knex.fn.now());
      table.integer('created_by');
      table.datetime('updated_on');
      table.integer('updated_by');
    })

};

exports.down = function (knex) {
  return knex.schema
    .dropTable('qualify')
};
