
exports.up = function (knex) {
  return knex.schema
    .createTable('labels_app', async function (table) {
      table.string('screen', 60);
      table.string('field', 60);
      table.string('type', 60);
      table.text('en');
      table.primary(['screen', 'field', 'type'], 'lables_app_pk')
    })

};

exports.down = function (knex) {
  return knex.schema
    .dropTable('labels_app')
};
