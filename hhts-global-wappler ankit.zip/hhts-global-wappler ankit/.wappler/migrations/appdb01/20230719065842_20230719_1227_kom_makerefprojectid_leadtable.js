
exports.up = function(knex) {
  return knex.schema
    .table('leads', async function (table) {
      table.integer('project_id').alter().unsigned();
      table.foreign('project_id').references('project_id').inTable('projects').onUpdate('CASCADE').onDelete('CASCADE');
    })

};

exports.down = function(knex) {
  return knex.schema
    .table('leads', async function (table) {
      await table.dropForeign('project_id');
      table.integer('project_id').alter();
    })
};
