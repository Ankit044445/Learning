
exports.up = function (knex) {
  return knex.schema
    .table('leads', async function (table) {
      table.integer('assigned_to').alter().unsigned();
      table.foreign('assigned_to').references('id').inTable('users').onUpdate('CASCADE').onDelete('CASCADE');
    })

};

exports.down = function (knex) {
  return knex.schema
    .table('leads', async function (table) {
      await table.dropForeign('assigned_to');
      table.integer('assigned_to').alter();
    })
};
