
exports.up = function(knex) {
  return knex.schema
    .table('user_projects', async function (table) {
      table.integer('created_by').alter();
      table.integer('updated_by').alter();
    })

};

exports.down = function(knex) {
  return knex.schema
    .table('user_projects', async function (table) {
      table.string('created_by', 255).alter();
      table.string('updated_by', 255).alter();
    })
};
