
exports.up = function (knex) {
  return knex.schema
    .createTable('batch_lead', async function (table) {
      table.increments('batch_lead_id');
      table.string('batch_label');
      table.text('lead_id');
      table.string('lead_type', 255);
      table.integer('user_id').unsigned();
      table.foreign('user_id').references('id').inTable('users').onUpdate('CASCADE').onDelete('CASCADE');
      table.integer('records_count');
      table.datetime('created_on');
      table.integer('created_by');
      table.datetime('updated_on');
      table.integer('updated_by');
    })

};

exports.down = function (knex) {
  return knex.schema
    .dropTable('batch_lead')
};
