
exports.up = function(knex) {
  return knex.schema
    .createTable('leads', async function (table) {
      table.increments('id');
      table.integer('response_id');
      table.datetime('date');
      table.string('adsource', 255);
      table.integer('student_status');
      table.string('source_project', 255);
      table.string('fname', 255);
      table.string('lname', 255);
      table.string('email', 255);
      table.string('phone', 100);
      table.string('address_place', 255);
      table.string('address_street', 255);
      table.string('address_city', 255);
      table.string('address_state', 255);
      table.integer('address_zip');
      table.float('address_lati');
      table.float('address_longi');
      table.string('howheardsrc', 255);
      table.string('prefcomms', 255);
      table.integer('ok2sms');
      table.integer('notifysurv');
      table.integer('project_id');
      table.string('camp_resident', 255);
      table.integer('dormitory');
      table.string('dormitory_other', 255);
      table.integer('married_spouse');
      table.integer('other_rommate_nonttu');
      table.integer('live_with_parents');
      table.string('applinks_pin', 255);
      table.integer('live_in_studyarea');
      table.integer('hh_income');
      table.integer('hh_size');
      table.integer('assigned_to');
      table.integer('lead_status');
      table.datetime('created_on').defaultTo(knex.fn.now());
      table.integer('created_by');
      table.datetime('updated_on');
      table.integer('updated_by');
    })

};

exports.down = function(knex) {
  return knex.schema
    .dropTable('leads')
};
