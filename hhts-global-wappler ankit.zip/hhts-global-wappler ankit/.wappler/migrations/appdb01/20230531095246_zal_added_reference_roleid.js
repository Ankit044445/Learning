
exports.up = function (knex) {
  return knex.schema
    .table('users', async function (table) {
      table.integer('role_id').unsigned().after('password');
      table.foreign('role_id').references('role_id').inTable('roles').onUpdate('CASCADE').onDelete('CASCADE');
    })

};

exports.down = function (knex) {
  return knex.schema
    .table('users', async function (table) {
      table.dropForeign('role_id');
      table.dropColumn('role_id');
    })
};
