
exports.up = function (knex) {
  return knex.schema
    .createTable('roles', async function (table) {
      table.increments('role_id');
      table.string('role_name');
      table.text('role_description');
      table.datetime('created_on').defaultTo(knex.fn.now());
      table.integer('created_by');
      table.datetime('updated_on');
      table.integer('updated_by');
    })

};

exports.down = function (knex) {
  return knex.schema
    .dropTable('roles')
};
