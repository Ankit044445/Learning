
exports.up = function (knex) {
  return knex.schema
    .createTable('user_projects', async function (table) {
      table.increments('user_project_id');
      table.integer('user_id').unsigned();
      table.foreign('user_id').references('id').inTable('users').onUpdate('CASCADE').onDelete('CASCADE');
      table.integer('project_id').unsigned();
      table.foreign('project_id').references('project_id').inTable('projects').onUpdate('CASCADE').onDelete('CASCADE');
      table.datetime('created_on').defaultTo(knex.fn.now());
      table.integer('created_by');
      table.datetime('updated_on');
      table.integer('updated_by');
    })

};

exports.down = function (knex) {
  return knex.schema
    .dropTable('user_projects')
};
