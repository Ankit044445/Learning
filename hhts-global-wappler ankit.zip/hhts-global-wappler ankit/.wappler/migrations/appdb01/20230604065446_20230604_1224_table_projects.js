
exports.up = function(knex) {
  return knex.schema
    .createTable('projects', async function (table) {
      table.increments('project_id');
      table.string('project_name', 100);
      table.text('project_description');
      table.string('project_code', 60);
      table.string('etc_project_number', 60);
      table.integer('start_year');
      table.string('client_name', 100);
      table.string('project_status', 20);
      table.string('project_timezone', 60);
      table.boolean('is_active').defaultTo(true);
      table.datetime('created_on');
      table.integer('created_by');
      table.datetime('updated_on');
      table.integer('updated_by');
    })

};

exports.down = function(knex) {
  return knex.schema
    .dropTable('projects')
};
