
exports.up = function(knex) {
  return knex.schema
    .createTable('history_actions', async function (table) {
      table.increments('history_id');
      table.integer('lead_id').unsigned();
      table.foreign('lead_id').references('id').inTable('leads').onUpdate('CASCADE').onDelete('CASCADE');
      table.string('lead_type');
      table.integer('lead_action_id');
      table.integer('lead_status');
      table.string('action_note', 255);
      table.integer('batch_id');
      table.integer('project_id').unsigned();
      table.foreign('project_id').references('project_id').inTable('projects').onUpdate('CASCADE').onDelete('CASCADE');
      table.integer('assign_to');
      table.integer('created_by').defaultTo(knex.fn.now());
      table.datetime('created_on');
      table.datetime('updated_on');
      table.integer('updated_by');
    })
    .createTable('review_tag', async function (table) {
      table.increments('id');
      table.string('tag', 255);
      table.text('description');
      table.integer('status');
      table.integer('created_by');
      table.datetime('created_on');
      table.datetime('updated_on');
      table.integer('updated_by');
    })

};

exports.down = function(knex) {
  return knex.schema
    .dropTable('review_tag')
    .dropTable('lead_review_tag')
    .dropTable('history_actions')
    .dropTable('batch_lead')
};
