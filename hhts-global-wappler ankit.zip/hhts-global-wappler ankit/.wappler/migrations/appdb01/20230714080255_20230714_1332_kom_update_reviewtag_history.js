
exports.up = function (knex) {
  return knex.schema
    .table('history_actions', async function (table) {
      table.datetime('created_on').defaultTo(knex.fn.now()).alter();
    })
    .table('lead_review_tag', async function (table) {
      table.datetime('created_on').defaultTo(knex.fn.now()).alter();
    })

};

exports.down = function (knex) {
  return knex.schema
    .table('lead_review_tag', async function (table) {
      table.datetime('created_on').defaultTo().alter();
    })
    .table('history_actions', async function (table) {
      table.datetime('created_on').defaultTo().alter();
    })
};
