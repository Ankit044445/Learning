
exports.up = function(knex) {
  return knex.schema
    .createTable('user_permisiions', async function (table) {
      table.increments('user_permissions_id');
      table.integer('user_id').unsigned();
      table.foreign('user_id').references('id').inTable('users').onUpdate('CASCADE').onDelete('CASCADE');
      table.integer('permission_id').unsigned();
      table.foreign('permission_id').references('permission_id').inTable('permissions').onUpdate('CASCADE').onDelete('CASCADE');
      table.datetime('created_on').defaultTo(knex.fn.now());
      table.integer('created_by');
      table.datetime('updated_on');
      table.integer('updated_by');
    })

};

exports.down = function(knex) {
  return knex.schema
    .dropTable('user_permisiions')
};
