exports.getValue = function (options) {
    let result = {};
    let data = this.parse(options.data);

    data.forEach((item) => {
        if(!result[item.screen]){
            result[item.screen] = {};
        }
        if(item.screen == 'general'){
            if(!result[item.screen][item.field]){
                result[item.screen][item.field] = item.en;;
            }
        }else{
            if(!result[item.screen][item.field]){
                result[item.screen][item.field] = {};
            }
            result[item.screen][item.field][item.type] = item.en;
        }
    });
    
    
    return result;
};
