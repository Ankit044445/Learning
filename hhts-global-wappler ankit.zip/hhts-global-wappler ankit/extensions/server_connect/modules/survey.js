// JavaScript Document

exports.getSurvey = function (options) {
    let result = {};
    let data = this.parse(options.data);

    data.forEach((item) => {
        if (!result[item.page_code]) {
            result[item.page_code] = {};
            result[item.page_code].id = item.page_code;
            result[item.page_code].questions = {};
        }

        if (item.questionid == 'nextpage') {
            result[item.page_code].nextpage = item.attribute_value;
        } else if (item.questionid == 'startpage') {
        } else {
            if (!result[item.page_code].questions[item.questionid]) {
                result[item.page_code].questions[item.questionid] = {};
                result[item.page_code].questions[item.questionid].id = item.questionid;
            }
            result[item.page_code].questions[item.questionid][item.attribute_name] = item.attribute_value;
        }
    });

    return result;
};

exports.getLabels = function (options) {
    let result = {};
    let data = this.parse(options.data);
    let lang = this.parse(options.lang);

    data.forEach((item) => {
        if (!result[item.questionid]) {
            result[item.questionid] = {};
        }

        result[item.questionid][item.label_name] = item[`value_${lang}`];
    });

    return result;
};

exports.getOptions = function (options) {
    let result = {};
    let data = this.parse(options.data);
    let lang = this.parse(options.lang);

    data.forEach((item) => {
        if (!result[item.questionid]) {
            result[item.questionid] = [];
        }

        result[item.questionid].push({ "key": item.option_key, "text": item[`value_${lang}`], "seq": item['sequence'] });
    });

    return result;
};