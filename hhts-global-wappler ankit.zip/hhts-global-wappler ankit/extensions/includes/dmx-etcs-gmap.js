// JavaScript Document
dmx.Component('etcs-gmap', {
    extends: "form-element",

    extraMarkers: [],
    map: null,
    geocoder: null,
    placeService: null,

    initialData: {
        searchtext: null,
        searchplaceid: null,
        debug: true,
        lat: null,
        lng: null,
        placeid: "",
        placename: "",
        fulladdress: "",
        street: "",
        city: "",
        state: "",
        zip: "",
        county: "",
        country: "",
        studyarea: "",
    },

    attributes: {
        init_lat: {
            default: null
        },
        init_lng: {
            default: null
        },
        init_zoom: {
            default: null
        },
        scrollwheel: {
            default: "true"
        },
        disabledefaultui: {
            default: false
        },
        /* autocomplete */
        searchplaceid: {
            default: null
        },
        searchtext: {
            default: null
        },
        /* data */
        lat: {
            default: null
        },
        lng: {
            default: null
        },
        placeid: {
            default: null
        },
        placename: {
            default: null
        },
        fulladdress: {
            default: null
        },
        street: {
            default: null
        },
        city: {
            default: null
        },
        county: {
            default: null
        },
        zip: {
            default: null
        },
        studyarea: {
            default: null
        },
        country: {
            default: null
        },
        /* markers */
        extramarkers: {
            type: Array,
            default: []
        }
    },

    methods: {

    },

    events: {
        updated: Event,
        mapclicked: Event,
        markerclicked: Event,
        onmapload: Event
    },

    //init map
    initMap: function () {
        let myLatLng = new google.maps.LatLng({ lat: this.data.lat ? this.data.lat : 0.0, lng: this.data.lng ? this.data.lng : 0.0 });

        //load google map
        this.map = new google.maps.Map(document.getElementById(`${this.name}_map_div`), {
            gestureHandling: 'greedy',
            zoom: 10,
            center: myLatLng,
            scrollwheel: this.props.scrollwheel,
            disableDefaultUI: this.props.disabledefaultui,
            fullscreenControlOptions: {
                position: google.maps.ControlPosition.BOTTOM_RIGHT
            }
        });

        const locationButton = document.createElement("button");
        locationButton.textContent = "ME";
        locationButton.classList.add("custom-map-control-button");
        this.map.controls[google.maps.ControlPosition.TOP_RIGHT].push(locationButton);

        locationButton.addEventListener("click", () => {
            this.getCurrentLocation();
        });

        this.map.addListener("click", (event) => { this.onMapClick(event) });

        this.geocoder = new google.maps.Geocoder();
        this.placeService = new google.maps.places.PlacesService(this.map);

        dmx.nextTick(function () {
            this.dispatchEvent('updated');
            this.dispatchEvent('onmapload');
        }, this);

    },

    updateExtraMarkers: function () {

        let i = 0;
        let bounds = new google.maps.LatLngBounds();

        //Clear existing markers
        this.extraMarkers.forEach((element) => {
            element.setMap(null);
        })

        //Add markers
        this.props.extramarkers.forEach((element) => {

            i++;

            let gmarker = new google.maps.Marker({
                position: new google.maps.LatLng(element.lat, element.lng),
                map: this.map,
                title: element.title,
                label: element.label
            })

            google.maps.event.addListener(gmarker, 'click', () => {
                dmx.nextTick(function () {
                    this.dispatchEvent('markerclicked');
                }, this);
            });

            this.extraMarkers.push(gmarker)

            bounds.extend(gmarker.getPosition());
        })

        if (i == 1) {
            this.map.setCenter(new google.maps.LatLng(datasource[0].lat, datasource[0].lng));
            this.map.setZoom(15);

        } else {
            if (i > 0) {
                this.map.fitBounds(bounds);
            }
        }

    },

    geocodeLatlng: function (updatesearch) {
        this.geocoder.geocode({ location: { lat: this.data.lat, lng: this.data.lng } },
            (results, status) => {

                if (status == "OK") {
                    if (results[0]) {

                        this.updatePlaceValue(results[0], true, updatesearch);



                        dmx.nextTick(function () {
                            this.dispatchEvent('updated');
                            this.dispatchEvent('mapclicked');
                        }, this);

                    } else {
                        if (this.data.debug) console.log("No results found - Map click");
                    }

                }
            }
        );
    },

    getPlaceDetails: function () {
        console.log(`gmap-getPlaceDetails(${this.props.searchplaceid})`);
        if (!this.props.searchplaceid) return;

        this.placeService.getDetails({ placeId: this.props.searchplaceid, fields: ['name', 'formatted_address', 'address_components', 'geometry'] },

            (place, status) => {
                if (status == google.maps.places.PlacesServiceStatus.OK) {

                    this.data.placeid = this.props.searchplaceid;

                    this.updatePlaceValue(place, false, false);

                    this.updateLocationMarker(true);

                    dmx.nextTick(function () {
                        this.dispatchEvent('updated');
                        this.dispatchEvent('mapclicked');
                    }, this);
                }
            });
    },

    geocodeSearch: function () {
        console.log(`gmap-geocodeSearch(${this.props.searchtext})`);
        if (!this.props.searchtext) return;
        this.geocoder.geocode({ address: this.props.searchtext }, (results, status) => {
            if (status == "OK") {

                if (results[0]) {
                    // fill map elements
                    this.updatePlaceValue(results[0], true);

                    this.updateLocationMarker(true);

                    dmx.nextTick(function () {
                        this.dispatchEvent('updated');
                        this.dispatchEvent('mapclicked');
                    }, this);
                }
            }
        });
    },

    updatePlaceValue: function (place, updateplaceid, updatesearch) {

        this.set("value", place.formatted_address);

        this.set("fulladdress", place.formatted_address);

        this.set("search", place.formatted_address);

        this.set("lat", place.geometry.location.lat());

        this.set("lng", place.geometry.location.lng());

        if (place.name) {
            this.set("placename", place.name);
        } else {
            this.set("placename", '-');
        }

        if (updateplaceid) {
            if (place.place_id) {
                this.set("placeid", place.place_id);
            } else {
                this.set("placeid", '-');
            }
        }
        if (updatesearch) {
            this.set("searchtext", place.formatted_address);
            if (place.place_id) {
                this.set("searchplaceid", place.place_id);
            } else {
                this.set("searchplaceid", '-');
            }

        }

        this.set("street", place.formatted_address.split(',')[0]);
        this.set("zip", "");
        this.set("country", "");
        this.set("state", "");
        this.set("county", "");
        this.set("city", "");

        for (let i = 0; i < place.address_components.length; i++) {
            if (place.address_components[i].types.indexOf('postal_code') > -1) {
                //zip
                this.set("zip", place.address_components[i].short_name);
            } else if (place.address_components[i].types.indexOf('country') > -1) {
                //country
                this.set("country", place.address_components[i].short_name);
            } else if (place.address_components[i].types.indexOf('administrative_area_level_1') > -1) {
                //state
                this.set("state", place.address_components[i].short_name);
            } else if (place.address_components[i].types.indexOf('administrative_area_level_2') > -1) {
                //county
                this.set("county", place.address_components[i].short_name);
            } else if (place.address_components[i].types.indexOf('locality') > -1) {
                //city
                this.set("city", place.address_components[i].long_name);
            }
        }
    },

    getCurrentLocation: function () {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    this.data.lat = position.coords.latitude;
                    this.data.lng = position.coords.longitude;
                    this.updateLocationMarker(true);

                    this.geocodeLatlng()
                },
                () => {
                    this.handleLocationError(true);
                }
            );
        } else {
            // Browser doesn't support Geolocation
            this.handleLocationError(false);
        }
    },

    handleLocationError: function (browserHasGeolocation) {
        if (this.d / ata.debug) console.log(browserHasGeolocation ? "Error: The Geolocation service failed." : "Error: Your browser doesn't support geolocation.");
    },

    onMapClick: function (event) {
        this.data.lat = event.latLng.lat();
        this.data.lng = event.latLng.lng();
        this.data.placeid = null;
        this.props.placeid = null;

        this.updateLocationMarker(false);

        this.geocodeLatlng(true);
    },

    updateLocationMarker: function (movemap) {
        console.log(`updateLocationMarker(${movemap})`);
        console.log(this.$node.attributes);

        let latlng = { lat: parseFloat(this.data.lat ? this.data.lat : "0.0"), lng: parseFloat(this.data.lng ? this.data.lng : "0.0") }

        if (this.data.markerLocation) this.data.markerLocation.setMap(null);

        this.data.markerLocation = new google.maps.Marker({
            position: latlng,
            map: this.map,
            draggable: true
        });

        if (movemap) {
            this.map.setCenter(latlng);
            this.map.setZoom(15);
        }
    },

    render: function (node) {

        console.log('gmap - render');
        dmx.Component("form-element").prototype.render.call(this, node);

        //copy dynamic props into values
        if (this.props.searchtext) this.data.searchtext = this.props.searchtext;
        if (this.props.searchplaceid) this.data.searchplaceid = this.props.searchplaceid;
        if (this.props.lat) this.data.lat = this.props.lat;
        if (this.props.lng) this.data.lng = this.props.lng;
        if (this.props.placeid) this.data.placeid = this.props.placeid;
        if (this.props.placename) this.data.placename = this.props.placename;
        if (this.props.fulladdress) this.data.fulladdress = this.props.fulladdress;
        if (this.props.street) this.data.street = this.props.street;
        if (this.props.city) this.data.city = this.props.city;
        if (this.props.county) this.data.county = this.props.county;
        if (this.props.zip) this.data.zip = this.props.zip;
        if (this.props.state) this.data.state = this.props.state;
        if (this.props.studyarea) this.data.studyarea = this.props.studyarea;
        if (this.props.country) this.data.country = this.props.country;

        this.initMap();

        this.updateLocationMarker(false);

    },

    update: function (props, fields) {

        if (fields.has("init_lat") || fields.has("init_lng") || fields.has("init_zoom")) {
            //Once all three available move map to init position
            if (this.props.init_lat && this.props.init_lng && this.props.init_zoom) {
                console.log(`gmap update init_lat init_lng`);
                console.log({ lat: parseFloat(this.props.init_lat), lng: parseFloat(this.props.init_lng) });
                console.log(this.props.init_zoom);
                let myLatLng = new google.maps.LatLng({ lat: parseFloat(this.props.init_lat), lng: parseFloat(this.props.init_lng) });
                this.map.setCenter(myLatLng);
                this.map.setZoom(parseInt(this.props.init_zoom));
            }
        }

        if (fields.has("lat") || fields.has("lng") || fields.has("fulladdress") || fields.has("street") || fields.has("city")
            || fields.has("county") || fields.has("state") || fields.has("zip") || fields.has("studyarea") || fields.has("country")) {
            console.log(`gmap update lat lng`);
            //Step1 copy dynamic props into values
            if (this.data.searchtext != this.props.searchtext) this.data.searchtext = this.props.searchtext;
            if (this.data.searchplaceid != this.props.searchplaceid) this.data.searchplaceid = this.props.searchplaceid;
            if (this.data.lat != this.props.lat || this.data.lng != this.props.lng) {
                this.data.lat = this.props.lat;
                this.data.lng = this.props.lng;
                this.updateLocationMarker(false);
            }
            if (this.data.fulladdress != this.props.fulladdress) this.data.fulladdress = this.props.fulladdress;
            if (this.data.street != this.props.street) this.data.street = this.props.street;
            if (this.data.city != this.props.city) this.data.city = this.props.city;
            if (this.data.county != this.props.county) this.data.county = this.props.county;
            if (this.data.state != this.props.state) this.data.state = this.props.state;
            if (this.data.zip != this.props.zip) this.data.zip = this.props.zip;
            if (this.data.studyarea != this.props.studyarea) this.data.studyarea = this.props.studyarea;
            if (this.data.country != this.props.country) this.data.country = this.props.country;

        }
        if (fields.has("searchtext") && this.data.searchtext != this.props.searchtext) {
            console.log(`gmap update searchtext`);
            this.set("searchtext", this.props.searchtext)
            //this.geocodeSearch();
        }
        if (fields.has("searchplaceid") && this.data.searchplaceid != this.props.searchplaceid) {
            console.log(`gmap update searchplaceid`);
            this.set("searchplaceid", this.props.searchplaceid)
            this.getPlaceDetails();
        }
        if (fields.has("extramarkers")) {
            this.updateExtraMarkers();
        }
    }
});
