// JavaScript Document

dmx.Component('etcs-datepicker', {
    extends: "form-element",

    initialData: {
        //dateformat: "MM/dd/yyyy",
        tdconfig: {
            display: {
                icons: {
                    type: 'icons',
                    time: 'fa fa-solid fa-clock',
                    date: 'fa fa-solid fa-calendar',
                    up: 'fa fa-solid fa-arrow-up',
                    down: 'fa fa-solid fa-arrow-down',
                    previous: 'fa fa-solid fa-chevron-left',
                    next: 'fa fa-solid fa-chevron-right',
                    today: 'fa fa-solid fa-calendar-check',
                    clear: 'fa fa-solid fa-trash',
                    close: 'fa fa-solid fa-xmark'
                },
                components: {
                    calendar: true,
                    date: true,
                    month: true,
                    year: true,
                    decades: true,
                    clock: true,
                    hours: false,
                    minutes: false,
                    seconds: false,
                    //deprecated use localization.hourCycle = 'h24' instead
                    useTwentyfourHour: undefined
                },

                theme: 'light'
            },
            localization: {
                locale: 'en-US',
                format: 'MM/dd/yyyy',
            },
            defaultDate: undefined,
            restrictions: {
                daysOfWeekDisabled: [0, 6],
            }
        }
    },

    attributes: {
        // dateformat: {
        //     type: String,
        //     default: "MM/dd/yyyy"
        // },
        disabledweekdays: {
            type: String,
            default: null
        },
        disableddates: {
            type: Array,
            default: []
        }
    },

    methods: {
        setValue: function (value) {
            console.log(`setValue(${value})`);

            //Update state
            this.set("value", value);

            this.props.value = value;

            //Update ui
            this.recreateDateWidget(value);

            //This comp value is updated so if other components are using they can update their self
            dmx.nextTick(function () {
                this.dispatchEvent('updated');
            }, this);
        }
    },

    events: {
        updated: Event,
        datechanged: Event,
    },

    recreateDateWidget: function () {
        //Value is in yyyy-mm-dd format
        const value = this.data.value;

        //Update value in config
        let formattedate = value ? this.convertToMMddYYYY(value) : undefined;

        if (value) {
            document.getElementById(`${this.name}_input`).value = formattedate;
            //update config
            this.data.tdconfig.defaultDate = formattedate;//this.dateFromYYYYMMdd(value); //This is js date obj
        } else {
            document.getElementById(`${this.name}_input`).value = null;
            //update config
            this.data.tdconfig.defaultDate = undefined;
        }

        //daysOfWeekDisabled
        if (this.props.disabledweekdays) {
            this.data.tdconfig.restrictions.daysOfWeekDisabled = this.props.disabledweekdays.split(',').map(item => parseInt(item));
        }

        //update disabledDates in config
        if (this.props.disableddates) {
            this.data.tdconfig.restrictions.disabledDates = this.props.disableddates.map(item => {
                let parts = item.split('-');
                return `${parts[1]}/${parts[2]}/${parts[0]}`;
            });
        }

        //dettach event
        if (this.tempusDominusOnChange) this.tempusDominusOnChange.unsubscribe();

        //dispose 
        if (this.tempusDominus) this.tempusDominus.dispose();

        //recreate
        this.tempusDominus = new tempusDominus.TempusDominus(
            document.getElementById(`${this.name}_input`), Object.assign({}, this.data.tdconfig));

        //attache event handler
        this.tempusDominusOnChange = this.tempusDominus.subscribe('change.td', () => {

            //Update state
            let formattedstr = document.getElementById(`${this.name}_input`).value;

            let datestr = this.convertToYYYYMMdd(formattedstr);

            if (this.data.value != datestr) {

                this.set("value", datestr);

                this.props.value = datestr;

                //This comp value is updated so if other components are using they can update their self
                dmx.nextTick(function () {
                    this.dispatchEvent('updated');
                    this.dispatchEvent('datechanged');
                }, this);
            }
        });
    },

    update: function (props, fields) {
        //Handles dynamic propery updates on container. If any dynamic property of this component is changed, this method will be fired with "fields" containing changed property name. this.props holds new value, props hold old values

        let needRefresh = false;

        if (fields.has('value') && this.data.value != this.props.value) {
            //Update state
            this.data.value = this.props.value;

            needRefresh = true;
        }
        if (fields.has('disableddates')) {
            needRefresh = true;
        }

        if (needRefresh) {
            //Update ui
            this.recreateDateWidget();

            //This comp value is updated so if other components are using they can update their self
            dmx.nextTick(function () {
                this.dispatchEvent('updated');
            }, this);
        }
    },

    render: function (node) {
        //This method is called once after page is loaded. It renders html for initial state
        dmx.Component("form-element").prototype.render.call(this, node);

        this.data.value = this.props.value;

        this.recreateDateWidget();


    },

    convertToYYYYMMdd: function (str) {
        let parts = str.split('/');
        return `${parts[2]}-${parts[0]}-${parts[1]}`;
    },

    convertToMMddYYYY: function (str) {
        let parts = str.split('-');
        return `${parts[1]}/${parts[2]}/${parts[0]}`;
    }
});