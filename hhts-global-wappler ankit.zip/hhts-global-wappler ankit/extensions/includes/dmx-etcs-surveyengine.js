// JavaScript Document

dmx.Component('etcs-surveyengine', {

    extends: 'value',

    initialData: {
        debug: true
    },

    attributes: {
        debug: {
            default: true
        },
    },

    methods: {

        initSurveyJson: function (answers = null) {

            console.log(`survey-initSurveyJson()`);

            for (const pageid in this.data.value.pages) {
                const page = this.data.value.pages[pageid];
                // console.log(`Page`);
                // console.log(page);

                this.data.value.pages[pageid].isvalid = true;
                for (const qid in this.data.value.pages[pageid].questions) {
                    const question = this.data.value.pages[pageid].questions[qid];
                    //console.log(`Question`);
                    //console.log(question);

                    //copy lables
                    if (this.data.value.labels[qid]) {
                        this.data.value.pages[pageid].questions[qid].labels = this.data.value.labels[qid];
                    }

                    //Add additional attributes for ui binding for each type
                    switch (question.type) {
                        case 'hidden':
                            this.data.value.pages[pageid].questions[qid].ui = this.initHiddenJson();
                            this.data.value.pages[pageid].questions[qid].values = this.valuesHidden(qid, answers);
                            break;
                        case 'text':
                            this.data.value.pages[pageid].questions[qid].ui = this.initTextJson();
                            this.data.value.pages[pageid].questions[qid].values = this.valuesText(qid, answers);
                            //if answer is available, then only run validation in init
                            if (this.hasTextValues(qid, answers)) {
                                this.validateText(pageid, qid);
                            }
                            break;
                        case 'textdnr':
                            this.data.value.pages[pageid].questions[qid].ui = this.initTextdnrJson();
                            this.data.value.pages[pageid].questions[qid].values = this.valuesTextdnr(qid, answers);
                            //if answer is available, then only run validation in init
                            if (this.hasTextdnrValues(qid, answers)) {
                                this.validateTextdnr(pageid, qid);
                            }
                            break;
                        case 'number':
                            this.data.value.pages[pageid].questions[qid].ui = this.initNumberJson();
                            this.data.value.pages[pageid].questions[qid].values = this.valuesNumber(qid, answers);
                            //if answer is available, then only run validation in init
                            if (this.hasNumberValues(qid, answers)) {
                                this.validateNumber(pageid, qid);
                            }
                            break;
                        case 'numberdnr':
                            this.data.value.pages[pageid].questions[qid].ui = this.initNumberdnrJson();
                            this.data.value.pages[pageid].questions[qid].values = this.valuesNumberdnr(qid, answers);
                            //if answer is available, then only run validation in init
                            if (this.hasNumberdnrValues(qid, answers)) {
                                this.validateNumberdnr(pageid, qid);
                            }
                            break;
                        case 'radio':
                            this.data.value.pages[pageid].questions[qid].ui = this.initRadioJson();
                            this.data.value.pages[pageid].questions[qid].values = this.valuesRadio(qid, answers);
                            this.data.value.pages[pageid].questions[qid].options = this.getRadioOptions(pageid, qid);
                            //if answer is available, then only run validation in init
                            if (this.hasRadioValues(qid, answers)) {
                                this.validateRadio(pageid, qid);
                            }
                            break;
                        case 'radioother':
                            this.data.value.pages[pageid].questions[qid].ui = this.initRadiootherJson(qid, answers);
                            this.data.value.pages[pageid].questions[qid].values = this.valuesRadioother(qid, answers);
                            this.data.value.pages[pageid].questions[qid].options = this.getRadioOptions(pageid, qid);
                            //if answer is available, then only run validation in init
                            if (this.hasRadiootherValues(qid, answers)) {
                                this.validateRadioother(pageid, qid);
                            }
                            break;
                        case 'checkbox':
                            this.data.value.pages[pageid].questions[qid].ui = this.initCheckboxJson();
                            this.data.value.pages[pageid].questions[qid].values = this.valuesCheckbox(qid, answers);
                            this.data.value.pages[pageid].questions[qid].options = this.getCheckboxOptions(pageid, qid);
                            //if answer is available, then only run validation in init
                            if (this.hasCheckboxValues(qid, answers)) {
                                this.validateCheckbox(pageid, qid);
                            }
                            break;

                        case 'checkboxother':
                            this.data.value.pages[pageid].questions[qid].ui = this.initCheckboxotherJson(qid, answers);
                            this.data.value.pages[pageid].questions[qid].values = this.valuesCheckboxother(qid, answers);
                            this.data.value.pages[pageid].questions[qid].options = this.getCheckboxOptions(pageid, qid);
                            //if answer is available, then only run validation in init
                            if (this.hasCheckboxotherValues(qid, answers)) {
                                this.validateCheckboxother(pageid, qid);
                            }
                            break;
                        case 'datepicker':
                            this.data.value.pages[pageid].questions[qid].ui = this.initDatepickerJson();
                            this.data.value.pages[pageid].questions[qid].values = this.valuesDatepicker(qid, answers);
                            if (this.data.value.disableddates && this.data.value.disableddates[qid]) {
                                this.data.value.pages[pageid].questions[qid].disableddates = this.data.value.disableddates[qid];
                            }
                            //if answer is available, then only run validation in init
                            if (this.hasDatepickerValues(qid, answers)) {
                                this.validateDatepicker(pageid, qid);
                            }
                            break;
                        case 'timepicker':
                            this.data.value.pages[pageid].questions[qid].ui = this.initTimepickerJson();
                            this.data.value.pages[pageid].questions[qid].values = this.valuesTimepicker(qid, answers);
                            //if answer is available, then only run validation in init
                            if (this.hasTimepickerValues(qid, answers)) {
                                this.validateTimepicker(pageid, qid);
                            }
                            break;
                        case 'gmap':
                            this.data.value.pages[pageid].questions[qid].ui = this.initGmapJson(qid, answers);
                            this.data.value.pages[pageid].questions[qid].values = this.valuesGmap(pageid, qid, answers);
                            if (this.data.value.markers && this.data.value.markers[qid]) {
                                this.data.value.pages[pageid].questions[qid].extraMarkers = this.data.value.markers[qid];
                            }
                            //if answer is available, then only run validation in init
                            if (this.hasGmapValues(qid, answers)) {
                                this.validateGmap(pageid, qid);
                            }
                            break;
                        case 'gplacesearch':
                            console.debug('gplacesearch', this.data.value.pages.page1.id)
                            this.data.value.pages[pageid].questions[qid].ui = this.initGplacesearchJson();
                            this.data.value.pages[pageid].questions[qid].values = this.valuesGplacesearch(qid, answers);
                            //if answer is available, then only run validation in init
                            if (this.hasGplacesearchValues(qid, answers)) {
                                this.validateGplacesearch(pageid, qid);
                            }
                            break;
                        case 'autocomplete':
                            console.debug('autocomplete', this.data.value.pages.page1.id)
                            this.data.value.pages[pageid].questions[qid].ui = this.initAutocompleteJson();
                            this.data.value.pages[pageid].questions[qid].values = this.valuesAutocomplete(qid, answers);
                            //if answer is available, then only run validation in init
                            if (this.hasAutocompleteValues(qid, answers)) {
                                console.debug(this.data.value)
                                this.validateAutocomplete(pageid, qid);
                            }
                            break;
                        case 'email':
                            this.data.value.pages[pageid].questions[qid].ui = this.initEmailJson();
                            this.data.value.pages[pageid].questions[qid].values = this.valuesEmails(qid, answers);
                            if (this.hasEmailValues(qid, answers)) {
                                this.validateEmail(pageid, qid);
                            }
                            break;
                        case 'emaildnr':
                            this.data.value.pages[pageid].questions[qid].ui = this.initEmaildnrJson();
                            this.data.value.pages[pageid].questions[qid].values = this.valuesEmaildnr(qid, answers);
                            //if answer is available, then only run validation in init
                            if (this.hasEmaildnrValues(qid, answers)) {
                                this.validateEmaildnr(pageid, qid);
                            }
                            break;

                    }


                    //copy options radio, radioother, checkbox, checkboxother
                    // if (this.data.value.options && this.data.value.options[qid]) {
                    //     this.data.value.pages[pageid].questions[qid].options = this.getRadioOptions(pageid, qid);
                    // }

                }
            }
            //Init current page if not availble
            if (this.data.value.currentpage == undefined) {
                this.data.value.currentpage = this.data.value.startpage;
            }
            console.log(this.data.value);
        },
        /** Run validate for all visible components on page */
        validateSurveyPage: function (pageid) {

            this.validateSurveyPage(pageid);

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },
        findSurveyNextpage: function (pageid) {
            this.findSurveyNextpage(pageid);
            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        getSurveyAnswers: function () {
            let answers = {};

            for (const pageid in this.data.value.pages) {
                const page = this.data.value.pages[pageid];

                for (const qid in this.data.value.pages[pageid].questions) {
                    const question = this.data.value.pages[pageid].questions[qid];

                    switch (question.type) {
                        case 'hidden':
                            Object.assign(answers, this.answersHidden(pageid, qid));
                            break;
                        case 'text':
                            Object.assign(answers, this.answersText(pageid, qid));
                            break;
                        case 'textdnr':
                            Object.assign(answers, this.answersTextdnr(pageid, qid));
                            break;
                        case 'number':
                            Object.assign(answers, this.answersNumber(pageid, qid));
                            break;
                        case 'numberdnr':
                            Object.assign(answers, this.answersNumberdnr(pageid, qid));
                            break;
                        case 'radio':
                            Object.assign(answers, this.answersRadio(pageid, qid));
                            break;
                        case 'radioother':
                            Object.assign(answers, this.answersRadioother(pageid, qid));
                            break;
                        case 'checkbox':
                            Object.assign(answers, this.answersCheckbox(pageid, qid));
                            break;
                        case 'checkboxother':
                            Object.assign(answers, this.answersCheckboxother(pageid, qid));
                            break;
                        case 'datepicker':
                            Object.assign(answers, this.answersDatepicker(pageid, qid));
                            break;
                        case 'timepicker':
                            Object.assign(answers, this.answersTimepicker(pageid, qid));
                            break;
                        case 'gmap':
                            Object.assign(answers, this.answersGmap(pageid, qid));
                            break;
                        case 'gplacesearch':
                            Object.assign(answers, this.answersGplacesearch(pageid, qid));
                            break;
                        case 'autocomplete':
                            Object.assign(answers, this.answersAutocomplete(pageid, qid));
                            break;
                    }
                }
            }

            console.log(`getSurveyAnswers`);
            console.log(answers);
            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /** Update Visibility */
        exeSurveyLogic: function () {
            this.exeSurveyLogic();
            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Gmap */
        validateGmap: function (pageid, qcode) {
            this.validateGmap(pageid, qcode);

            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Gmap */
        setGmapValues: function (pageid, qcode, lat, lng, searchtext, searchplaceid, placeid, placename, fulladdress, street, city, state, zip, county, country, studyarea) {
            this.setGmapValues(pageid, qcode, lat, lng, searchtext, searchplaceid, placeid, placename, fulladdress, street, city, state, zip, county, country, studyarea);

            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Gmap */
        onGmapsearchChange: function (pageid, qcode, value, placeid) {
            this.onGmapsearchChange(pageid, qcode, value, placeid);

            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Gmap */
        onGmapChange: function (pageid, qcode, searchtext, searchplaceid, lat, lng, placeid, placename, fulladdress, street, city, state, zip, county, country, studyarea) {

            this.onGmapChange(pageid, qcode, searchtext, searchplaceid, lat, lng, placeid, placename, fulladdress, street, city, state, zip, county, country, studyarea);
            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },

        /* ========================= Gplacesearch ========================= */
        onGplacesearchChange: function (pageid, qcode, value, placeid) {
            this.onGplacesearchChange(pageid, qcode, value, placeid);

            // this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },

        setGplacesearchValues: function (pageid, qcode, value, placeid) {

            this.setGplacesearchValues(pageid, qcode, value, placeid);

            // this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },

        validateGplacesearch: function (pageid, qcode) {
            this.validateGplacesearch(pageid, qcode);

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);


        },
        /* ========================= Gplacesearch ========================= */

        /* ========================= Autocomplete ========================= */

        onAutocompleteChange: function (pageid, qcode, value) {
            this.onAutocompleteChange(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },

        setAutocompleteValues: function (pageid, qcode, value) {
            this.setAutocompleteValues(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },

        validateAutocomplete: function (pageid, qcode) {
            this.validateAutocomplete(pageid, qcode)

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },

        /* ========================= Autocomplete ========================= */

        /**Timepicker*/
        validateTimepicker: function (pageid, qcode) {
            this.validateTimepicker(pageid, qcode);
            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Timepicker*/
        setTimepickerValues: function (pageid, qcode, value) {
            this.setTimepickerValues(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Timepicker*/
        onTimepickerChange: function (pageid, qcode, value) {
            this.onTimepickerChange(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Datepicker*/
        validateDatepicker: function (pageid, qcode) {
            this.validateDatepicker(pageid, qcode);
            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Datepicker*/
        setDatepickerValues: function (pageid, qcode, value) {
            this.setDatepickerValues(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Datepicker */
        onDatepickerText: function (pageid, qcode, value) {

            this.onDatepickerText(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Datepicker*/
        onDatepickerChange: function (pageid, qcode, value) {
            this.onDatepickerChange(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /** Checkboxother */
        validateCheckboxother: function (pageid, qcode) {
            this.validateCheckboxother(pageid, qcode);

            //Setting value null and then with obj updates screen
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /** Checkboxother */
        setCheckboxotherValues: function (pageid, qcode, values, other) {

            this.setCheckboxotherValues(pageid, qcode, values, other)

            //Setting value null and then with obj updates screen
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },
        /** Checkboxother */
        onCheckboxotherOther: function (pageid, qcode, other) {

            this.onCheckboxotherOther(pageid, qcode, other);

            this.exeSurveyLogic();

            //Setting value null and then with obj updates screen
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /** Checkboxother */
        onCheckboxotherChange: function (pageid, qcode, value, checked) {

            this.onCheckboxotherChange(pageid, qcode, value, checked);

            this.exeSurveyLogic();

            //Setting value null and then with obj updates screen
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /** Checkbox */
        validateCheckbox: function (pageid, qcode) {
            this.validateCheckbox(pageid, qcode);
            //Setting value null and then with obj updates screen
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /** Checkbox */
        setCheckboxValues: function (pageid, qcode, checked) {
            this.setCheckboxValues(pageid, qcode, checked);

            this.exeSurveyLogic();
            //Setting value null and then with obj updates screen
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /** Checkbox */
        onCheckboxChange: function (pageid, qcode, value, checked) {
            this.onCheckboxChange(pageid, qcode, value, checked);

            this.exeSurveyLogic();

            //Setting value null and then with obj updates screen
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Radioother*/
        validateRadioother: function (pageid, qcode) {

            this.validateRadioother(pageid, qcode);

            //Setting value null and then with obj updates screen
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

            //If i fire updated event with below its not working. dont know reason
            // dmx.nextTick(function () {
            //     this.dispatchEvent('updated');
            // }, this);
        },
        setRadiootherValues: function (pageid, qcode, value, other) {
            this.setRadiootherValues(pageid, qcode, value, other);

            this.exeSurveyLogic();

            //Setting value null and then with obj updates screen
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Radioother */
        onRadiootherOther: function (pageid, qcode, other) {
            this.onRadiootherOther(pageid, qcode, other);

            this.exeSurveyLogic();

            //Setting value null and then with obj updates screen
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Radioother*/
        onRadiootherChange: function (pageid, qcode, value) {
            //Set value in survey object
            this.onRadiootherChange(pageid, qcode, value);

            this.exeSurveyLogic();

            //Setting value null and then with obj updates screen
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Radio*/
        validateRadio: function (pageid, qcode) {

            this.validateRadio(pageid, qcode);

            //Setting value null and then with obj updates screen
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Radio*/
        setRadioValues: function (pageid, qcode, value) {
            this.setRadioValues(pageid, qcode, value);

            this.exeSurveyLogic();

            //Setting value null and then with obj updates screen
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Radio*/
        onRadioChange: function (pageid, qcode, value) {
            this.onRadioChange(pageid, qcode, value);

            this.exeSurveyLogic();

            //Setting value null and then with obj updates screen
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Numberdnr */
        validateNumberdnr: function (pageid, qcode) {

            this.validateNumberdnr(pageid, qcode);

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        setNumberdnrValues: function (pageid, qcode, value, dontknow, refuse) {

            this.setNumberdnrValues(pageid, qcode, value, dontknow, refuse);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Numberdnr*/
        onNumberdnrRefuse: function (pageid, qcode, value) {
            this.onNumberdnrRefuse(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },
        /**Numberdnr*/
        onNumberdnrDontknow: function (pageid, qcode, value) {
            this.onNumberdnrDontknow(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },
        /**Numberdnr */
        onNumberdnrChange: function (pageid, qcode, value) {
            this.onNumberdnrChange(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },
        /**Number */
        validateNumber: function (pageid, qcode) {
            if (this.data.value == null) {
                console.log('Null value in survey engine while calling validateNumber');
                return;
            }

            this.validateNumber(pageid, qcode);

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },
        /**Number */
        setNumberValues: function (pageid, qcode, value) {
            this.setNumberValues(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },
        /**Number */
        onNumberChange: function (pageid, qcode, value) {
            this.onNumberChange(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },
        /**TextDnr*/
        validateTextdnr: function (pageid, qcode) {
            this.validateTextdnr(pageid, qcode);

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);


        },
        /**TextDnr*/
        setTextdnrValues: function (pageid, qcode, value, dontknow, refuse) {

            this.setTextdnrValues(pageid, qcode, value, dontknow, refuse);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },
        /**TextDnr*/
        onTextdnrRefuse: function (pageid, qcode, value) {
            this.onTextdnrRefuse(pageid, qcode, value)

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },
        /**TextDnr*/
        onTextdnrDontknow: function (pageid, qcode, value) {
            this.onTextdnrDontknow(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },
        /**TextDnr*/
        onTextdnrChange: function (pageid, qcode, value) {

            this.onTextdnrChange(pageid, qcode, value);

            this.validateTextdnr(pageid, qcode);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },
        /**Text*/
        validateText: function (pageid, qcode) {
            this.validateText(pageid, qcode);
            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Text*/
        setTextValues: function (pageid, qcode, value) {
            this.setTextValues(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Text*/
        onTextChange: function (pageid, qcode, value) {
            this.onTextChange(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Emaildnr*/
        validateEmaildnr: function (pageid, qcode) {
            this.validateEmaildnr(pageid, qcode);

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);


        },
        /**Emaildnr*/
        setEmaildnrValues: function (pageid, qcode, value, dontknow, refuse) {

            this.setEmaildnrValues(pageid, qcode, value, dontknow, refuse);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },
        /**Emaildnr*/
        onEmaildnrRefuse: function (pageid, qcode, value) {
            this.onEmaildnrRefuse(pageid, qcode, value)

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },
        /**Emaildnr*/
        onEmaildnrDontknow: function (pageid, qcode, value) {
            this.onEmaildnrDontknow(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },
        /**Emaildnr*/
        onEmaildnrChange: function (pageid, qcode, value) {

            this.onEmaildnrChange(pageid, qcode, value);

            this.validateEmaildnr(pageid, qcode);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);

        },
        /**Email*/
        validateEmail: function (pageid, qcode) {
            this.validateEmail(pageid, qcode);
            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Email*/
        setEmailValues: function (pageid, qcode, value) {
            this.setEmailValues(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
        /**Email*/
        onEmailChange: function (pageid, qcode, value) {
            this.onEmailChange(pageid, qcode, value);

            this.exeSurveyLogic();

            //Update ui
            let tmp = this.data.value; this.set("value", null); this.set("value", tmp);
        },
    },
    /****** Method ends here ******/
    /* Survey engine: Update visibility */
    exeSurveyLogic: function () {

        for (const pageid in this.data.value.pages) {
            const page = this.data.value.pages[pageid];
            //console.log(`Page`);
            //console.log(page);

            for (const qid in this.data.value.pages[pageid].questions) {
                const question = this.data.value.pages[pageid].questions[qid];
                //console.log(`Question`);
                //console.log(question);

                //updated placeholder text in label
                if (question.labels && question.labels.qtext) {
                    //Store original string with placeholder
                    if (!question.labels.qtext_orig) {
                        question.labels.qtext_orig = question.labels.qtext;
                    }
                    question.labels.qtext = this.replacePlaceholder(question.labels.qtext_orig);
                }

                //updte visibility
                if (question.show) {
                    const isvisible = this.parseGroup(question.show, '  ');
                    //if visibility changed and we needed to add some code
                    // if (isvisible !== question.ui.visible) {
                    //     switch (question.type) {
                    //         case 'text':
                    //             if (isvisible) {
                    //                 this.visibleText(pageid, qid);
                    //             } else {
                    //                 this.invisibleText(pageid, qid);
                    //             }
                    //             break;
                    //         case 'textdnr':
                    //             break;
                    //         case 'number':
                    //             break;
                    //         case 'numberdnr':
                    //             break;
                    //         case 'radio':
                    //             break;
                    //         case 'radioother':
                    //             break;
                    //         case 'checkbox':
                    //             break;
                    //         case 'checkboxother':
                    //             break;
                    //         case 'datepicker':
                    //             break;
                    //         case 'timepicker':
                    //             break;
                    //         case 'gmap':
                    //             break;
                    //     }
                    // }
                    question.ui.visible = isvisible
                }
            }
        }

        console.log(`exeSurveyLogic`);
        console.log(this.data.value);
        this.findSurveyNextpage(this.data.value.currentpage);
    },
    /** Survey engine: Run validate for all visible components on page */
    validateSurveyPage: function (pageid) {

        let pagevalid = true;

        for (const qid in this.data.value.pages[pageid].questions) {
            const question = this.data.value.pages[pageid].questions[qid];
            if (question.ui.visible) {
                switch (question.type) {
                    //Hidden field is excluded from validation                    
                    case 'text':
                        this.validateText(pageid, qid);
                        pagevalid = pagevalid && question.ui.valid;
                        break;
                    case 'textdnr':
                        this.validateTextdnr(pageid, qid);
                        pagevalid = pagevalid && question.ui.valid;
                        break;
                    case 'number':
                        this.validateNumber(pageid, qid);
                        pagevalid = pagevalid && question.ui.valid && question.ui.validmin && question.ui.validmax;
                        break;
                    case 'numberdnr':
                        this.validateNumberdnr(pageid, qid);
                        pagevalid = pagevalid && question.ui.valid && question.ui.validmin && question.ui.validmax;
                        break;
                    case 'radio':
                        this.validateRadio(pageid, qid);
                        pagevalid = pagevalid && question.ui.valid;
                        break;
                    case 'radioother':
                        this.validateRadioother(pageid, qid);
                        pagevalid = pagevalid && question.ui.valid && question.ui.validother;
                        break;
                    case 'checkbox':
                        this.validateCheckbox(pageid, qid);
                        pagevalid = pagevalid && question.ui.valid;
                        break;
                    case 'checkboxother':
                        this.validateCheckboxother(pageid, qid);
                        pagevalid = pagevalid && question.ui.valid && question.ui.validother;
                        break;
                    case 'datepicker':
                        this.validateDatepicker(pageid, qid);
                        pagevalid = pagevalid && question.ui.valid;
                        break;
                    case 'timepicker':
                        this.validateTimepicker(pageid, qid);
                        pagevalid = pagevalid && question.ui.valid;
                        break;
                    case 'gmap':
                        this.validateGmap(pageid, qid);
                        pagevalid = pagevalid && question.ui.valid;
                        break;
                    case 'gplacesearch':
                        this.validateGplacesearch(pageid, qid);
                        pagevalid = pagevalid && question.ui.valid;
                        break;
                    case 'autocomplete':
                        this.validateAutocomplete(pageid, qid);
                        pagevalid = pagevalid && question.ui.valid;
                        break;
                }
                console.log(`pagevalid: ${question.id}: ${pagevalid}`);
            }

        }

        this.data.value.pages[pageid].isvalid = pagevalid;

    },
    /**Survey engine: find next visible page based on answers given */
    findSurveyNextpage: function (pageid) {
        console.log(`findSurveyNextpage(${pageid})`);
        const page = this.data.value.pages[pageid];

        if (page.nextpage && page.nextpage != "end") {
            let nextpageid = page.nextpage;

            if (!this.hasPageVisibleQuestion(nextpageid)) {
                this.findSurveyNextpage(nextpageid);
            } else {
                this.data.value.nextpage = nextpageid;
            }
        } else {
            this.data.value.nextpage = "end";
        }
    },
    /**Survey engine: check if page has any visible question based on visible condition */
    hasPageVisibleQuestion: function (pageid) {
        console.log(`hasPageVisibleQuestion(${pageid})`);
        let result = false;
        for (const qid in this.data.value.pages[pageid].questions) {
            const question = this.data.value.pages[pageid].questions[qid];
            console.log(`${question.id} - ${question.ui.visible}`);
            result = result || question.ui.visible;
        }
        return result;
    },
    /*Gmap*/
    validateGmap: function (pageid, qcode) {
        if (this.data.value.pages[pageid].questions[qcode].required) {
            if (this.data.value.pages[pageid].questions[qcode].values['lat'] &&
                this.data.value.pages[pageid].questions[qcode].values['lng']) {
                this.data.value.pages[pageid].questions[qcode].ui.valid = true;

            } else {
                this.data.value.pages[pageid].questions[qcode].ui.valid = false;
            }
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.valid = true;
        }

        if (this.data.value.pages[pageid].questions[qcode].ui.valid) {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "is-valid";
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "is-invalid";
        }
        console.debug(this.data.value.pages[pageid].questions[qcode])
    },
    /*Gmap*/
    setGmapValues: function (pageid, qcode, lat, lng, searchtext, searchplaceid, placeid, placename, fulladdress, street, city, state, zip, county, country, studyarea) {
        //console.debug('setGmapValues', pageid, qcode, lat, lng, placeid, placename, fulladdress, address, city, state, zip, county, country, studyarea)

        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['lat'] = lat;
        this.data.value.pages[pageid].questions[qcode].values['lng'] = lng;
        this.data.value.pages[pageid].questions[qcode].values['searchtext'] = searchtext;
        this.data.value.pages[pageid].questions[qcode].values['searchplaceid'] = searchplaceid;
        this.data.value.pages[pageid].questions[qcode].values['placeid'] = placeid;
        this.data.value.pages[pageid].questions[qcode].values['placename'] = placename;
        this.data.value.pages[pageid].questions[qcode].values['fulladdress'] = fulladdress;
        this.data.value.pages[pageid].questions[qcode].values['street'] = street;
        this.data.value.pages[pageid].questions[qcode].values['city'] = city;
        this.data.value.pages[pageid].questions[qcode].values['state'] = state;
        this.data.value.pages[pageid].questions[qcode].values['zip'] = zip;
        this.data.value.pages[pageid].questions[qcode].values['county'] = county;
        this.data.value.pages[pageid].questions[qcode].values['country'] = country;
        this.data.value.pages[pageid].questions[qcode].values['studyarea'] = studyarea;

        this.validateGmap(pageid, qcode);

    },
    /*Gmap*/
    onGmapsearchChange: function (pageid, qcode, value, placeid) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['searchtext'] = value;
        this.data.value.pages[pageid].questions[qcode].values['searchplaceid'] = placeid;
    },
    /*Gmap*/
    onGmapChange: function (pageid, qcode, searchtext, searchplaceid, lat, lng, placeid, placename, fulladdress, street, city, state, zip, county, country, studyarea) {
        console.log(`onMapChange(${pageid},${qcode},${lat},${lng},${placeid},${placename},${fulladdress},${street},${city},${state},${zip},${county},${country},${studyarea})`);

        console.log(this.data.value.pages[pageid].questions[qcode].values);
        this.data.value.pages[pageid].questions[qcode].values['searchtext'] = searchtext;
        this.data.value.pages[pageid].questions[qcode].values['searchplaceid'] = searchplaceid;
        this.data.value.pages[pageid].questions[qcode].values['lat'] = lat;
        this.data.value.pages[pageid].questions[qcode].values['lng'] = lng;
        this.data.value.pages[pageid].questions[qcode].values['placeid'] = placeid;
        this.data.value.pages[pageid].questions[qcode].values['placename'] = placename;
        this.data.value.pages[pageid].questions[qcode].values['fulladdress'] = fulladdress;
        this.data.value.pages[pageid].questions[qcode].values['street'] = street;
        this.data.value.pages[pageid].questions[qcode].values['city'] = city;
        this.data.value.pages[pageid].questions[qcode].values['state'] = state;
        this.data.value.pages[pageid].questions[qcode].values['zip'] = zip;
        this.data.value.pages[pageid].questions[qcode].values['county'] = county;
        this.data.value.pages[pageid].questions[qcode].values['country'] = country;
        this.data.value.pages[pageid].questions[qcode].values['studyarea'] = studyarea;

        this.validateGmap(pageid, qcode);

        this.exeSurveyLogic();
    },
    /*Gmap*/
    hasGmapValues: function (qcode, answers) {
        if (answers && answers[`${qcode}_lat`] && answers[`${qcode}_lng`]) {
            return true;
        }
        return false;
    },
    /**Gmap */
    valuesGmap: function (pageid, qcode, answers) {
        //Checkbox mutliple values are saved single colum with ; separated string
        const question = this.data.value.pages[pageid].questions[qcode];
        const obj = {};
        const keys = question.dbfields.split('|');
        keys.forEach((key) => {
            obj[`${key}`] = (answers && answers[`${qcode}_${key}`]) ? answers[`${qcode}_${key}`] : ""
        });

        return obj;


        // return {
        //     "placename": (answers && answers[`${qcode}_placename`]) ? answers[`${qcode}_placename`] : "",
        //     "address": (answers && answers[`${qcode}_address`]) ? answers[`${qcode}_address`] : "",
        //     "city": (answers && answers[`${qcode}_city`]) ? answers[`${qcode}_city`] : "",
        //     "state": (answers && answers[`${qcode}_state`]) ? answers[`${qcode}_state`] : "",
        //     "zip": (answers && answers[`${qcode}_zip`]) ? answers[`${qcode}_zip`] : "",
        //     "county": (answers && answers[`${qcode}_county`]) ? answers[`${qcode}_county`] : "",
        //     "country": (answers && answers[`${qcode}_country`]) ? answers[`${qcode}_country`] : "",
        //     "studyarea": (answers && answers[`${qcode}_studyarea`]) ? answers[`${qcode}_studyarea`] : "",
        //     "lat": (answers && answers[`${qcode}_lat`]) ? answers[`${qcode}_lat`] : "",
        //     "lng": (answers && answers[`${qcode}_lng`]) ? answers[`${qcode}_lng`] : "",
        // };
    },
    /**Gmap */
    answersGmap: function (pageid, qcode) {
        const question = this.data.value.pages[pageid].questions[qcode];
        const obj = {};
        const keys = question.dbfields.split('|');
        keys.forEach((key) => {
            obj[`${qcode}_${key}`] = question.values[key];
        })

        return obj;

    },
    /*Gmap*/
    initGmapJson: function (qcode, answers) {
        return {
            "visible": true,
            "valid": true,
            "uiclass": ""
        }
    },
    /* Gplacesearch */
    validateGplacesearch: function (pageid, qcode) {
        if (this.data.value.pages[pageid].questions[qcode].required) {
            if (this.data.value.pages[pageid].questions[qcode].values['text']) {
                this.data.value.pages[pageid].questions[qcode].ui.valid = true;
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.valid = false;
            }
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.valid = true;
        }

        if (this.data.value.pages[pageid].questions[qcode].ui.valid) {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "is-valid";
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "is-invalid";
        }
    },
    /* Gplacesearch */
    setGplacesearchValues: function (pageid, qcode, value, placeid) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['text'] = value;
        this.data.value.pages[pageid].questions[qcode].values['placeid'] = placeid;

        this.validateGplacesearch(pageid, qcode);

    },
    /* Gplacesearch */
    onGplacesearchChange: function (pageid, qcode, value, placeid) {
        //Set value in survey object

        this.data.value.pages[pageid].questions[qcode].values['text'] = value;
        this.data.value.pages[pageid].questions[qcode].values['placeid'] = placeid;

        this.validateGplacesearch(pageid, qcode);

    },
    /* Gplacesearch */
    hasGplacesearchValues: function (qcode, answers) {
        if (answers && answers[qcode]) {
            return true;
        }
        return false;
    },
    /* Gplacesearch */
    valuesGplacesearch: function (qcode, answers) {
        return {
            "text": (answers && answers[qcode]) ? answers[qcode] : "",
            "placeid": (answers && answers[`${qcode}_placeid`]) ? answers[`${qcode}_placeid`] : ""
        };
    },
    /* Gplacesearch */
    answersGplacesearch: function (pageid, qcode) {
        const question = this.data.value.pages[pageid].questions[qcode];
        const obj = {};
        obj[`${question.id}`] = question.values.text
        obj[`${question.id}_placeid`] = question.values.placeid
        return obj;
    },
    /* Gplacesearch */
    initGplacesearchJson: function () {
        return {
            "visible": true,
            "valid": true,
            "uiclass": ""
        }
    },
    /* Autocomplete */
    initAutocompleteJson: function () {
        return {
            "visible": true,
            "valid": true,
            "uiclass": ""
        }
    },
    /* Autocomplete */
    valuesAutocomplete: function (qcode, answers) {
        return {
            "text": (answers && answers[qcode]) ? answers[qcode] : ""
        };
    },
    /* Autocomplete */
    hasAutocompleteValues: function (qcode, answers) {
        if (answers && answers[qcode]) {
            return true;
        }
        return false;
    },
    /* Autocomplete */
    validateAutocomplete: function (pageid, qcode) {
        if (this.data.value.pages[pageid].questions[qcode].required) {
            if (this.data.value.pages[pageid].questions[qcode].values['text']) {
                this.data.value.pages[pageid].questions[qcode].ui.valid = true;
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.valid = false;
            }
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.valid = true;
        }

        if (this.data.value.pages[pageid].questions[qcode].ui.valid) {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "is-valid";
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "is-invalid";
        }
    },
    /* Autocomplete */
    setAutocompleteValues: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['text'] = value;

        this.validateAutocomplete(pageid, qcode);

    },
    /* Autocomplete */
    onAutocompleteChange: function (pageid, qcode, value) {
        //Set value in survey object

        this.data.value.pages[pageid].questions[qcode].values['text'] = value;

        console.debug(value)
        console.debug(this.data.value.pages[pageid].questions[qcode].values)

        this.validateAutocomplete(pageid, qcode);

    },
    /* Autocomplete */
    answersAutocomplete: function (pageid, qcode) {
        const question = this.data.value.pages[pageid].questions[qcode];
        const obj = {};
        obj[`${question.id}`] = question.values.text
        return obj;
    },
    /*Timepicker*/
    validateTimepicker: function (pageid, qcode) {
        if (this.data.value.pages[pageid].questions[qcode].required) {
            if (this.data.value.pages[pageid].questions[qcode].values['time']) {
                this.data.value.pages[pageid].questions[qcode].ui.valid = true;
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.valid = false;
            }
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.valid = true;
        }

        if (this.data.value.pages[pageid].questions[qcode].ui.valid) {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control is-valid";
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control is-invalid";
        }
    },
    /*Timepicker*/
    setTimepickerValues: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['time'] = value;

        this.validateTimepicker(pageid, qcode);

    },
    /*Timepicker*/
    onTimepickerChange: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['time'] = value;
        this.validateTimepicker(pageid, qcode);

    },
    /*Timepicker*/
    hasTimepickerValues: function (qcode, answers) {
        if (answers && answers[qcode]) {
            return true;
        }
        return false;
    },
    /*Timepicker*/
    valuesTimepicker: function (qcode, answers) {
        return {
            "time": (answers && answers[qcode]) ? answers[qcode] : ""
        };
    },
    /*Timepicker*/
    answersTimepicker: function (pageid, qcode) {
        const question = this.data.value.pages[pageid].questions[qcode];
        const obj = {};
        obj[`${question.id}`] = question.values.time
        return obj;
    },
    /*Timepicker*/
    initTimepickerJson: function () {
        return {
            "visible": true,
            "valid": true,
            "uiclass": "form-control"
        }
    },
    /*Datepicker*/
    validateDatepicker: function (pageid, qcode) {
        if (this.data.value.pages[pageid].questions[qcode].required) {
            if (this.data.value.pages[pageid].questions[qcode].values['date']) {
                this.data.value.pages[pageid].questions[qcode].ui.valid = true;
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.valid = false;
            }
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.valid = true;
        }

        if (this.data.value.pages[pageid].questions[qcode].ui.valid) {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control is-valid";
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control is-invalid";
        }
    },
    /*Datepicker*/
    setDatepickerValues: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['date'] = value;

        this.validateDatepicker(pageid, qcode);

    },
    /*Datepicker*/
    onDatepickerText: function (pageid, qcode, value) {

        const regexDDMMYYYY = /^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(19|20)\d{2}$/

        if (regexDDMMYYYY.test(value)) {
            //Set value in survey object
            this.data.value.pages[pageid].questions[qcode].ui.validformat = true;
            this.onDatepickerChange(pageid, qcode, value)
        } else {
            //Set null value if date format is incorrect
            this.data.value.pages[pageid].questions[qcode].ui.validformat = false;
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control is-invalid";
        }
    },
    /*Datepicker*/
    onDatepickerChange: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['date'] = value;

        this.validateDatepicker(pageid, qcode);

    },
    /*Datepicker*/
    hasDatepickerValues: function (qcode, answers) {
        if (answers && answers[qcode]) {
            return true;
        }
        return false;
    },
    /*Datepicker*/
    valuesDatepicker: function (qcode, answers) {
        return {
            "date": (answers && answers[qcode]) ? answers[qcode] : ""
        };
    },
    /*Datepicker*/
    answersDatepicker: function (pageid, qcode) {
        const question = this.data.value.pages[pageid].questions[qcode];
        const obj = {};
        obj[`${question.id}`] = question.values.date
        return obj;
    },
    /*Datepicker*/
    initDatepickerJson: function () {
        return {
            "visible": true,
            "valid": true,
            "uiclass": "form-control"
        }
    },
    /*Checkboxother*/
    validateCheckboxother: function (pageid, qcode) {
        if (this.data.value.pages[pageid].questions[qcode].required) {
            if (this.data.value.pages[pageid].questions[qcode].values['checked'].length > 0) {
                this.data.value.pages[pageid].questions[qcode].ui.valid = true;

                //Validate other if visible
                if (this.data.value.pages[pageid].questions[qcode].hasother &&
                    this.data.value.pages[pageid].questions[qcode].values['checked'].includes(this.data.value.pages[pageid].questions[qcode].hasother) &&
                    this.data.value.pages[pageid].questions[qcode].requiredother
                ) {

                    if (this.data.value.pages[pageid].questions[qcode].values['other']) {
                        this.data.value.pages[pageid].questions[qcode].ui.validother = true;
                    } else {
                        this.data.value.pages[pageid].questions[qcode].ui.validother = false;
                    }

                    //ui class other box
                    if (this.data.value.pages[pageid].questions[qcode].ui.validother) {
                        this.data.value.pages[pageid].questions[qcode].ui.otheruiclass = "form-control is-valid";
                    } else {
                        this.data.value.pages[pageid].questions[qcode].ui.otheruiclass = "form-control is-invalid";
                    }

                } else {
                    this.data.value.pages[pageid].questions[qcode].ui.validother = true;
                }
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.valid = false;
            }
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.valid = true;
        }
    },
    /** Checkboxother */
    setCheckboxotherValues: function (pageid, qcode, values, other = null) {

        if (values) {
            this.data.value.pages[pageid].questions[qcode].values['checked'] = values.split(';');
        } else {
            this.data.value.pages[pageid].questions[qcode].values['checked'] = [];
        }

        //Other
        if (this.data.value.pages[pageid].questions[qcode].hasother) {
            if (this.data.value.pages[pageid].questions[qcode].values['checked'].includes(
                this.data.value.pages[pageid].questions[qcode].hasother)) {
                this.data.value.pages[pageid].questions[qcode].ui.visibleother = true;
                this.data.value.pages[pageid].questions[qcode].values['other'] = other;
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.visibleother = false;
                this.data.value.pages[pageid].questions[qcode].values['other'] = "";
            }
        }

        this.validateCheckboxother(pageid, qcode);

    },
    /*Checkboxother*/
    onCheckboxotherOther: function (pageid, qcode, other) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['other'] = other;

        this.validateCheckboxother(pageid, qcode);
    },
    /*Checkboxother*/
    onCheckboxotherChange: function (pageid, qcode, value, checked) {
        console.log(`onCheckboxotherChange(${pageid},${qcode},${value},${checked})`);

        //Set value in survey object
        if (checked) {
            this.data.value.pages[pageid].questions[qcode].values['checked'].push(value);
        } else {
            this.data.value.pages[pageid].questions[qcode].values['checked'].splice(this.data.value.pages[pageid].questions[qcode].values['checked'].indexOf(value), 1);
        }

        //visible other 
        if (this.data.value.pages[pageid].questions[qcode].hasother) {

            console.log(this.data.value.pages[pageid].questions[qcode].values['checked']);

            if (this.data.value.pages[pageid].questions[qcode].values['checked'].includes(this.data.value.pages[pageid].questions[qcode].hasother)) {
                this.data.value.pages[pageid].questions[qcode].ui.visibleother = true;
                this.data.value.pages[pageid].questions[qcode].ui.validother = true;
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.visibleother = false;
                this.data.value.pages[pageid].questions[qcode].values['other'] = '';
                this.data.value.pages[pageid].questions[qcode].ui.validother = true;
            }
        }

        //ui class other box
        if (this.data.value.pages[pageid].questions[qcode].ui.validother) {
            this.data.value.pages[pageid].questions[qcode].ui.otheruiclass = "form-control";
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.otheruiclass = "form-control is-invalid";
        }

        //main validation
        if (this.data.value.pages[pageid].questions[qcode].values['checked'].length > 0) {
            this.data.value.pages[pageid].questions[qcode].ui.valid = true;
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.valid = false;
        }
    },
    /*Checkboxother*/
    hasCheckboxotherValues: function (qcode, answers) {
        if (answers && answers[qcode]) {
            return true;
        }
        return false;
    },
    /*Checkboxother*/
    valuesCheckboxother: function (qcode, answers) {
        //Checkbox mutliple values are saved single colum with ; separated string
        return {
            "checked": (answers && answers[qcode]) ? answers[qcode].split(';') : [],
            "other": (answers && answers[`${qcode}_other`]) ? answers[`${qcode}_other`] : "",
        };
    },
    /*Checkboxother*/
    answersCheckboxother: function (pageid, qcode) {
        const question = this.data.value.pages[pageid].questions[qcode];
        const obj = {};
        obj[`${question.id}`] = (question.values.checked &&
            Array.isArray(question.values.checked) &&
            question.values.checked.length > 0) ? question.values.checked.join(';') : null;
        obj[`${question.id}_other`] = question.values.other;
        return obj;
    },
    /*Checkboxother*/
    initCheckboxotherJson: function (qcode, answers) {
        return {
            "visible": true,
            "valid": true,
            "visibleother": (answers && answers[`${qcode}_other`]) ? true : false,
            "validother": true,
        }
    },

    /*Checkbox*/
    validateCheckbox: function (pageid, qcode) {
        if (this.data.value.pages[pageid].questions[qcode].required) {
            if (this.data.value.pages[pageid].questions[qcode].values['checked'].length > 0) {
                this.data.value.pages[pageid].questions[qcode].ui.valid = true;
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.valid = false;
            }
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.valid = true;
        }

    },
    /*Checkbox*/
    setCheckboxValues: function (pageid, qcode, checked) {
        if (checked) {
            this.data.value.pages[pageid].questions[qcode].values['checked'] = checked.split(';');
        } else {
            this.data.value.pages[pageid].questions[qcode].values['checked'] = [];
        }

        this.validateCheckbox(pageid, qcode);
    },
    /*Checkbox*/
    onCheckboxChange: function (pageid, qcode, value, checked) {
        //Set value in survey object
        if (checked) {
            this.data.value.pages[pageid].questions[qcode].values['checked'].push(value);
        } else {
            this.data.value.pages[pageid].questions[qcode].values['checked'].splice(this.data.value.pages[pageid].questions[qcode].values['checked'].indexOf(value), 1);
        }

        this.validateCheckbox(pageid, qcode);
    },
    /**Checkbox*/
    getCheckboxOptions: function (pageid, qid) {
        //Sort all option 
        this.data.value.options[qid].sort((a, b) => a.seq - b.seq);

        //Set checked flag if its in value
        this.data.value.options[qid].forEach((item) => {
            item.checked = this.data.value.pages[pageid].questions[qid].values.checked && this.data.value.pages[pageid].questions[qid].values.checked.includes(item.key);
        });

        //Single column to multiple column
        let cols = this.data.value.pages[pageid].questions[qid].optioncols ? parseInt(this.data.value.pages[pageid].questions[qid].optioncols) : 1;
        let size = Math.ceil(this.data.value.options[qid].length / cols);
        const coloptions = {};
        for (let i = 0; i < cols; i++) {
            coloptions['col' + (i + 1)] = this.data.value.options[qid].slice(i * size, i * size + size)
        }

        return coloptions;
    },
    /*Checkbox*/
    hasCheckboxValues: function (qcode, answers) {
        if (answers && answers[qcode]) {
            return true;
        }
        return false;
    },
    /*Checkbox*/
    valuesCheckbox: function (qcode, answers) {
        //Checkbox mutliple values are saved single colum with ; separated string
        return {
            "checked": (answers && answers[qcode]) ? answers[qcode].split(';') : []
        };
    },
    /*Checkbox*/
    answersCheckbox: function (pageid, qcode) {
        const question = this.data.value.pages[pageid].questions[qcode];
        const obj = {};
        obj[`${question.id}`] = (question.values.checked &&
            Array.isArray(question.values.checked) &&
            question.values.checked.length > 0) ? question.values.checked.join(';') : null;
        return obj;
    },
    /*Checkbox*/
    initCheckboxJson: function () {
        return {
            "visible": true,
            "valid": true,
        }
    },
    /**Radioother*/
    validateRadioother: function (pageid, qcode) {
        //Validation
        if (this.data.value.pages[pageid].questions[qcode].required) {
            if (this.data.value.pages[pageid].questions[qcode].values['value']) {
                this.data.value.pages[pageid].questions[qcode].ui.valid = true;
                //Validate other if visible
                if (this.data.value.pages[pageid].questions[qcode].hasother &&
                    this.data.value.pages[pageid].questions[qcode].hasother == this.data.value.pages[pageid].questions[qcode].values['value'] &&
                    this.data.value.pages[pageid].questions[qcode].requiredother
                ) {

                    if (this.data.value.pages[pageid].questions[qcode].values['other']) {
                        this.data.value.pages[pageid].questions[qcode].ui.validother = true;
                    } else {
                        this.data.value.pages[pageid].questions[qcode].ui.validother = false;
                    }

                    //ui class other box
                    if (this.data.value.pages[pageid].questions[qcode].ui.validother) {
                        this.data.value.pages[pageid].questions[qcode].ui.otheruiclass = "form-control is-valid";
                    } else {
                        this.data.value.pages[pageid].questions[qcode].ui.otheruiclass = "form-control is-invalid";
                    }

                } else {
                    this.data.value.pages[pageid].questions[qcode].ui.validother = true;
                }

            } else {
                this.data.value.pages[pageid].questions[qcode].ui.valid = false;
            }
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.valid = true;
        }
    },
    /**Radioother*/
    setRadiootherValues: function (pageid, qcode, value, other) {
        this.data.value.pages[pageid].questions[qcode].values['value'] = value;
        if (this.data.value.pages[pageid].questions[qcode].hasother) {

            if (this.data.value.pages[pageid].questions[qcode].values['value'] ==
                this.data.value.pages[pageid].questions[qcode].hasother) {
                this.data.value.pages[pageid].questions[qcode].values['other'] = other;
                this.data.value.pages[pageid].questions[qcode].ui.visibleother = true;
            } else {
                this.data.value.pages[pageid].questions[qcode].values['other'] = '';
                this.data.value.pages[pageid].questions[qcode].ui.visibleother = false;
                this.data.value.pages[pageid].questions[qcode].ui.validother = true;
            }
        }
        this.validateRadioother(pageid, qcode);
    },
    /**Radioother*/
    onRadiootherOther: function (pageid, qcode, other) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['other'] = other;
        this.validateRadioother(pageid, qcode);

    },
    /**Radioother*/
    onRadiootherChange: function (pageid, qcode, value) {

        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['value'] = value;
        this.data.value.pages[pageid].questions[qcode].ui.valid = true;

        //visible other 
        if (this.data.value.pages[pageid].questions[qcode].hasother) {

            if (this.data.value.pages[pageid].questions[qcode].values['value'] ==
                this.data.value.pages[pageid].questions[qcode].hasother) {
                this.data.value.pages[pageid].questions[qcode].ui.visibleother = true;
                this.data.value.pages[pageid].questions[qcode].ui.validother = true;
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.visibleother = false;
                this.data.value.pages[pageid].questions[qcode].values['other'] = '';
                this.data.value.pages[pageid].questions[qcode].ui.validother = true;
            }
        }

        //ui class other box
        if (this.data.value.pages[pageid].questions[qcode].ui.validother) {
            this.data.value.pages[pageid].questions[qcode].ui.otheruiclass = "form-control";
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.otheruiclass = "form-control is-invalid";
        }
    },
    /*Radioother*/
    hasRadiootherValues: function (qcode, answers) {
        if (answers && (answers[qcode] || answers[`${qcode}_other`])) {
            return true;
        }
        return false;
    },
    /*Radioother*/
    valuesRadioother: function (qcode, answers) {
        return {
            "value": (answers && answers[qcode]) ? answers[qcode] : "",
            "other": (answers && answers[`${qcode}_other`]) ? answers[`${qcode}_other`] : "",
        };
    },
    /*Radioother*/
    answersRadioother: function (pageid, qcode) {
        const question = this.data.value.pages[pageid].questions[qcode];
        const obj = {};
        obj[`${question.id}`] = question.values.value;
        obj[`${question.id}_other`] = question.values.other;
        return obj;
    },
    /*Radioother*/
    initRadiootherJson: function (qcode, answers) {
        return {
            "visible": true,
            "valid": true,
            "visibleother": (answers && answers[`${qcode}_other`]) ? true : false,
            "validother": true,
            "otheruiclass": "form-control"
        }
    },
    /*Radio*/
    validateRadio: function (pageid, qcode) {
        if (this.data.value.pages[pageid].questions[qcode].required) {
            if (this.data.value.pages[pageid].questions[qcode].values['value']) {
                this.data.value.pages[pageid].questions[qcode].ui.valid = true;
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.valid = false;
            }
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.valid = true;
        }

    },
    /*Radio*/
    setRadioValues: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['value'] = value;
        this.validateRadio(pageid, qcode);

    },
    /*Radio*/
    onRadioChange: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['value'] = value;
        this.data.value.pages[pageid].questions[qcode].ui.valid = true;

    },
    /**Radio*/
    getRadioOptions: function (pageid, qid) {
        //Sort all option 
        this.data.value.options[qid].sort((a, b) => a.seq - b.seq);

        //Set checked flag if its in value
        this.data.value.options[qid].forEach((item) => {
            item.checked = this.data.value.pages[pageid].questions[qid].values.value && this.data.value.pages[pageid].questions[qid].values.value.includes(item.key);
        });

        //Single column to multiple column
        let cols = this.data.value.pages[pageid].questions[qid].optioncols ? parseInt(this.data.value.pages[pageid].questions[qid].optioncols) : 1;
        let size = Math.ceil(this.data.value.options[qid].length / cols);
        const coloptions = {};
        for (let i = 0; i < cols; i++) {
            coloptions['col' + (i + 1)] = this.data.value.options[qid].slice(i * size, i * size + size)
        }

        return coloptions;
    },
    /*Radio*/
    hasRadioValues: function (qcode, answers) {
        if (answers && answers[qcode]) {
            return true;
        }
        return false;
    },
    /*Radio*/
    valuesRadio: function (qcode, answers) {
        return {
            "value": (answers && answers[qcode]) ? answers[qcode] : ""
        };
    },
    /*Radio*/
    answersRadio: function (pageid, qcode) {
        const question = this.data.value.pages[pageid].questions[qcode];
        const obj = {};
        obj[`${question.id}`] = question.values.value;
        return obj;
    },
    /*Radio*/
    initRadioJson: function () {
        return {
            "visible": true,
            "valid": true,
        }
    },
    /*Numberdnr*/
    validateNumberdnr: function (pageid, qcode) {
        //validations
        //reset
        this.data.value.pages[pageid].questions[qcode].ui.valid =
            this.data.value.pages[pageid].questions[qcode].ui.validmin =
            this.data.value.pages[pageid].questions[qcode].ui.validmax = true;

        //required
        if (this.data.value.pages[pageid].questions[qcode].required) {
            if (this.data.value.pages[pageid].questions[qcode].values['num'] ||
                this.data.value.pages[pageid].questions[qcode].values['dontknow'] ||
                this.data.value.pages[pageid].questions[qcode].values['refuse']) {
                this.data.value.pages[pageid].questions[qcode].ui.valid = true;
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.valid = false;
            }
        }

        //min
        if (this.data.value.pages[pageid].questions[qcode].min &&
            this.data.value.pages[pageid].questions[qcode].ui.valid &&
            !this.data.value.pages[pageid].questions[qcode].values['dontknow'] &&
            !this.data.value.pages[pageid].questions[qcode].values['refuse']
        ) {
            if (this.data.value.pages[pageid].questions[qcode].values['num']) {
                if (parseFloat(this.data.value.pages[pageid].questions[qcode].values['num']) <
                    parseFloat(this.data.value.pages[pageid].questions[qcode].min)) {
                    this.data.value.pages[pageid].questions[qcode].ui.validmin = false;
                } else {
                    this.data.value.pages[pageid].questions[qcode].ui.validmin = true;
                }
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.validmin = false;
            }
        }
        //max
        if (this.data.value.pages[pageid].questions[qcode].max &&
            this.data.value.pages[pageid].questions[qcode].ui.valid &&
            this.data.value.pages[pageid].questions[qcode].ui.validmin &&
            !this.data.value.pages[pageid].questions[qcode].values['dontknow'] &&
            !this.data.value.pages[pageid].questions[qcode].values['refuse']
        ) {
            if (this.data.value.pages[pageid].questions[qcode].values['num']) {
                if (parseFloat(this.data.value.pages[pageid].questions[qcode].values['num']) >
                    parseFloat(this.data.value.pages[pageid].questions[qcode].max)) {
                    this.data.value.pages[pageid].questions[qcode].ui.validmax = false;
                } else {
                    this.data.value.pages[pageid].questions[qcode].ui.validmax = true;
                }
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.validmax = false;
            }
        }

        //ui
        //validation class
        if (this.data.value.pages[pageid].questions[qcode].ui.valid &&
            this.data.value.pages[pageid].questions[qcode].ui.validmin &&
            this.data.value.pages[pageid].questions[qcode].ui.validmax
        ) {
            if (!this.data.value.pages[pageid].questions[qcode].values['dontknow'] &&
                !this.data.value.pages[pageid].questions[qcode].values['refuse']) {
                this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control is-valid";
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control";
            }
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control is-invalid";
        }

        //placeholders in messages
        if (this.data.value.pages[pageid].questions[qcode].min) {
            if (!this.data.value.pages[pageid].questions[qcode].labels.validminorig) {
                this.data.value.pages[pageid].questions[qcode].labels.validminorig =
                    this.data.value.pages[pageid].questions[qcode].labels.validmin
            }
            this.data.value.pages[pageid].questions[qcode].labels.validmin =
                this.data.value.pages[pageid].questions[qcode].labels.validminorig.replace("{min}", this.data.value.pages[pageid].questions[qcode].min);
        }
        if (this.data.value.pages[pageid].questions[qcode].max) {
            if (!this.data.value.pages[pageid].questions[qcode].labels.validmaxorig) {
                this.data.value.pages[pageid].questions[qcode].labels.validmaxorig =
                    this.data.value.pages[pageid].questions[qcode].labels.validmax
            }
            this.data.value.pages[pageid].questions[qcode].labels.validmax =
                this.data.value.labels[qcode].validmaxorig.replace("{max}", this.data.value.pages[pageid].questions[qcode].max);
        }

    },
    /*Numberdnr*/
    setNumberdnrValues: function (pageid, qcode, value, dontknow, refuse) {
        this.data.value.pages[pageid].questions[qcode].values['num'] = value;
        this.data.value.pages[pageid].questions[qcode].values['dontknow'] = dontknow ? '1' : null;
        this.data.value.pages[pageid].questions[qcode].values['refuse'] = refuse ? '1' : null;

        this.validateNumberdnr(pageid, qcode);

    },
    /**Numberdnr*/
    onNumberdnrRefuse: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['refuse'] = value ? '1' : null;

        if (value) {
            this.data.value.pages[pageid].questions[qcode].values['num'] = null;
            this.data.value.pages[pageid].questions[qcode].values['dontknow'] = null;
        } else {
            this.data.value.pages[pageid].questions[qcode].values['num'] = null;
        }

        this.validateNumberdnr(pageid, qcode);

    },
    /**Numberdnr*/
    onNumberdnrDontknow: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['dontknow'] = value ? '1' : null;

        if (value) {
            this.data.value.pages[pageid].questions[qcode].values['num'] = null;
            this.data.value.pages[pageid].questions[qcode].values['refuse'] = null;
        } else {
            this.data.value.pages[pageid].questions[qcode].values['num'] = null;
        }

        this.validateNumberdnr(pageid, qcode);

    },
    /*Numberdnr*/
    onNumberdnrChange: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['num'] = value;

        this.validateNumber(pageid, qcode);

    },
    /*Numberdnr*/
    hasNumberdnrValues: function (qcode, answers) {
        if (answers && (answers[qcode] || answers[`${qcode}_dontknow`] || answers[`${qcode}_refuse`])) {
            return true;
        }
        return false;
    },
    /*Numberdnr*/
    valuesNumberdnr: function (qcode, answers) {
        return {
            "num": (answers && answers[qcode]) ? answers[qcode] : "",
            "dontknow": (answers && answers[`${qcode}_dontknow`]) ? true : null,
            "refuse": (answers && answers[`${qcode}_refuse`]) ? true : null,

        };
    },
    /*Numberdnr*/
    answersNumberdnr: function (pageid, qcode) {
        const question = this.data.value.pages[pageid].questions[qcode];
        const obj = {};
        obj[`${question.id}`] = question.values.num;
        obj[`${question.id}_dontknow`] = question.values.dontknow;
        obj[`${question.id}_refuse`] = question.values.refuse;
        return obj;
    },
    /*Numberdnr*/
    initNumberdnrJson: function () {
        return {
            "visible": true,
            "valid": true,
            "validmin": true,
            "validmax": true,
            "uiclass": "form-control"
        }
    },
    /*Number*/
    validateNumber: function (pageid, qcode) {
        //validations
        //reset
        this.data.value.pages[pageid].questions[qcode].ui.valid =
            this.data.value.pages[pageid].questions[qcode].ui.validmin =
            this.data.value.pages[pageid].questions[qcode].ui.validmax = true;

        //required
        if (this.data.value.pages[pageid].questions[qcode].required) {
            if (this.data.value.pages[pageid].questions[qcode].values['num']) {
                this.data.value.pages[pageid].questions[qcode].ui.valid = true;
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.valid = false;
            }
        }

        //min
        if (this.data.value.pages[pageid].questions[qcode].min &&
            this.data.value.pages[pageid].questions[qcode].ui.valid
        ) {
            if (this.data.value.pages[pageid].questions[qcode].values['num']) {
                if (parseFloat(this.data.value.pages[pageid].questions[qcode].values['num']) <
                    parseFloat(this.data.value.pages[pageid].questions[qcode].min)) {
                    this.data.value.pages[pageid].questions[qcode].ui.validmin = false;
                } else {
                    this.data.value.pages[pageid].questions[qcode].ui.validmin = true;
                }
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.validmin = false;
            }
        }
        //max
        if (this.data.value.pages[pageid].questions[qcode].max &&
            this.data.value.pages[pageid].questions[qcode].ui.valid &&
            this.data.value.pages[pageid].questions[qcode].ui.validmin
        ) {
            if (this.data.value.pages[pageid].questions[qcode].values['num']) {
                if (parseFloat(this.data.value.pages[pageid].questions[qcode].values['num']) >
                    parseFloat(this.data.value.pages[pageid].questions[qcode].max)) {
                    this.data.value.pages[pageid].questions[qcode].ui.validmax = false;
                } else {
                    this.data.value.pages[pageid].questions[qcode].ui.validmax = true;
                }
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.validmax = false;
            }
        }

        //ui
        //validation class
        if (this.data.value.pages[pageid].questions[qcode].ui.valid &&
            this.data.value.pages[pageid].questions[qcode].ui.validmin &&
            this.data.value.pages[pageid].questions[qcode].ui.validmax
        ) {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control is-valid";
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control is-invalid";
        }

        //placeholders in messages
        if (this.data.value.pages[pageid].questions[qcode].min) {
            if (!this.data.value.pages[pageid].questions[qcode].labels.validminorig) {
                this.data.value.pages[pageid].questions[qcode].labels.validminorig =
                    this.data.value.pages[pageid].questions[qcode].labels.validmin
            }
            this.data.value.pages[pageid].questions[qcode].labels.validmin =
                this.data.value.pages[pageid].questions[qcode].labels.validminorig.replace("{min}", this.data.value.pages[pageid].questions[qcode].min);
        }
        if (this.data.value.pages[pageid].questions[qcode].max) {
            if (!this.data.value.pages[pageid].questions[qcode].labels.validmaxorig) {
                this.data.value.pages[pageid].questions[qcode].labels.validmaxorig =
                    this.data.value.pages[pageid].questions[qcode].labels.validmax
            }
            this.data.value.pages[pageid].questions[qcode].labels.validmax =
                this.data.value.labels[qcode].validmaxorig.replace("{max}", this.data.value.pages[pageid].questions[qcode].max);
        }

    },
    /*Number*/
    setNumberValues: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['num'] = value;

        this.validateNumber(pageid, qcode);

    },
    /*Number*/
    onNumberChange: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['num'] = value;

        this.validateNumber(pageid, qcode);
    },
    /*Number*/
    hasNumberValues: function (qcode, answers) {
        if (answers && answers[qcode]) {
            return true;
        }
        return false;
    },
    /*Number*/
    valuesNumber: function (qcode, answers) {
        return {
            "num": (answers && answers[qcode]) ? answers[qcode] : ""
        };
    },
    /*Number*/
    answersNumber: function (pageid, qcode) {
        const question = this.data.value.pages[pageid].questions[qcode];
        const obj = {};
        obj[`${question.id}`] = question.values.num;
        return obj;
    },
    /*Number*/
    initNumberJson: function () {
        return {
            "visible": true,
            "valid": true,
            "validmin": true,
            "validmax": true,
            "uiclass": "form-control"
        }
    },
    /*Emaildnr*/
    validateEmaildnr: function (pageid, qcode) {
        let regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;

        if (this.data.value.pages[pageid].questions[qcode].required) {

            //if dont know or refuse selected its valid
            if (this.data.value.pages[pageid].questions[qcode].values['refuse'] ||
                this.data.value.pages[pageid].questions[qcode].values['dontknow']) {
                this.data.value.pages[pageid].questions[qcode].ui.valid = true;
            } else {
                if (this.data.value.pages[pageid].questions[qcode].values['emaildnr']) {
                    let valid = regex.test(this.data.value.pages[pageid].questions[qcode].values['emaildnr']);
                    if (valid) {
                        this.data.value.pages[pageid].questions[qcode].ui.valid = true;
                    } else {
                        this.data.value.pages[pageid].questions[qcode].ui.valid = false;
                    }
                } else {
                    this.data.value.pages[pageid].questions[qcode].ui.valid = false;
                }
            }

        } else {
            this.data.value.pages[pageid].questions[qcode].ui.valid = true;
        }

        //Set ui class
        if (this.data.value.pages[pageid].questions[qcode].ui.valid) {
            if (this.data.value.pages[pageid].questions[qcode].values['refuse'] ||
                this.data.value.pages[pageid].questions[qcode].values['dontknow']) {
                this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control";
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control is-valid";
            }
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control is-invalid";
        }

    },
    /*Emaildnr*/
    setEmaildnrValues: function (pageid, qcode, value, dontknow, refuse) {

        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['emaildnr'] = value;
        this.data.value.pages[pageid].questions[qcode].values['dontknow'] = dontknow ? '1' : null;
        this.data.value.pages[pageid].questions[qcode].values['refuse'] = refuse ? '1' : null;

        this.validateEmaildnr(pageid, qcode);
    },
    /*Emaildnr*/
    onEmaildnrRefuse: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['refuse'] = value ? '1' : null;

        if (value) {
            this.data.value.pages[pageid].questions[qcode].values['emaildnr'] = null;
            this.data.value.pages[pageid].questions[qcode].valid = true;
            this.data.value.pages[pageid].questions[qcode].textenable = false;
            this.data.value.pages[pageid].questions[qcode].values['dontknow'] = null;
        } else {
            this.data.value.pages[pageid].questions[qcode].values['emaildnr'] = null;
            this.data.value.pages[pageid].questions[qcode].valid = false;
            this.data.value.pages[pageid].questions[qcode].textenable = true;
        }

        this.validateEmaildnr(pageid, qcode);


    },
    /*Emaildnr*/
    onEmaildnrDontknow: function (pageid, qcode, value) {

        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['dontknow'] = value ? '1' : null;

        if (value) {
            this.data.value.pages[pageid].questions[qcode].values['emaildnr'] = null;
            this.data.value.pages[pageid].questions[qcode].valid = true;
            this.data.value.pages[pageid].questions[qcode].enable = false;
            this.data.value.pages[pageid].questions[qcode].values['refuse'] = null;
        } else {
            this.data.value.pages[pageid].questions[qcode].values['emaildnr'] = null;
            this.data.value.pages[pageid].questions[qcode].valid = false;
            this.data.value.pages[pageid].questions[qcode].enable = true;
        }

        this.validateEmaildnr(pageid, qcode);


    },
    /*Emaildnr*/
    onEmaildnrChange: function (pageid, qcode, value) {

        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['emaildnr'] = value;

        this.validateEmaildnr(pageid, qcode);
    },
    /*Emaildnr*/
    hasEmaildnrValues: function (qcode, answers) {
        //text entered or any checkbox is checked
        if (answers && (answers[qcode] || answers[`${qcode}_dontknow`] || answers[`${qcode}_refuse`])) {
            return true;
        }
        return false;
    },
    /*Emaildnr*/
    valuesEmaildnr: function (qcode, answers) {
        return {
            "emaildnr": (answers && answers[qcode]) ? answers[qcode] : null,
            "dontknow": (answers && answers[`${qcode}_dontknow`]) ? true : null,
            "refuse": (answers && answers[`${qcode}_refuse`]) ? true : null,

        };
    },
    /*Emaildnr*/
    answersEmaildnr: function (pageid, qcode) {
        const question = this.data.value.pages[pageid].questions[qcode];
        const obj = {};
        obj[`${question.id}`] = question.values.text;
        obj[`${question.id}_dontknow`] = question.values.dontknow;
        obj[`${question.id}_refuse`] = question.values.refuse;
        return obj;
    },
    /*Emaildnr*/
    initEmaildnrJson: function () {
        return {
            "visible": true,
            "valid": true,
            "uiclass": "form-control"
        }
    },
    /*Email*/
    initEmailJson: function () {
        return {
            "visible": true,
            "valid": true,
            "uiclass": "form-control"
        }
    },
    /*Email*/
    valuesEmails: function (qcode, answers) {
        return {
            "email": (answers && answers[qcode]) ? answers[qcode] : ""
        };
    },
    /*Email*/
    hasEmailValues: function (qcode, answers) {
        if (answers && answers[qcode]) {
            return true;
        }
        return false;
    },
    /*Email*/
    validateEmail: function (pageid, qcode) {
        let regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (this.data.value.pages[pageid].questions[qcode].required) {
            if (this.data.value.pages[pageid].questions[qcode].values['email']) {
                let valid = regex.test(this.data.value.pages[pageid].questions[qcode].values['email']);
                if (valid) {
                    this.data.value.pages[pageid].questions[qcode].ui.valid = true;
                } else {
                    this.data.value.pages[pageid].questions[qcode].ui.valid = false;
                }
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.valid = false;
            }
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.valid = true;
        }

        if (this.data.value.pages[pageid].questions[qcode].ui.valid) {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control is-valid";
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control is-invalid";
        }
    },
    /*Email*/
    setEmailValues: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['email'] = value;

        this.validateEmail(pageid, qcode);

    },
    /*Email*/
    onEmailChange: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['email'] = value;

        this.validateEmail(pageid, qcode);

    },
    /*Textdnr*/
    validateTextdnr: function (pageid, qcode) {
        if (this.data.value.pages[pageid].questions[qcode].required) {

            //if dont know or refuse selected its valid
            if (this.data.value.pages[pageid].questions[qcode].values['refuse'] ||
                this.data.value.pages[pageid].questions[qcode].values['dontknow']) {
                this.data.value.pages[pageid].questions[qcode].ui.valid = true;
            } else {
                if (this.data.value.pages[pageid].questions[qcode].values['text']) {
                    this.data.value.pages[pageid].questions[qcode].ui.valid = true;
                } else {
                    this.data.value.pages[pageid].questions[qcode].ui.valid = false;
                }
            }

        } else {
            this.data.value.pages[pageid].questions[qcode].ui.valid = true;
        }

        //Set ui class
        if (this.data.value.pages[pageid].questions[qcode].ui.valid) {
            if (this.data.value.pages[pageid].questions[qcode].values['refuse'] ||
                this.data.value.pages[pageid].questions[qcode].values['dontknow']) {
                this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control";
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control is-valid";
            }
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control is-invalid";
        }

    },
    /*Textdnr*/
    setTextdnrValues: function (pageid, qcode, value, dontknow, refuse) {

        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['text'] = value;
        this.data.value.pages[pageid].questions[qcode].values['dontknow'] = dontknow ? '1' : null;
        this.data.value.pages[pageid].questions[qcode].values['refuse'] = refuse ? '1' : null;

        this.validateTextdnr(pageid, qcode);
    },
    /**TextDnr*/
    onTextdnrRefuse: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['refuse'] = value ? '1' : null;

        if (value) {
            this.data.value.pages[pageid].questions[qcode].values['text'] = null;
            this.data.value.pages[pageid].questions[qcode].valid = true;
            this.data.value.pages[pageid].questions[qcode].textenable = false;
            this.data.value.pages[pageid].questions[qcode].values['dontknow'] = null;
        } else {
            this.data.value.pages[pageid].questions[qcode].values['text'] = null;
            this.data.value.pages[pageid].questions[qcode].valid = false;
            this.data.value.pages[pageid].questions[qcode].textenable = true;
        }

        this.validateTextdnr(pageid, qcode);


    },
    /**TextDnr*/
    onTextdnrDontknow: function (pageid, qcode, value) {

        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['dontknow'] = value ? '1' : null;

        if (value) {
            this.data.value.pages[pageid].questions[qcode].values['text'] = null;
            this.data.value.pages[pageid].questions[qcode].valid = true;
            this.data.value.pages[pageid].questions[qcode].enable = false;
            this.data.value.pages[pageid].questions[qcode].values['refuse'] = null;
        } else {
            this.data.value.pages[pageid].questions[qcode].values['text'] = null;
            this.data.value.pages[pageid].questions[qcode].valid = false;
            this.data.value.pages[pageid].questions[qcode].enable = true;
        }

        this.validateTextdnr(pageid, qcode);


    },
    /*Textdnr*/
    onTextdnrChange: function (pageid, qcode, value) {

        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['text'] = value;

        this.validateTextdnr(pageid, qcode);
    },
    /*Textdnr*/
    hasTextdnrValues: function (qcode, answers) {
        //text entered or any checkbox is checked
        if (answers && (answers[qcode] || answers[`${qcode}_dontknow`] || answers[`${qcode}_refuse`])) {
            return true;
        }
        return false;
    },
    /*Textdnr*/
    valuesTextdnr: function (qcode, answers) {
        return {
            "text": (answers && answers[qcode]) ? answers[qcode] : null,
            "dontknow": (answers && answers[`${qcode}_dontknow`]) ? true : null,
            "refuse": (answers && answers[`${qcode}_refuse`]) ? true : null,

        };
    },
    /*Textdnr*/
    answersTextdnr: function (pageid, qcode) {
        const question = this.data.value.pages[pageid].questions[qcode];
        const obj = {};
        obj[`${question.id}`] = question.values.text;
        obj[`${question.id}_dontknow`] = question.values.dontknow;
        obj[`${question.id}_refuse`] = question.values.refuse;
        return obj;
    },
    /*Textdnr*/
    initTextdnrJson: function () {
        return {
            "visible": true,
            "valid": true,
            "uiclass": "form-control"
        }
    },
    /**Text*/
    invisibleText: function (pageid, qcode) {
        this.data.value.pages[pageid].questions[qcode].values['text'] = null;
        this.data.value.pages[pageid].questions[qcode].ui.valid = true;
    },
    /**Text*/
    visibleText: function (pageid, qcode) {
        this.data.value.pages[pageid].questions[qcode].values['text'] = null;
        this.data.value.pages[pageid].questions[qcode].ui.valid = true;
        this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control";
    },
    /*Text*/
    validateText: function (pageid, qcode) {
        if (this.data.value.pages[pageid].questions[qcode].required) {
            if (this.data.value.pages[pageid].questions[qcode].values['text']) {
                this.data.value.pages[pageid].questions[qcode].ui.valid = true;
            } else {
                this.data.value.pages[pageid].questions[qcode].ui.valid = false;
            }
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.valid = true;
        }

        if (this.data.value.pages[pageid].questions[qcode].ui.valid) {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control is-valid";
        } else {
            this.data.value.pages[pageid].questions[qcode].ui.uiclass = "form-control is-invalid";
        }
    },
    /*Text*/
    setTextValues: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['text'] = value;

        this.validateText(pageid, qcode);

    },
    /*Text*/
    onTextChange: function (pageid, qcode, value) {
        //Set value in survey object
        this.data.value.pages[pageid].questions[qcode].values['text'] = value;

        this.validateText(pageid, qcode);

    },
    /*Text*/
    hasTextValues: function (qcode, answers) {
        if (answers && answers[qcode]) {
            return true;
        }
        return false;
    },
    /*Text*/
    valuesText: function (qcode, answers) {
        return {
            "text": (answers && answers[qcode]) ? answers[qcode] : ""
        };
    },
    /*Text*/
    answersText: function (pageid, qcode) {
        const question = this.data.value.pages[pageid].questions[qcode];
        const obj = {};
        obj[`${question.id}`] = question.values.text
        return obj;
    },
    /*Text*/
    initTextJson: function () {
        return {
            "visible": true,
            "valid": true,
            "uiclass": "form-control"
        }
    },
    // /*Hidden*/
    // validateHidden: function (pageid, qcode) {
    // },
    /*Hidden*/
    // hasHiddenValues: function (qcode, answers) {
    //     if (answers && answers[qcode]) {
    //         return true;
    //     }
    //     return false;
    // },
    /*Hidden*/
    valuesHidden: function (qcode, answers) {
        return {
            "text": (answers && answers[qcode]) ? answers[qcode] : ""
        };
    },
    /*Hidden*/
    answersHidden: function (pageid, qcode) {
        const question = this.data.value.pages[pageid].questions[qcode];
        const obj = {};
        obj[`${question.id}`] = question.values.text
        return obj;
    },
    /*Hidden*/
    initHiddenJson: function () {
        /* Escape validation and findnext page logic */
        return { "valid": true, "visible": true }
    },

    /* Survey engine */
    replacePlaceholder: function (str) {

        let newstr = str;
        const matchesPlace = str.matchAll(this.regexPlaceholder);
        //if (this.data.debug) console.log(matchesPlace);
        if (matchesPlace) {
            //if (this.data.debug) console.log(`replacePlaceholder: ${str}`);

            for (const match of matchesPlace) {
                if (match.groups.g) {
                    //console.log(match.groups.g.slice(1, -1));
                    const result = this.parseVariable(match.groups.g.slice(1, -1), ``);
                    newstr = newstr.replace(match.groups.g, result);
                    //console.log(`newstr: ${newstr}`);
                }
            }
        }

        return newstr;
    },
    /* Survey engine */
    exeQvalue: function (qvalue) {
        console.log(`exeQvalue`);
        console.log(qvalue);

        const val = this.data.value.pages[qvalue.pageid].questions[qvalue.qcode].values[qvalue.value];
        return val;

        //const parts = qvalue.split(".");
        //const val = this.data.value.page
        //console.log(parts);

    },
    /* Survey engine */
    exeValue: function (value) {
        console.log(`exeValue`);
        console.log(value);

        switch (value.type) {
            case 'qvalue':
                const val = this.exeQvalue(value.qvalue);
                console.log(`exeValue: ${value.type} ${val}`);
                return val;
            case 'value':
                console.log(`exeValue: ${value.type} ${value.value}`);
                return value.value
            default:
                console.log(`exeValue: Invalid type ${value.type}`);
        }
    },
    /* Survey engine */
    exeSurveyCompare: function (compare) {
        switch (compare.type) {
            case 'eq':
                console.log(`exeSurveyCompare: ${compare.type}`);
                const a = this.exeValue(compare.first);
                const b = this.exeValue(compare.second);
                //Both value must exist. Dont compare "no value" or "null" or "undefined" mean not matching
                if (a && b) {
                    return a === b;
                } else {
                    return false;
                }
            case 'gt':
                console.log(`exeSurveyCompare: ${compare.type}`);
                return false;
            case 'lt':
                console.log(`exeSurveyCompare: ${compare.type}`);
                return false;
            case 'neq':
                //For neq comparing value must exist for first and second parameter
                //If value does not exist for any, condition result will be true.
                console.log(`exeSurveyCompare: ${compare.type}`);
                const c = this.exeValue(compare.first);
                const d = this.exeValue(compare.second);

                if (c && d) {
                    return !(c === d);
                } else {
                    return false;
                }
                return false;
            default:
                console.log(`exeSurveyCompare: Invalid type ${compare.type}`);

        }
    },
    /* Survey engine */
    findQuestionByid: function (qcode) {
        for (const pageid in this.data.value.pages) {

            for (const qid in this.data.value.pages[pageid].questions) {
                const question = this.data.value.pages[pageid].questions[qid];
                if (qid == qcode) return question;
            }
        }
    },
    /* Survey engine */
    parseVariable: function (str, ind) {

        //In expression trying variables can be two types. 
        // value between single quotes. we consider values separated by ; as separate values to match
        // page.qcode.value.subvalue

        if (false) console.log(`${ind}parseVariable: ${str}`);

        //Match const first as it start with '
        const matchesConst = str.match(this.regexConst);
        if (false) console.log(matchesConst);
        if (matchesConst) {
            if (false) console.log(`${ind}parseVariable const result: ${str}`);
            //remove single quotes, split multiple values by ; and return array
            const res = str.slice(1, -1).split(';');
            console.log(res);
            return res;//remove single quoate
        }


        const matchesVar = str.match(this.regexVar);
        if (false) console.log(matchesVar);
        if (matchesVar) {
            const parts = str.split(".");
            console.log(parts);

            const questtion = this.findQuestionByid(parts[0]);
            console.log(questtion);
            const result = questtion.values ? questtion.values[parts[1]] : null;

            //Vish need to put more effort to return resulty type based on question type
            //const result = this.data.value.pages[parts[0]].questions[parts[1]].values[parts[2]];
            if (false) console.log(`${ind}parseVariable var result`);
            console.log(result);
            if (Array.isArray(result)) {
                //value already string array
                if (false) console.log(`${ind}parseVariable var result array`);
                return result;
            } else {
                //Not null string value
                if (result) {
                    if (false) console.log(`${ind}parseVariable var result non array`);
                    const res = `${result}`.split(';');
                    console.log(res);
                    return res;
                } else {
                    if (false) console.log(`${ind}parseVariable var result blank array`);
                    return [];
                }
            }
        }
    },
    /* Survey engine <= */
    parseLeq: function (str, ind) {
        if (true) console.log(`${ind}parseLeq: ${str}`);
        const strings = str.split("<=");
        if (true) console.log(strings);
        if (strings && strings.length == 2) {

            const a = this.parseVariable(strings[0].trim(), ind);
            const b = this.parseVariable(strings[1].trim(), ind);

            //let arrA = a.pl

            if (Array.isArray(a) && Array.isArray(b)) {
                //Vish to put more effort. Consider type of qustion and then compare
                let result = (parseFloat(a[0]) <= parseFloat(b[0]));
                if (true) console.log(`${ind}parseLeq array: ${result}`);
                return result;
            } else {
                const result = (parseFloat(a) >= parseFloat(b));
                if (true) console.log(`${ind}parseLeq non array: ${result}`);
                return result;
            }

        } else {
            console.log(`${ind}parseLeq: Invalid string ${str}`);
            return false;
        }
    },
    /* Survey engine >= */
    parseGeq: function (str, ind) {
        if (true) console.log(`${ind}parseGeq: ${str}`);
        const strings = str.split(">=");
        if (true) console.log(strings);
        if (strings && strings.length == 2) {

            const a = this.parseVariable(strings[0].trim(), ind);
            const b = this.parseVariable(strings[1].trim(), ind);

            //let arrA = a.pl

            if (Array.isArray(a) && Array.isArray(b)) {
                //Vish to put more effort. Consider type of qustion and then compare
                let result = (parseFloat(a[0]) >= parseFloat(b[0]));
                if (true) console.log(`${ind}parseGeq array: ${result}`);
                return result;
            } else {
                const result = (parseFloat(a) >= parseFloat(b));
                if (true) console.log(`${ind}parseGeq non array: ${result}`);
                return result;
            }

        } else {
            console.log(`${ind}parseGeq: Invalid string ${str}`);
            return false;
        }
    },
    /* Survey engine */
    parseEq: function (str, ind) {
        if (false) console.log(`${ind}parseEq: ${str}`);
        const strings = str.split("==");
        if (false) console.log(strings);
        if (strings && strings.length == 2) {
            let a;
            if (strings[0].trim() == 'true') {
                a = true;
            } else if (strings[0].trim() == 'false') {
                a = false;
            } else {
                a = this.parseVariable(strings[0].trim(), ind);
            }
            let b;
            if (strings[1].trim() == 'true') {
                b = true;
            } else if (strings[1].trim() == 'false') {
                b = false;
            } else {
                b = this.parseVariable(strings[1].trim(), ind);
            }
            // const a = this.parseVariable(strings[0].trim(), ind);
            // const b = this.parseVariable(strings[1].trim(), ind);

            //let arrA = a.pl

            if (Array.isArray(a) && Array.isArray(b)) {
                let result = false;
                a.forEach((item) => {
                    b.forEach((bitem) => {
                        if (item == bitem) {
                            result = true;
                        }
                    })
                });
                if (false) console.log(`${ind}parseEq array: ${result}`);
                return result;
            } else {
                const result = (a === b);
                if (false) console.log(`${ind}parseEq non array: ${result}`);
                return result;
            }

        } else {
            console.log(`${ind}parseEq: Invalid string ${str}`);
            return false;
        }
    },
    /* Survey engine */
    parseNeq: function (str, ind) {
        if (false) console.log(`${ind}parseNeq: ${str}`);
        const strings = str.split("!=");
        if (false) console.log(strings);
        if (strings && strings.length == 2) {
            const a = this.parseVariable(strings[0].trim(), ind);
            const b = this.parseVariable(strings[1].trim(), ind);
            const result = (a !== b);
            if (false) console.log(`${ind}parseNeq: ${result}`);
            return result;
        } else {
            console.log(`${ind}parseNeq: Invalid string ${str}`);
            return false;
        }
    },
    /* Survey engine */
    parseOr: function (str, ind) {
        if (false) console.log(`${ind}parseOr: ${str}`);
        const strings = str.split("||");
        if (false) console.log(strings);
        if (strings && strings.length > 1) {
            let result = false;
            strings.forEach((item) => {
                const trimmed = item.trim();
                if (trimmed.includes("==")) {
                    result = result || this.parseEq(trimmed, ind);
                } else if (trimmed.includes("!=")) {
                    result = result || this.parseNeq(trimmed, ind);
                } else if (trimmed.includes(">=")) {
                    result = result || this.parseGeq(trimmed, ind);
                } else if (trimmed.includes("<=")) {
                    result = result || this.parseLeq(trimmed, ind);
                } else if (trimmed === "true") {
                    result = result || true;
                } else if (trimmed === "false") {
                    result = result || false;
                } else {
                    console.log(`${ind}parseOr: Invalid Operator ${trimmed}`);
                }
            })
            if (false) console.log(`${ind}parseOr: ${result}`);
            return result;

        } else {
            if (false) console.log(`${ind}parseOr: No or`);

            if (str.includes("==")) {
                return this.parseEq(str, ind);
            } else if (str.includes("!=")) {
                return this.parseNeq(str, ind);
            } else if (str.includes(">=")) {
                return this.parseGeq(str, ind);
            } else if (str.includes("<=")) {
                return this.parseLeq(str, ind);
            } else if (str.trim() === "true") {
                return true;
            } else if (str.trim() === "false") {
                return false;
            } else {
                console.log(`${ind}parseOr: Invalid Operator ${str}`);
            }
        }
    },
    /* Survey engine */
    parseAnd: function (str, ind) {
        if (false) console.log(`${ind}parseAnd: ${str}`);
        const strings = str.split("&&");
        if (this.data.debug) console.log(strings);
        if (strings && strings.length > 1) {
            let result = true;
            strings.forEach((item) => {
                let trimmed = item.trim();
                if (trimmed.includes("||")) {
                    result = result && this.parseOr(trimmed, ind);
                } else if (trimmed.includes("==")) {
                    result = result && this.parseEq(trimmed, ind);
                } else if (trimmed.includes("!=")) {
                    result = result && this.parseNeq(trimmed, ind);
                } else if (trimmed.includes(">=")) {
                    result = result && this.parseGeq(trimmed, ind);
                } else if (trimmed.includes("<=")) {
                    result = result && this.parseLeq(trimmed, ind);
                } else if (trimmed === "true") {
                    result = result && true;
                } else if (trimmed === "false") {
                    result = result && false;
                } else {
                    console.log(`${ind}parseOr: Invalid Operator ${trimmed}`);
                }
            });
            if (false) console.log(`${ind}parseAnd: ${result}`);
            return result;
        } else {
            if (false) console.log(`${ind}parseAnd: No and`);
            return this.parseOr(str, ind);
        }
    },
    /* Survey engine */
    parseGroup: function (str, ind) {
        if (false) console.log(`${ind}parseGroup: ${str}`);
        const matchesMulGrp = str.matchAll(this.regexGrp);
        let hasgrp = false;
        let newstr = str;

        for (const match of matchesMulGrp) {
            if (match.groups.g) {
                console.log(match.groups.g.slice(1, -1));
                hasgrp = true;
                const result = this.parseGroup(match.groups.g.slice(1, -1), `${ind}  `);
                newstr = newstr.replace(match.groups.g, result);
                console.log(`${ind}newstr: ${newstr}`);
            }
        }

        if (hasgrp && newstr.match(this.regexGrp)) {
            if (false) console.log(`${ind}Has group str: ${newstr}`);
            const result = this.parseGroup(newstr, `${ind}  `);
            if (false) console.log(`${ind}Has group result: ${result}`);
            return result;
        } else {
            if (false) console.log(`${ind}No group str: ${newstr}`);
            const result = this.parseAnd(newstr, ind);
            if (false) console.log(`${ind}No group result: ${result}`);
            return result;
        }

    },

    regexGrp: /(?<g>\([^\(]+?\))?/g, // Start with "(" and ends with ")". Cover everything between this
    regexVar: /[a-zA-Z][a-zA-Z_\d\.]+/g, // Start with alpha, min 1 char and can contain _, digit and .
    regexConst: /'[a-zA-Z_\d\.;]+'/g, // Start with single quote(') and ends with (')
    regexPlaceholder: /(?<g>{[^{]+?})/g, // Start with "{" and ends with "}". Cover everything between this

    /* Old Survey engine - Not in use*/
    exeSurveyCondition: function (condition) {

        switch (condition.type) {
            case 'compare':
                const val = this.exeSurveyCompare(condition.compare);
                console.log(`exeSurveyCompare(${condition.type}): ${val}`);
                return val;
            case 'and':
                if (Array.isArray(condition.and)) {

                    let result = true;
                    condition.and.forEach((item) => {
                        result = result && this.exeSurveyCondition(item);
                    });
                    console.log(`exeSurveyCompare(${condition.type}): ${result}`);
                    return result;

                } else {
                    console.log(`exeSurveyCompare( ${condition.type}): missing 'and' or is not an array`);
                    return false;
                }
            case 'or':
                if (Array.isArray(condition.or)) {

                    let result = false;
                    condition.or.forEach((item) => {
                        result = result || this.exeSurveyCondition(item);
                    });
                    console.log(`exeSurveyCompare(${condition.type}): ${result}`);
                    return result;

                } else {
                    console.log(`exeSurveyCompare( ${condition.type}): missing 'and' or is not an array`);
                    return false;
                }

                return false;
            default:
                console.log(`exeSurveyCompare: Invalid type ${condition.type}`);

        }

    },

})