// JavaScript Document

dmx.Component('etcs-timepicker', {
    extends: "form-element",

    initialData: {
        tdconfig: {
            display: {
                icons: {
                    type: 'icons',
                    time: 'fa fa-solid fa-clock',
                    date: 'fa fa-solid fa-calendar',
                    up: 'fa fa-solid fa-arrow-up',
                    down: 'fa fa-solid fa-arrow-down',
                    previous: 'fa fa-solid fa-chevron-left',
                    next: 'fa fa-solid fa-chevron-right',
                    today: 'fa fa-solid fa-calendar-check',
                    clear: 'fa fa-solid fa-trash',
                    close: 'fa fa-solid fa-xmark'
                },
                components: {
                    calendar: false,
                    date: false,
                    month: false,
                    year: false,
                    decades: false,
                    clock: true,
                    hours: true,
                    minutes: true,
                    seconds: false,
                    //deprecated use localization.hourCycle = 'h24' instead
                    useTwentyfourHour: undefined
                },

                theme: 'light'
            },
            localization: {
                locale: 'en-US',
                format: 'hh:mm T',
            },
            defaultDate: undefined,
        }
    },

    attributes: {
    },

    methods: {
        setValue: function (value) {
            console.log(`setValue(${value})`);

            //Update state
            this.set("value", value);

            this.props.value = value;

            //Update ui
            this.recreateDateWidget(value);

            //This comp value is updated so if other components are using they can update their self
            dmx.nextTick(function () {
                this.dispatchEvent('updated');
            }, this);
        }
    },

    events: {
        updated: Event,
        timechanged: Event,
    },

    recreateDateWidget: function () {

        const value = this.data.value;
        //Value is in HH:mm format

        console.log(`recreateDateWidget(${value})`);

        //Update value in config
        let formattedate = value ? this.convertTo12Hr(value) : undefined;

        if (value) {
            document.getElementById(`${this.name}_input`).value = formattedate;
            //update config
            this.data.tdconfig.defaultDate = formattedate;
        } else {
            document.getElementById(`${this.name}_input`).value = null;
            //update config
            this.data.tdconfig.defaultDate = undefined;
        }

        //dettach event
        if (this.tempusDominusOnChange) this.tempusDominusOnChange.unsubscribe();

        //dispose 
        if (this.tempusDominus) this.tempusDominus.dispose();

        console.log(this.data.tdconfig);

        //recreate
        this.tempusDominus = new tempusDominus.TempusDominus(
            document.getElementById(`${this.name}_input`), Object.assign({}, this.data.tdconfig));

        //attache event handler
        this.tempusDominusOnChange = this.tempusDominus.subscribe('change.td', () => {

            //Update state
            let formattedstr = document.getElementById(`${this.name}_input`).value;

            let timestr = this.covertTo24Hr(formattedstr);

            console.log(`tempusDominusOnChange ${formattedstr} ${timestr}`);


            if (this.data.value != timestr) {

                console.log(`tempusDominusOnChange fire updates`);

                this.set("value", timestr);

                this.props.value = timestr;

                //This comp value is updated so if other components are using they can update their self
                dmx.nextTick(function () {
                    this.dispatchEvent('updated');
                    this.dispatchEvent('timechanged');
                }, this);
            }
        });
    },

    update: function (props, fields) {
        //Handles dynamic propery updates on container. If any dynamic property of this component is changed, this method will be fired with "fields" containing changed property name. this.props holds new value, props hold old values
        // console.log('etcs-timepicker update');
        // console.log(props);
        // console.log(this.props);
        // console.log(fields);

        if (fields.has('value') && this.data.value != this.props.value) {
            //Update state
            this.data.value = this.props.value;
            //Update ui
            this.recreateDateWidget();

            //This comp value is updated so if other components are using they can update their self
            dmx.nextTick(function () {
                this.dispatchEvent('updated');
            }, this);
        }
    },

    render: function (node) {
        //This method is called once after page is loaded. It renders html for initial state
        dmx.Component("form-element").prototype.render.call(this, node);

        this.data.value = this.props.value;

        this.recreateDateWidget();


    },

    // dateFromYYYYMMdd: function (str) {
    //     console.log(`dateFromYYYYMMdd(${str})`);
    //     let parts = str.split('-');
    //     console.log(parseInt(parts[0]));
    //     console.log(parseInt(parts[1]) - 1);
    //     console.log(parseInt(parts[2]));
    //     //let date = new Date(Date.UTC(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2])));
    //     //let date = new Date(Date.parse(str));
    //     //let date = new Date(parts[0], parts[1], parts[2]);
    //     //prefix zero if needed
    //     //let month = (parseInt(parts[1]) - 1) < 10 ? '0' + (parseInt(parts[1]) - 1) : '' + (parseInt(parts[1]) - 1);
    //     let date = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]), 0, 0, 0, 0);
    //     console.log(date);
    //     return date;
    // },

    covertTo24Hr: function (str) {
        const [time, modifier] = str.split(' ');

        let [hours, minutes] = time.split(':');

        if (hours === '12') {
            hours = '00';
        }

        if (modifier === 'PM') {
            hours = parseInt(hours, 10) + 12;
        }

        return `${hours}:${minutes}`;
    },

    convertTo12Hr: function (str) {
        const [hourString, minute] = str.split(":");
        const hour = +hourString % 24;
        return (hour % 12 || 12) + ":" + minute + (hour < 12 ? " AM" : " PM");
    },
});