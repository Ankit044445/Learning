// JavaScript Document
dmx.Component('etcs-autocomplete', {
    extends: "form-element",

    dropdown: null,

    initialData: {
        debug: false,
    },

    attributes: {
    },

    methods: {
        showDropdownMenu: function (value) {
            if (value) {
                this.dropdown.show()
            } else {
                this.dropdown.hide()
            }
        },
        hideDropdownMenu: function (value) {
            if (value) {
                this.dropdown.hide()
            } else {
                this.dropdown.show()
            }
        },
    },

    init: function () {
        // console.debug('init', this.name)
        // let toggleBtn = document.querySelectorAll(`#${this.name}_drp_tgl`)
        // this.dropdown = new bootstrap.Dropdown(toggleBtn[0]);

        // $(`#${this.name}_drp_tgl`).on('focus', (event) => {
        //     console.log('focus');
        //     //$(`#${this.name}_drp_tgl`).removeAttr('data-bs-toggle')
        //     //$(`#${this.name}_drp_tgl`).attr('data-bs-toggle', 'dropdown')
        //     //this.dropdown.show()
        // });

        // $(`#${this.name}_drp_tgl`).on('blur', (event) => {
        //     console.log('blur');
        //     //this.dropdown.hide()
        //     //$(`#${this.name}_drp_tgl`).removeAttr('data-bs-toggle')
        //     //$(`#${this.name}_drp_tgl`).attr('data-bs-toggle', 'dropdown')
        // });


    },

    events: {
        updated: Event,
    },

    render: function (node) {
        dmx.Component("form-element").prototype.render.call(this, node);

        this.init();
    },

    update: function (props, fields) {
        if (fields.has('value')) {
            $(`#${this.name}_drp_tgl`).val(this.props.value)
            this.set("value", this.props.value)
        }
    }
});
