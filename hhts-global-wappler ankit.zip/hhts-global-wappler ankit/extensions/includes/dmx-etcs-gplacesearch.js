// JavaScript Document
dmx.Component('etcs-gplacesearch', {

    autocompleteservice: null,

    initialData: {
        data: []
    },

    attributes: {
        bound_ne_lat: {
            default: null
        },
        bound_ne_lng: {
            default: null
        },
        bound_sw_lat: {
            default: null
        },
        bound_sw_lng: {
            default: null
        },
        text: {
            default: null,
        }
    },

    init: function () {
        this.autocompleteservice = new google.maps.places.AutocompleteService();
    },

    searchPlaces: function () {
        if (this.props.text && this.props.text.length > 2) {

            let newBounds = null;

            if (this.props.bound_sw_lat && this.props.bound_sw_lng &&
                this.props.bound_ne_lat && this.props.bound_ne_lng) {
                const southwest = { lat: parseFloat(this.props.bound_sw_lat), lng: parseFloat(this.props.bound_sw_lng) };
                const northeast = { lat: parseFloat(this.props.bound_ne_lat), lng: parseFloat(this.props.bound_ne_lng) };
                newBounds = new google.maps.LatLngBounds(southwest, northeast);

            }

            this.autocompleteservice.getQueryPredictions({
                input: this.props.text,
                bounds: newBounds
            }, (results, status) => {
                if (status === google.maps.places.PlacesServiceStatus.OK) {
                    console.log(results);
                    this.set("data", results.map((item) => { return { "key": item.place_id, "text": item.description } }));
                } else {
                    this.set("data", []);
                }
            }
            );
        } else {
            this.set("data", []);
        }
    },

    render: function (node) {
        this.autocompleteservice = new google.maps.places.AutocompleteService();
    },

    update: function (props, fields) {
        if (fields.has("text")) {
            this.searchPlaces();
        }
    }
});
