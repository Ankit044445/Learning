UPDATE `survey_labels` SET `survey_code` = 'verifyqualification', `page_code` = 'page1' WHERE `survey_labels`.`id` = 521;
UPDATE `survey_labels` SET `survey_code` = 'verifyqualification', `page_code` = 'page1' WHERE `survey_labels`.`id` = 522;
UPDATE `survey_labels` SET `survey_code` = 'verifyqualification', `page_code` = 'page1' WHERE `survey_labels`.`id` = 523;
UPDATE `survey_labels` SET `survey_code` = 'verifyqualification', `page_code` = 'page1' WHERE `survey_labels`.`id` = 524;