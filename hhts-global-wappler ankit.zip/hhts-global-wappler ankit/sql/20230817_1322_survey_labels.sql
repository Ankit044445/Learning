CREATE TABLE `survey_labels` (
    `id` INT NOT NULL AUTO_INCREMENT , 
    `project_code` VARCHAR(80) NULL DEFAULT NULL , 
    `survey_code` VARCHAR(80) NULL DEFAULT NULL , 
    `page_code` VARCHAR(80) NULL DEFAULT NULL ,
    `questionid` VARCHAR(80) NULL DEFAULT NULL , 
    `label_name` VARCHAR(80) NULL DEFAULT NULL , 
    `platform` VARCHAR(20) NULL DEFAULT NULL , 
    `value_en` TEXT NULL DEFAULT NULL , 
    PRIMARY KEY (`id`)
) ENGINE = InnoDB CHARSET=utf8mb4 COLLATE utf8mb4_unicode_ci;


ALTER TABLE `survey_labels` ADD UNIQUE `unique_survey_label_key` (
    `project_code`, 
    `survey_code`, 
    `page_code`, 
    `questionid`, 
    `label_name`, 
    `platform`
);
