CREATE TABLE `question_options` (
    `id` INT NOT NULL AUTO_INCREMENT , 
    `project_code` VARCHAR(80) NOT NULL , 
    `survey_code` VARCHAR(80) NOT NULL , 
    `page_code` VARCHAR(80) NOT NULL , 
    `questionid` VARCHAR(80) NOT NULL , 
    `platform` VARCHAR(20) NOT NULL , 
    `sequence` INT NOT NULL , 
    `option_key` VARCHAR(80) NOT NULL , 
    `value_en` VARCHAR(255) NOT NULL , 
    PRIMARY KEY (`id`)
) ENGINE = InnoDB CHARSET=utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE `question_options` ADD UNIQUE `unique_question_option_key` (
    `project_code`, 
    `survey_code`, 
    `page_code`, 
    `questionid`, 
    `platform`, 
    `sequence`
);