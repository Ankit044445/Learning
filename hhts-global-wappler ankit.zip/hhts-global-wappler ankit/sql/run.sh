#This script will find all .sql files and run them on database server
#All sql files must be copied in "sql" directory. Sub directory under "sqls" directory will be ignored
#File names must be sortable. So pls prefix all the file names with same timestamp
#Log file will be created for each date

#DB Config
DBUSER="root"
DBPASS="home1234"
DBNAME="hhts-global"

#File Dir. User this as prefix for all path. So script can be run from from any path
workdir=$(dirname "$0")
#sqlsdir="/Users/vishal/Data/adroit-pmtool/pmtool-database"
sqlsdir=$(dirname "$0")
echo $workdir

#Current timestamp
timestamp=$(date +%Y%m%d_%H%M%S)

datestamp=$(date +%Y%m%d)

#Log file to write script logs
logfile="$workdir/logs/$datestamp.txt"

#Last run file
lastrun="$workdir/lastrun.txt"

#List of files already executed
processed="$workdir/processed.txt"

#Script starts
echo "STARTED - $timestamp" >> $logfile

#Fetch all sql files
#sqlfiles=`find $workdir/sqls/* -maxdepth 0 -type f -name "*.sql" | sort -z`
sqlfiles=`find $sqlsdir/* -maxdepth 0 -type f -name "*.sql" | sort -z`

#If program is not running first time. Fetch only newer files
if [ -e $lastrun ]
then
    echo "Not first time"
    sqlfiles=`find $sqlsdir/* -maxdepth 0 -type f -newer $lastrun -name "*.sql" | sort -z`
fi

for sqlfile in $sqlfiles
do
    echo "Loop: $sqlfile"
    #Check if file already processed
    if grep -Fxq "$sqlfile" $processed
    then
        echo "File already executed: $sqlfile" >> $logfile
        echo "File already executed: $sqlfile"
    else
        #echo "Uploading: $sqlfile" >> $logfile
        
        mysql -u"$DBUSER" -p"$DBPASS" $DBNAME < $sqlfile

        #If no error 
        if [ "$?" -eq 0 ]; 
        then
            #Save into list of processed file so we dont run same file again. 
            #I mean is someone edit same sql file (by mistake) server should not re-run same file
            echo $sqlfile >> $processed
            echo "Upload success: $sqlfile" >> $logfile
            echo "Upload success: $sqlfile"
        else
            echo "Error while uploading: $sqlfile" >> $logfile
            echo "Error while uploading: $sqlfile"
        fi
    fi
done

echo "AUTO GENERATED. DO NOT TOUCH" > $lastrun

echo "ENDED - $timestamp" >> $logfile
