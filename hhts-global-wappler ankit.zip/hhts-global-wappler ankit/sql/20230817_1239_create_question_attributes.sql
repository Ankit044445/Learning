CREATE TABLE `question_attributes` (
    `id` INT NOT NULL AUTO_INCREMENT , `project_code` VARCHAR(80) NULL DEFAULT NULL , 
    `survey_code` VARCHAR(80) NULL DEFAULT NULL , 
    `page_code` VARCHAR(80) NULL DEFAULT NULL , 
    `questionid` VARCHAR(80) NULL DEFAULT NULL , 
    `attribute_name` VARCHAR(80) NULL DEFAULT NULL , 
    `attribute_platform` VARCHAR(20) NULL DEFAULT NULL , 
    `attribute_value` TEXT NULL DEFAULT NULL , 
    PRIMARY KEY (`id`)
) ENGINE = InnoDB CHARSET=utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE `question_attributes` ADD UNIQUE `unique_question_attribute_key` (
    `project_code`, 
    `survey_code`, 
    `page_code`, 
    `questionid`, 
    `attribute_name`,
    `attribute_platform`
) USING BTREE;
